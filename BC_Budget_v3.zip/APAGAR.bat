@echo off
chcp 65001 >nul
cd /d "%~dp0"
title BIMCost Budget - Apagar

echo Apagando BIMCost Budget...
echo Tus proyectos y cantidades NO se borraran.
echo.

where docker >nul 2>nul
if errorlevel 1 (
  echo Docker no esta disponible. No hay nada que apagar.
  pause
  exit /b 1
)

docker compose down
if errorlevel 1 (
  echo.
  echo No se pudo contactar Docker Desktop. Puede que ya este apagado.
) else (
  echo.
  echo Listo. Los datos quedaron guardados.
  echo Para encender nuevamente usa INSTALAR.bat o ABRIR.bat.
)
echo.
pause
