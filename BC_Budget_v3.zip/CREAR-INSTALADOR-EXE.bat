@echo off
setlocal EnableExtensions
chcp 65001 >nul
cd /d "%~dp0"
title BIMCost Budget - Crear instalador EXE

echo ================================================================
echo        Crear instalador BIMCost Budget Desktop v0.2.0-beta.1
echo ================================================================
echo.
echo El EXE instalara un acceso directo nativo en Windows.
echo El backend y la base de datos seguiran gestionados por Docker,
echo que conserva los proyectos aunque cierre la ventana.
echo.

where node >nul 2>nul
if errorlevel 1 goto :noNode
where npm >nul 2>nul
if errorlevel 1 goto :noNode

pushd "%~dp0desktop"
echo [1/2] Instalando herramientas de empaquetado (solo la primera vez)...
call npm install --no-audit --no-fund
if errorlevel 1 goto :failed

echo.
echo [2/2] Creando el instalador de Windows...
call npm run dist:win
if errorlevel 1 goto :failed
popd

echo.
echo ================================================================
echo  LISTO
 echo ================================================================
echo El instalador se encuentra en:
echo   %~dp0dist-desktop\BIMCost-Budget-0.2.0-beta.1-instalador.exe
echo.
start "" "%~dp0dist-desktop"
pause
exit /b 0

:failed
popd
echo.
echo [ERROR] No se pudo crear el instalador.
echo Comprueba Internet, antivirus y espacio disponible.
pause
exit /b 1

:noNode
echo [ERROR] Se necesita Node.js 20 o superior para construir el EXE.
pause
exit /b 1
