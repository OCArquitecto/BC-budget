@echo off
setlocal EnableExtensions EnableDelayedExpansion
chcp 65001 >nul
cd /d "%~dp0"
title BIMCost Budget - Escritorio

echo ================================================================
echo              BIMCost Budget Desktop v0.2.0-beta.1
echo ================================================================
echo.

where docker >nul 2>nul
if errorlevel 1 goto :noDocker

docker info >nul 2>nul
if errorlevel 1 (
  echo Docker Desktop esta cerrado. Intentando abrirlo...
  if exist "%ProgramFiles%\Docker\Docker\Docker Desktop.exe" start "" "%ProgramFiles%\Docker\Docker\Docker Desktop.exe"
  echo Esperando el motor de Docker...
  set /a n=0
  :waitDocker
  timeout /t 2 /nobreak >nul
  docker info >nul 2>nul
  if not errorlevel 1 goto :dockerReady
  set /a n+=1
  if !n! LSS 60 goto :waitDocker
  echo [ERROR] Docker no pudo iniciar. Abre Docker Desktop manualmente.
  pause
  exit /b 1
)

:dockerReady
docker start bimcost-budget-db bimcost-budget-app >nul 2>nul

where node >nul 2>nul
if errorlevel 1 goto :noNode
where npm >nul 2>nul
if errorlevel 1 goto :noNode

if not exist "%~dp0desktop\node_modules\electron\dist\electron.exe" (
  echo Preparando la ventana de escritorio por primera vez...
  echo Esto descarga Electron y puede tardar algunos minutos.
  pushd "%~dp0desktop"
  call npm install --no-audit --no-fund
  if errorlevel 1 (
    popd
    echo [ERROR] No se pudo preparar la ventana de escritorio.
    pause
    exit /b 1
  )
  popd
)

echo Abriendo BIMCost Budget en una ventana nativa...
start "BIMCost Budget" /D "%~dp0desktop" "%~dp0desktop\node_modules\.bin\electron.cmd" .
exit /b 0

:noDocker
echo [ERROR] Docker Desktop no esta instalado o Windows no lo encuentra.
echo Ejecuta primero INSTALAR.bat.
pause
exit /b 1

:noNode
echo [ERROR] Node.js no esta instalado o Windows no lo encuentra.
echo Instala Node.js 20 o superior y vuelve a ejecutar este archivo.
pause
exit /b 1
