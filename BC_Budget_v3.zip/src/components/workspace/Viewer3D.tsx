"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import * as THREE from "three";
import {
  RotateCcw, Maximize2, Minimize2, Sun, Moon, Box as BoxIcon, Layers,
  Ruler, Eye, EyeOff, Focus, Grid3x3, Scissors, SquareDashedBottom, PackageCheck, PackageX,
} from "lucide-react";
import { Chip, cx } from "@/components/ui";
import { fmt } from "@/lib/client";

export interface ViewerFace {
  outline: [number, number][];
  holes: [number, number][][];
  thickness: number;
  origin: [number, number, number];
  uAxis: [number, number, number];
  vAxis: [number, number, number];
  nAxis: [number, number, number];
  clipped: boolean;
}

export interface ViewerElement {
  id: string;
  name: string | null;
  ifcClass: string;
  level: string | null;
  material: string | null;
  geometry: {
    kind: string;
    size: [number, number, number];
    center: [number, number, number];
    yaw: number;
    face?: ViewerFace;
    openings?: { width: number; height: number; area: number; name: string | null }[];
    oriented?: {
      size: [number, number, number];
      center: [number, number, number];
      axes: [[number, number, number], [number, number, number], [number, number, number]];
    };
  } | null;
  dimensions?: Record<string, number | null> | null;
  dimensionSources?: Record<string, string> | null;
  semanticType?: string | null;
  activities?: { id: string; code: string; name: string; status: string }[];
  excluded?: boolean;
}

type ViewMode = "3D" | "PLANTA" | "FRENTE" | "LADO";

const CLASS_COLOR: Record<string, number> = {
  IFCWALL: 0xc08b5c, IFCWALLSTANDARDCASE: 0xc08b5c, IFCCURTAINWALL: 0x74b3d6,
  IFCSLAB: 0x9fa9b5, IFCROOF: 0xc25b5b, IFCPLATE: 0x9fa9b5,
  IFCBEAM: 0x4f9d8f, IFCCOLUMN: 0x2f7d6f,
  IFCFOOTING: 0x7d8590, IFCPILE: 0x7d8590,
  IFCDOOR: 0xdba53a, IFCWINDOW: 0x62bde0,
  IFCPIPESEGMENT: 0x4a90c2, IFCFLOWSEGMENT: 0x4a90c2, IFCPIPEFITTING: 0x3a7ba8,
  IFCCABLESEGMENT: 0xe0a93a, IFCCABLECARRIERSEGMENT: 0xe0a93a, IFCDUCTSEGMENT: 0x9a9ac0,
  IFCSANITARYTERMINAL: 0xcfd6dd, IFCFLOWTERMINAL: 0xcfd6dd,
  IFCOUTLET: 0xeec26a, IFCSWITCHINGDEVICE: 0xeec26a, IFCLAMP: 0xf2df5e, IFCLIGHTFIXTURE: 0xf2df5e,
  IFCSPACE: 0x4fb5b0, IFCCOVERING: 0xc2a79f, IFCSTAIR: 0x9079b5, IFCRAILING: 0x9079b5,
  IFCFURNISHINGELEMENT: 0x8a94a6, IFCFURNITURE: 0x8a94a6,
};
const colorFor = (c: string) => CLASS_COLOR[c.toUpperCase()] ?? 0x8ba0b6;

/* ------------------------------------------------------------------ */
/* Etiquetas de cota dibujadas como sprites de texto                   */
/* ------------------------------------------------------------------ */
function makeLabel(text: string, color: string, bg: string): THREE.Sprite {
  const pad = 8;
  const canvas = document.createElement("canvas");
  const ctx = canvas.getContext("2d")!;
  const font = "600 34px 'IBM Plex Mono', ui-monospace, monospace";
  ctx.font = font;
  const w = ctx.measureText(text).width;
  canvas.width = Math.ceil(w + pad * 2);
  canvas.height = 52;
  const c2 = canvas.getContext("2d")!;
  c2.font = font;
  c2.fillStyle = bg;
  c2.strokeStyle = color;
  c2.lineWidth = 2;
  c2.beginPath();
  c2.roundRect(1, 1, canvas.width - 2, canvas.height - 2, 8);
  c2.fill();
  c2.stroke();
  c2.fillStyle = color;
  c2.textBaseline = "middle";
  c2.fillText(text, pad, canvas.height / 2 + 1);

  const tex = new THREE.CanvasTexture(canvas);
  tex.minFilter = THREE.LinearFilter;
  const mat = new THREE.SpriteMaterial({ map: tex, depthTest: false, transparent: true });
  const sprite = new THREE.Sprite(mat);
  sprite.renderOrder = 999;
  sprite.userData.aspect = canvas.width / canvas.height;
  return sprite;
}

/** Construye la malla de un elemento: cara real con vanos, o caja. */
function buildMesh(el: ViewerElement, material: THREE.Material): THREE.Mesh {
  const g = el.geometry!;
  const f = g.face;

  if (f && f.outline.length >= 3) {
    const shape = new THREE.Shape(f.outline.map(([u, v]) => new THREE.Vector2(u, v)));
    for (const hole of f.holes ?? []) {
      if (hole.length >= 3) shape.holes.push(new THREE.Path(hole.map(([u, v]) => new THREE.Vector2(u, v))));
    }
    const geom = new THREE.ExtrudeGeometry(shape, { depth: Math.max(f.thickness, 0.005), bevelEnabled: false });
    geom.translate(0, 0, -Math.max(f.thickness, 0.005) / 2);
    const mesh = new THREE.Mesh(geom, material);

    // Base ortonormal de la cara (IFC Z-up → three Y-up)
    const toThree = (v: [number, number, number]) => new THREE.Vector3(v[0], v[2], -v[1]);
    const u = toThree(f.uAxis).normalize();
    const vv = toThree(f.vAxis).normalize();
    const n = toThree(f.nAxis).normalize();
    const m = new THREE.Matrix4().makeBasis(u, vv, n);
    mesh.quaternion.setFromRotationMatrix(m);
    mesh.position.copy(toThree(f.origin));
    const us = f.outline.map((p) => p[0]);
    const vs = f.outline.map((p) => p[1]);
    mesh.userData.measureSize = [
      Math.max(...us) - Math.min(...us),
      Math.max(...vs) - Math.min(...vs),
      f.thickness,
    ];
    mesh.userData.measureAxes = [u, vv, n];
    return mesh;
  }

  if (g.oriented) {
    const [length, sectionMajor, sectionMinor] = g.oriented.size;
    const geom = new THREE.BoxGeometry(
      Math.max(length, 0.01), Math.max(sectionMajor, 0.01), Math.max(sectionMinor, 0.01)
    );
    const mesh = new THREE.Mesh(geom, material);
    const toThree = (v: [number, number, number]) => new THREE.Vector3(v[0], v[2], -v[1]);
    // BoxGeometry: X=longitud, Y=canto, Z=ancho
    const x = toThree(g.oriented.axes[0]).normalize();
    const y = toThree(g.oriented.axes[1]).normalize();
    let z = toThree(g.oriented.axes[2]).normalize();
    // Mantener una base de mano derecha
    if (new THREE.Vector3().crossVectors(x, y).dot(z) < 0) z = z.multiplyScalar(-1);
    mesh.quaternion.setFromRotationMatrix(new THREE.Matrix4().makeBasis(x, y, z));
    mesh.position.copy(toThree(g.oriented.center));
    mesh.userData.measureSize = [length, sectionMajor, sectionMinor];
    mesh.userData.measureAxes = [x, y, z];
    return mesh;
  }

  const [sx, sy, sz] = g.size;
  const geom = new THREE.BoxGeometry(Math.max(sx, 0.01), Math.max(sz, 0.01), Math.max(sy, 0.01));
  const mesh = new THREE.Mesh(geom, material);
  mesh.position.set(g.center[0], g.center[2], -g.center[1]);
  mesh.rotation.y = -g.yaw;
  mesh.userData.measureSize = [sx, sz, sy];
  return mesh;
}

export interface ViewerMeasurement {
  method: string;
  config: { areaBasis?: string; dimension?: string; volumeBasis?: string; factor?: number };
  value: number | null;
  unit: string;
  /** Aplica la regla a todos los elementos de la cantidad/grupo. */
  onApply: (config: { areaBasis?: string; dimension?: string; volumeBasis?: string; factor?: number }) => void | Promise<void>;
}

export function Viewer3D({
  elements, height = 520, selectedId, onSelect, title, measurement,
}: {
  elements: ViewerElement[];
  height?: number;
  selectedId?: string | null;
  onSelect?: (id: string | null) => void;
  title?: string;
  measurement?: ViewerMeasurement;
}) {
  const mountRef = useRef<HTMLDivElement | null>(null);
  const st = useRef<{
    renderer?: THREE.WebGLRenderer;
    scene?: THREE.Scene;
    camera?: THREE.Camera;
    persp?: THREE.PerspectiveCamera;
    ortho?: THREE.OrthographicCamera;
    meshes: Map<string, THREE.Mesh>;
    edges: Map<string, THREE.LineSegments>;
    dims?: THREE.Group;
    target: THREE.Vector3;
    sph: { radius: number; theta: number; phi: number };
    pan: THREE.Vector3;
    frame?: number;
    apply?: () => void;
  }>({ meshes: new Map(), edges: new Map(), target: new THREE.Vector3(), sph: { radius: 40, theta: Math.PI / 4, phi: Math.PI / 3.4 }, pan: new THREE.Vector3() });

  const [hover, setHover] = useState<ViewerElement | null>(null);
  const [internalSelected, setInternalSelected] = useState<string | null>(null);
  const [mode, setMode] = useState<ViewMode>("3D");
  const [light, setLight] = useState(true);
  const [expanded, setExpanded] = useState(false);
  const [hiddenLevels, setHiddenLevels] = useState<Set<string>>(new Set());
  const [hiddenClasses, setHiddenClasses] = useState<Set<string>>(new Set());
  const [layersOpen, setLayersOpen] = useState(false);
  const [showAll, setShowAll] = useState(true);
  const [showDims, setShowDims] = useState(true);
  const [showMeasured, setShowMeasured] = useState(false);
  const [hiddenActivities, setHiddenActivities] = useState<Set<string>>(new Set());
  const [measureDraft, setMeasureDraft] = useState(measurement?.config ?? {});
  const [applyingMeasure, setApplyingMeasure] = useState(false);
  const [ready, setReady] = useState(false);

  useEffect(() => { setMeasureDraft(measurement?.config ?? {}); }, [measurement?.config]);

  const drawable = useMemo(
    () => elements.filter((e) => e.geometry && (e.geometry.face || e.geometry.size.some((s) => s > 0.0005))),
    [elements]
  );
  const levels = useMemo(() => [...new Set(drawable.map((d) => d.level).filter(Boolean))] as string[], [drawable]);
  const classes = useMemo(() => [...new Set(drawable.map((d) => d.ifcClass))].sort(), [drawable]);
  const measuredCount = useMemo(() => drawable.filter((d) => (d.activities?.length ?? 0) > 0).length, [drawable]);
  const activityChoices = useMemo(() => {
    const map = new Map<string, { id: string; code: string; name: string; count: number }>();
    for (const el of drawable) {
      for (const a of el.activities ?? []) {
        const current = map.get(a.id) ?? { id: a.id, code: a.code, name: a.name, count: 0 };
        current.count++;
        map.set(a.id, current);
      }
    }
    return [...map.values()].sort((a, b) => a.code.localeCompare(b.code, "es", { numeric: true }));
  }, [drawable]);
  const visibleIds = useMemo(() => {
    const s = new Set<string>();
    for (const d of drawable) {
      if (d.level && hiddenLevels.has(d.level)) continue;
      if (!d.level && hiddenLevels.has("(sin nivel)")) continue;
      if (hiddenClasses.has(d.ifcClass)) continue;
      const acts = d.activities ?? [];
      // Si el elemento tiene actividades, basta con que una permanezca encendida.
      if (acts.length > 0 && acts.every((a) => hiddenActivities.has(a.id))) continue;
      s.add(d.id);
    }
    return s;
  }, [drawable, hiddenLevels, hiddenClasses, hiddenActivities]);

  const effectiveSelectedId = selectedId !== undefined ? selectedId : internalSelected;
  const selected = useMemo(
    () => drawable.find((d) => d.id === effectiveSelectedId) ?? null,
    [drawable, effectiveSelectedId]
  );
  const viewHeight = expanded ? Math.max((typeof window !== "undefined" ? window.innerHeight : 900) - 210, 480) : height;

  /* --------------------------- escena ----------------------------- */
  useEffect(() => {
    const mount = mountRef.current;
    if (!mount || drawable.length === 0) return;

    const width = mount.clientWidth || 800;
    const scene = new THREE.Scene();
    scene.background = new THREE.Color(light ? 0xf4f6f9 : 0x0b1018);

    const persp = new THREE.PerspectiveCamera(40, width / viewHeight, 0.05, 20000);
    const ortho = new THREE.OrthographicCamera(-10, 10, 10, -10, -10000, 20000);
    const renderer = new THREE.WebGLRenderer({ antialias: true });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.setSize(width, viewHeight);
    mount.appendChild(renderer.domElement);

    scene.add(new THREE.AmbientLight(0xffffff, light ? 0.8 : 0.55));
    const key = new THREE.DirectionalLight(0xffffff, light ? 0.95 : 1.15);
    key.position.set(1, 2.2, 1.3);
    scene.add(key);
    const fill = new THREE.DirectionalLight(light ? 0xdde8ff : 0x88bbff, 0.4);
    fill.position.set(-1.4, 0.7, -1.2);
    scene.add(fill);

    const S = st.current;
    S.renderer = renderer; S.scene = scene; S.persp = persp; S.ortho = ortho;
    S.meshes = new Map(); S.edges = new Map();

    const bounds = new THREE.Box3();

    for (const el of drawable) {
      const mat = new THREE.MeshLambertMaterial({
        color: colorFor(el.ifcClass), transparent: true,
        opacity: el.excluded ? 0.15 : 0.95, side: THREE.DoubleSide,
      });
      const mesh = buildMesh(el, mat);
      mesh.userData.id = el.id;
      mesh.userData.measured = (el.activities?.length ?? 0) > 0;
      scene.add(mesh);
      S.meshes.set(el.id, mesh);

      // Cada elemento necesita su PROPIO material de aristas (no uno
      // compartido) para poder pintar en verde/rojo la cobertura de
      // cantidades elemento por elemento.
      const eg = new THREE.EdgesGeometry(mesh.geometry, 25);
      const edgeMat = new THREE.LineBasicMaterial({ color: light ? 0x2c3a4d : 0x9fb4c9, transparent: true, opacity: 0.4 });
      const line = new THREE.LineSegments(eg, edgeMat);
      line.position.copy(mesh.position);
      line.quaternion.copy(mesh.quaternion);
      line.rotation.copy(mesh.rotation);
      scene.add(line);
      S.edges.set(el.id, line);

      bounds.expandByObject(mesh);
    }

    const center = bounds.getCenter(new THREE.Vector3());
    const size = bounds.getSize(new THREE.Vector3());
    S.target.copy(center);
    S.sph.radius = Math.max(size.length() * 0.8, 3);

    const grid = new THREE.GridHelper(Math.max(size.x, size.z) * 2 || 20, 20,
      light ? 0xbcc6d2 : 0x1f2a3c, light ? 0xdde3ea : 0x151d2b);
    grid.position.set(center.x, bounds.min.y - 0.01, center.z);
    scene.add(grid);

    const dims = new THREE.Group();
    scene.add(dims);
    S.dims = dims;

    const applyCamera = () => {
      const { radius: r, theta, phi } = S.sph;
      const t = S.target.clone().add(S.pan);
      const w = mount.clientWidth || width;
      if (mode === "3D") {
        persp.position.set(
          t.x + r * Math.sin(phi) * Math.cos(theta),
          t.y + r * Math.cos(phi),
          t.z + r * Math.sin(phi) * Math.sin(theta)
        );
        persp.lookAt(t);
        persp.aspect = w / viewHeight;
        persp.updateProjectionMatrix();
        S.camera = persp;
      } else {
        const aspect = w / viewHeight;
        const half = r * 0.62;
        ortho.left = -half * aspect; ortho.right = half * aspect;
        ortho.top = half; ortho.bottom = -half;
        if (mode === "PLANTA") { ortho.position.set(t.x, t.y + r * 2, t.z + 0.0001); ortho.up.set(0, 0, -1); }
        if (mode === "FRENTE") { ortho.position.set(t.x, t.y, t.z + r * 2); ortho.up.set(0, 1, 0); }
        if (mode === "LADO") { ortho.position.set(t.x + r * 2, t.y, t.z); ortho.up.set(0, 1, 0); }
        ortho.lookAt(t);
        ortho.updateProjectionMatrix();
        S.camera = ortho;
      }
    };
    S.apply = applyCamera;
    applyCamera();

    let dragging: "orbit" | "pan" | null = null;
    let moved = false;
    let lastX = 0, lastY = 0;
    const dom = renderer.domElement;
    dom.style.cursor = "grab";

    const pick = (e: MouseEvent): string | null => {
      const rect = dom.getBoundingClientRect();
      const ray = new THREE.Raycaster();
      ray.setFromCamera(
        new THREE.Vector2(((e.clientX - rect.left) / rect.width) * 2 - 1, -((e.clientY - rect.top) / rect.height) * 2 + 1),
        S.camera as THREE.Camera
      );
      const targets = [...S.meshes.entries()].filter(([id, m]) => m.visible && visibleIds.has(id)).map(([, m]) => m);
      return (ray.intersectObjects(targets, false)[0]?.object.userData.id as string | undefined) ?? null;
    };

    const onDown = (e: PointerEvent) => {
      dragging = e.button === 2 || e.shiftKey || mode !== "3D" ? "pan" : "orbit";
      moved = false; lastX = e.clientX; lastY = e.clientY; dom.style.cursor = "grabbing";
    };
    const onUp = () => { dragging = null; dom.style.cursor = "grab"; };
    const onMove = (e: PointerEvent) => {
      if (dragging) {
        const dx = e.clientX - lastX, dy = e.clientY - lastY;
        if (Math.abs(dx) + Math.abs(dy) > 2) moved = true;
        lastX = e.clientX; lastY = e.clientY;
        if (dragging === "orbit") {
          S.sph.theta -= dx * 0.006;
          S.sph.phi = Math.min(Math.PI - 0.05, Math.max(0.05, S.sph.phi - dy * 0.006));
        } else {
          const f = S.sph.radius * 0.0016;
          if (mode === "PLANTA") S.pan.add(new THREE.Vector3(-dx * f, 0, -dy * f));
          else if (mode === "FRENTE") S.pan.add(new THREE.Vector3(-dx * f, dy * f, 0));
          else if (mode === "LADO") S.pan.add(new THREE.Vector3(0, dy * f, dx * f));
          else S.pan.add(new THREE.Vector3(-dx * f, dy * f, 0));
        }
        applyCamera();
        return;
      }
      const id = pick(e);
      setHover(id ? drawable.find((d) => d.id === id) ?? null : null);
    };
    const onWheel = (e: WheelEvent) => {
      e.preventDefault();
      S.sph.radius = Math.min(Math.max(S.sph.radius * (1 + Math.sign(e.deltaY) * 0.1), 0.4), 50000);
      applyCamera();
    };
    const onClick = (e: MouseEvent) => {
      if (!moved) {
        const id = pick(e);
        setInternalSelected(id);
        onSelect?.(id);
      }
    };
    const onCtx = (e: Event) => e.preventDefault();

    dom.addEventListener("pointerdown", onDown);
    window.addEventListener("pointerup", onUp);
    dom.addEventListener("pointermove", onMove);
    dom.addEventListener("wheel", onWheel, { passive: false });
    dom.addEventListener("click", onClick);
    dom.addEventListener("contextmenu", onCtx);

    const onResize = () => { renderer.setSize(mount.clientWidth || width, viewHeight); applyCamera(); };
    window.addEventListener("resize", onResize);

    const loop = () => {
      S.frame = requestAnimationFrame(loop);
      // Mantener el tamaño de las etiquetas de cota
      if (S.dims && S.camera) {
        const camPos = (S.camera as THREE.Camera).position;
        for (const child of S.dims.children) {
          if (child instanceof THREE.Sprite) {
            const d = camPos.distanceTo(child.position);
            const s = Math.max(d * 0.035, 0.18);
            child.scale.set(s * (child.userData.aspect ?? 3), s, 1);
          }
        }
      }
      if (S.camera) renderer.render(scene, S.camera);
    };
    loop();
    setReady(true);

    return () => {
      if (S.frame) cancelAnimationFrame(S.frame);
      window.removeEventListener("resize", onResize);
      window.removeEventListener("pointerup", onUp);
      dom.removeEventListener("pointerdown", onDown);
      dom.removeEventListener("pointermove", onMove);
      dom.removeEventListener("wheel", onWheel);
      dom.removeEventListener("click", onClick);
      dom.removeEventListener("contextmenu", onCtx);
      renderer.dispose();
      for (const m of S.meshes.values()) { m.geometry.dispose(); (m.material as THREE.Material).dispose(); }
      for (const l of S.edges.values()) { l.geometry.dispose(); (l.material as THREE.Material).dispose(); }
      if (dom.parentNode) dom.parentNode.removeChild(dom);
      setReady(false);
    };
  }, [drawable, viewHeight, mode, light, onSelect, visibleIds]);

  /* ------------- resaltado, visibilidad y cobertura de cantidades ------------- */
  useEffect(() => {
    const S = st.current;
    for (const [id, mesh] of S.meshes) {
      const mat = mesh.material as THREE.MeshLambertMaterial;
      const vis = visibleIds.has(id);
      const sel = effectiveSelectedId === id;
      mesh.visible = vis || showAll;
      const edge = S.edges.get(id) as (THREE.LineSegments & { material: THREE.LineBasicMaterial }) | undefined;
      if (edge) edge.visible = mesh.visible;
      mat.opacity = sel ? 1 : vis ? 0.95 : 0.05;
      mat.emissive = new THREE.Color(sel ? 0x1d9bc4 : 0x000000);
      mat.emissiveIntensity = sel ? 0.7 : 0;
      mat.needsUpdate = true;
      if (edge) {
        if (showMeasured && !sel) {
          const measured = (mesh.userData.measured as boolean) ?? false;
          edge.material.color = new THREE.Color(measured ? 0x2fbf6a : 0xe0525f);
          edge.material.opacity = vis ? 0.9 : 0.15;
        } else {
          edge.material.color = new THREE.Color(light ? 0x2c3a4d : 0x9fb4c9);
          edge.material.opacity = 0.4;
        }
        edge.material.needsUpdate = true;
      }
    }
  }, [effectiveSelectedId, visibleIds, showAll, showMeasured, light, ready]);

  /* ------------- COTAS del elemento seleccionado ------------- */
  useEffect(() => {
    const S = st.current;
    const group = S.dims;
    if (!group) return;
    while (group.children.length) {
      const c = group.children.pop()!;
      if (c instanceof THREE.Sprite) { c.material.map?.dispose(); c.material.dispose(); }
      else if (c instanceof THREE.Line) { c.geometry.dispose(); (c.material as THREE.Material).dispose(); }
    }
    if (!selected || !showDims || !selected.geometry) return;

    const mesh = S.meshes.get(selected.id);
    if (!mesh) return;
    const measureSize = (mesh.userData.measureSize as number[] | undefined) ?? [
      selected.geometry.size[0], selected.geometry.size[2], selected.geometry.size[1],
    ];
    const measureAxes = (mesh.userData.measureAxes as THREE.Vector3[] | undefined) ?? [
      new THREE.Vector3(1, 0, 0), new THREE.Vector3(0, 1, 0), new THREE.Vector3(0, 0, 1),
    ];
    const center = mesh.position.clone();
    const off = Math.max(Math.hypot(...measureSize) * 0.06, 0.12);
    const linear = selected.semanticType === "MIEMBRO_LINEAL_CUBIERTA";
    const labels = linear
      ? ["Longitud inclinada", "Canto de sección", "Ancho de sección"]
      : ["Eje principal", "Altura / canto", "Profundidad / espesor"];
    const colors = [
      { color: 0xd6455b, css: "#d6455b" },
      { color: 0x2a7fc9, css: "#2a7fc9" },
      { color: 0x1f9e6b, css: "#1f9e6b" },
    ];
    const AXES: { from: THREE.Vector3; to: THREE.Vector3; label: string; color: number; css: string }[] =
      measureAxes.map((axis, i) => {
        const dir = axis.clone().normalize();
        const side1 = measureAxes[(i + 1) % 3].clone().normalize().multiplyScalar(off);
        const side2 = measureAxes[(i + 2) % 3].clone().normalize().multiplyScalar(off);
        const mid = center.clone().add(side1).add(side2);
        return {
          from: mid.clone().addScaledVector(dir, -measureSize[i] / 2),
          to: mid.clone().addScaledVector(dir, measureSize[i] / 2),
          label: `${labels[i]} ${fmt(measureSize[i], 3)} m`,
          ...colors[i],
        };
      });

    const bg = light ? "#ffffffee" : "#0e131cee";
    for (const a of AXES) {
      const mat = new THREE.LineBasicMaterial({ color: a.color, depthTest: false, linewidth: 2 });
      const geo = new THREE.BufferGeometry().setFromPoints([a.from, a.to]);
      const line = new THREE.Line(geo, mat);
      line.renderOrder = 998;
      group.add(line);

      // marcas en los extremos
      for (const p of [a.from, a.to]) {
        const tickDir = new THREE.Vector3().subVectors(a.to, a.from).normalize();
        const perp = new THREE.Vector3(-tickDir.y, tickDir.x, tickDir.z).normalize().multiplyScalar(off * 0.25);
        const tg = new THREE.BufferGeometry().setFromPoints([
          p.clone().sub(perp), p.clone().add(perp),
        ]);
        const tl = new THREE.Line(tg, mat);
        tl.renderOrder = 998;
        group.add(tl);
      }

      const sprite = makeLabel(a.label, a.css, bg);
      sprite.position.copy(a.from.clone().add(a.to).multiplyScalar(0.5));
      group.add(sprite);
    }
  }, [selected, showDims, light, ready]);

  const fit = useCallback((onlyVisible: boolean) => {
    const S = st.current;
    const box = new THREE.Box3();
    for (const [id, m] of S.meshes) {
      if (onlyVisible && !visibleIds.has(id)) continue;
      box.expandByObject(m);
    }
    if (box.isEmpty()) return;
    S.target.copy(box.getCenter(new THREE.Vector3()));
    S.pan.set(0, 0, 0);
    S.sph.radius = Math.max(box.getSize(new THREE.Vector3()).length() * 0.8, 1.5);
    S.apply?.();
  }, [visibleIds]);

  const focusSelected = useCallback(() => {
    const S = st.current;
    if (!effectiveSelectedId) return fit(true);
    const m = S.meshes.get(effectiveSelectedId);
    if (!m) return;
    const box = new THREE.Box3().setFromObject(m);
    S.target.copy(box.getCenter(new THREE.Vector3()));
    S.pan.set(0, 0, 0);
    S.sph.radius = Math.max(box.getSize(new THREE.Vector3()).length() * 1.6, 1.2);
    S.apply?.();
  }, [effectiveSelectedId, fit]);

  const resetView = () => {
    const S = st.current;
    S.sph.theta = Math.PI / 4;
    S.sph.phi = Math.PI / 3.4;
    S.pan.set(0, 0, 0);
    fit(false);
  };

  if (drawable.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center gap-2 rounded-xl border border-dashed border-line-strong bg-ink-850/60 px-6 py-12 text-center">
        <BoxIcon size={22} className="text-fog" />
        <p className="text-xs font-semibold text-slate-200">Sin geometría representable</p>
        <p className="max-w-md text-[11px] text-mist">
          Estos elementos no traen geometría interpretable en el IFC. La medición deberá apoyarse en cantidades IFC,
          propiedades o medición manual.
        </p>
      </div>
    );
  }

  const info = selected ?? hover;
  const infoFace = info?.geometry?.face;
  const infoOpenings = info?.geometry?.openings ?? [];

  return (
    <div className={cx("overflow-hidden rounded-xl border border-line", expanded && "fixed inset-3 z-50 bg-ink-900 shadow-2xl")}>
      <div className="flex flex-wrap items-center gap-1.5 border-b border-line bg-ink-800/80 px-2.5 py-2">
        {title && <span className="mr-1 text-[11px] font-bold text-white">{title}</span>}
        <div className="flex overflow-hidden rounded-lg border border-line-strong">
          {(["3D", "PLANTA", "FRENTE", "LADO"] as ViewMode[]).map((m) => (
            <button key={m} onClick={() => setMode(m)}
              className={cx("px-2.5 py-1 text-[10.5px] font-bold transition-colors",
                mode === m ? "bg-acc text-ink-950" : "bg-ink-800 text-mist hover:text-white")}>
              {m === "3D" ? "3D cónica" : m === "PLANTA" ? "Planta" : m === "FRENTE" ? "Alzado" : "Lateral"}
            </button>
          ))}
        </div>
        {(levels.length > 0 || classes.length > 1) && (
          <button onClick={() => setLayersOpen(!layersOpen)} title="Apagar/encender niveles y clases de elementos"
            className={cx("flex items-center gap-1 rounded-lg border border-line-strong px-2 py-1.5 text-[10.5px] font-bold",
              layersOpen || hiddenLevels.size > 0 || hiddenClasses.size > 0 ? "bg-acc/15 text-acc" : "bg-ink-800 text-mist hover:text-acc")}>
            <Layers size={13} /> Capas
            {(hiddenLevels.size + hiddenClasses.size) > 0 && (
              <span className="rounded-full bg-acc/25 px-1.5 font-mono text-[9.5px]">{hiddenLevels.size + hiddenClasses.size} apagadas</span>
            )}
          </button>
        )}
        <button onClick={() => setShowMeasured(!showMeasured)}
          title="Colorear en el borde qué elementos ya tienen una cantidad registrada"
          className={cx("flex items-center gap-1 rounded-lg border border-line-strong px-2 py-1.5 text-[10.5px] font-bold",
            showMeasured ? "bg-emerald-500/15 text-emerald-300" : "bg-ink-800 text-mist hover:text-acc")}>
          <PackageCheck size={13} /> Cantidades
          {showMeasured && <span className="font-mono text-[9.5px] opacity-80">{measuredCount}/{drawable.length}</span>}
        </button>
        <button onClick={() => setShowDims(!showDims)} title="Mostrar cotas del elemento seleccionado"
          className={cx("rounded-lg border border-line-strong p-1.5", showDims ? "bg-acc/15 text-acc" : "bg-ink-800 text-mist hover:text-acc")}>
          <Ruler size={13} />
        </button>
        <button onClick={() => setShowAll(!showAll)} title={showAll ? "Ocultar lo no filtrado" : "Mostrar todo atenuado"}
          className="rounded-lg border border-line-strong bg-ink-800 p-1.5 text-mist hover:text-acc">
          {showAll ? <Eye size={13} /> : <EyeOff size={13} />}
        </button>
        <button onClick={focusSelected} title="Centrar en la selección"
          className="rounded-lg border border-line-strong bg-ink-800 p-1.5 text-mist hover:text-acc"><Focus size={13} /></button>
        <button onClick={resetView} title="Ver todo el modelo"
          className="rounded-lg border border-line-strong bg-ink-800 p-1.5 text-mist hover:text-acc"><RotateCcw size={13} /></button>
        <button onClick={() => setLight(!light)} title={light ? "Fondo oscuro" : "Fondo claro"}
          className="rounded-lg border border-line-strong bg-ink-800 p-1.5 text-mist hover:text-acc">
          {light ? <Moon size={13} /> : <Sun size={13} />}
        </button>
        <button onClick={() => setExpanded(!expanded)} title={expanded ? "Reducir" : "Pantalla completa"}
          className="ml-auto rounded-lg border border-line-strong bg-ink-800 p-1.5 text-mist hover:text-acc">
          {expanded ? <Minimize2 size={13} /> : <Maximize2 size={13} />}
        </button>
      </div>

      {measurement && (
        <div className="flex flex-wrap items-center gap-2 border-b border-line bg-ink-850 px-2.5 py-2">
          <span className="text-[10px] font-bold uppercase tracking-wider text-fog">Cómo se mide este grupo</span>
          {measurement.method === "SUPERFICIE_GEOMETRICA" && (
            <select value={measureDraft.areaBasis ?? "NETA"}
              onChange={(e) => setMeasureDraft({ ...measureDraft, areaBasis: e.target.value })}
              className="rounded-md border border-line-strong bg-ink-800 px-2 py-1 text-[10.5px] text-slate-200">
              <option value="NETA">Área neta (descontar vanos)</option>
              <option value="BRUTA">Área bruta de la cara real</option>
              <option value="UNA_CARA">Una cara</option>
              <option value="DOS_CARAS">Dos caras</option>
              <option value="PLANTA">Proyección en planta</option>
              <option value="LATERAL">Superficie lateral</option>
              <option value="SUPERFICIE_TOTAL">Superficie total</option>
            </select>
          )}
          {measurement.method === "DIMENSION" && (
            <select value={measureDraft.dimension ?? "LARGO"}
              onChange={(e) => setMeasureDraft({ ...measureDraft, dimension: e.target.value })}
              className="rounded-md border border-line-strong bg-ink-800 px-2 py-1 text-[10.5px] text-slate-200">
              <option value="LARGO">Longitud del eje principal</option>
              <option value="ALTO">Canto / altura de sección</option>
              <option value="ANCHO">Ancho de sección</option>
              <option value="ESPESOR">Espesor</option>
              <option value="PERIMETRO">Perímetro</option>
            </select>
          )}
          {measurement.method === "VOLUMEN_GEOMETRICO" && (
            <select value={measureDraft.volumeBasis ?? "NETO"}
              onChange={(e) => setMeasureDraft({ ...measureDraft, volumeBasis: e.target.value })}
              className="rounded-md border border-line-strong bg-ink-800 px-2 py-1 text-[10.5px] text-slate-200">
              <option value="NETO">Volumen neto</option>
              <option value="BRUTO">Volumen bruto</option>
            </select>
          )}
          <label className="flex items-center gap-1 text-[10px] text-mist">
            Factor
            <input type="number" min="0.001" step="0.1" value={measureDraft.factor ?? 1}
              onChange={(e) => setMeasureDraft({ ...measureDraft, factor: Number(e.target.value) || 1 })}
              className="w-16 rounded-md border border-line-strong bg-ink-800 px-1.5 py-1 font-mono text-[10.5px] text-slate-200" />
          </label>
          <span className="font-mono text-[11px] font-bold text-white">
            Actual: {fmt(measurement.value, 3)} {measurement.unit}
          </span>
          <button disabled={applyingMeasure}
            onClick={async () => {
              setApplyingMeasure(true);
              try { await measurement.onApply(measureDraft); } finally { setApplyingMeasure(false); }
            }}
            className="ml-auto rounded-md border border-acc/50 bg-acc/15 px-2.5 py-1 text-[10.5px] font-bold text-acc hover:bg-acc/25 disabled:opacity-40">
            {applyingMeasure ? "Recalculando…" : `Aplicar a los ${elements.length} elementos`}
          </button>
        </div>
      )}

      {layersOpen && (levels.length > 0 || classes.length > 1) && (
        <div className="flex flex-wrap items-start gap-4 border-b border-line bg-ink-850 px-2.5 py-2">
          {levels.length > 0 && (
            <div className="flex flex-wrap items-center gap-1.5">
              <span className="mr-1 text-[10px] font-bold uppercase tracking-wider text-fog">Niveles</span>
              {levels.map((lvl) => {
                const off = hiddenLevels.has(lvl);
                return (
                  <button key={lvl}
                    onClick={() => setHiddenLevels((cur) => {
                      const next = new Set(cur);
                      if (next.has(lvl)) next.delete(lvl); else next.add(lvl);
                      return next;
                    })}
                    title={`${off ? "Encender" : "Apagar"} nivel ${lvl}`}
                    className={cx("inline-flex items-center gap-1 rounded-md border px-2 py-1 text-[10px] font-semibold transition-colors",
                      off ? "border-line bg-ink-800 text-fog line-through" : "border-acc/35 bg-acc/10 text-acc")}>
                    {off ? <EyeOff size={10} /> : <Eye size={10} />} {lvl}
                  </button>
                );
              })}
            </div>
          )}
          {classes.length > 1 && (
            <div className="flex flex-wrap items-center gap-1.5">
              <span className="mr-1 text-[10px] font-bold uppercase tracking-wider text-fog">Clases IFC</span>
              {classes.map((c) => {
                const off = hiddenClasses.has(c);
                return (
                  <button key={c}
                    onClick={() => setHiddenClasses((cur) => {
                      const next = new Set(cur);
                      if (next.has(c)) next.delete(c); else next.add(c);
                      return next;
                    })}
                    title={`${off ? "Encender" : "Apagar"} ${c}`}
                    className={cx("inline-flex items-center gap-1 rounded-md border px-2 py-1 text-[10px] font-semibold transition-colors",
                      off ? "border-line bg-ink-800 text-fog line-through" : "border-acc/35 bg-acc/10 text-acc")}>
                    {off ? <EyeOff size={10} /> : <Eye size={10} />} {c.replace(/^IFC/, "Ifc")}
                  </button>
                );
              })}
            </div>
          )}
          {(hiddenLevels.size > 0 || hiddenClasses.size > 0) && (
            <button onClick={() => { setHiddenLevels(new Set()); setHiddenClasses(new Set()); }}
              className="ml-auto text-[10px] font-semibold text-mist hover:text-acc">
              Encender todas las capas
            </button>
          )}
        </div>
      )}

      {activityChoices.length > 0 && (
        <div className="flex flex-wrap items-center gap-1.5 border-b border-line bg-ink-850 px-2.5 py-1.5">
          <span className="mr-1 text-[10px] font-bold uppercase tracking-wider text-fog">Actividades visibles</span>
          {activityChoices.map((a) => {
            const off = hiddenActivities.has(a.id);
            return (
              <button key={a.id}
                onClick={() => setHiddenActivities((current) => {
                  const next = new Set(current);
                  if (next.has(a.id)) next.delete(a.id); else next.add(a.id);
                  return next;
                })}
                title={`${off ? "Encender" : "Apagar"} ${a.code} — ${a.name}`}
                className={cx(
                  "inline-flex max-w-64 items-center gap-1 rounded-md border px-2 py-1 text-[10px] font-semibold transition-colors",
                  off
                    ? "border-line bg-ink-800 text-fog line-through"
                    : "border-acc/35 bg-acc/10 text-acc"
                )}>
                {off ? <EyeOff size={10} /> : <Eye size={10} />}
                <span className="font-mono">{a.code}</span>
                <span className="truncate">{a.name}</span>
                <span className="font-mono opacity-70">({a.count})</span>
              </button>
            );
          })}
          {hiddenActivities.size > 0 && (
            <button onClick={() => setHiddenActivities(new Set())} className="ml-auto text-[10px] font-semibold text-mist hover:text-acc">
              Encender todas
            </button>
          )}
        </div>
      )}

      <div className="relative">
        <div ref={mountRef} style={{ height: viewHeight }} />

        <div className="pointer-events-none absolute left-3 top-3 flex max-w-xs flex-col gap-1.5">
          <Chip className={cx("border-line-strong backdrop-blur", light ? "bg-white/85 text-slate-700" : "bg-ink-900/85 text-mist")}>
            <Layers size={11} /> {visibleIds.size} de {drawable.length} elementos
          </Chip>
          {info && (
            <div className={cx("rounded-lg border px-2.5 py-2 backdrop-blur",
              light ? "border-slate-300 bg-white/95" : "border-acc/40 bg-ink-900/95")}>
              <p className={cx("truncate text-[11px] font-bold", light ? "text-slate-900" : "text-white")}>
                {info.name ?? "(sin nombre)"}
              </p>
              <p className="font-mono text-[10px] text-acc">{info.ifcClass}</p>
              {info.geometry && (
                <div className="mt-1 space-y-0.5 font-mono text-[10px]">
                  {info.geometry.oriented ? (
                    <>
                      <p className={light ? "text-rose-600" : "text-rose-300"}>Longitud inclinada: {fmt(info.geometry.oriented.size[0], 3)} m</p>
                      <p className={light ? "text-sky-600" : "text-sky-300"}>Canto: {fmt(info.geometry.oriented.size[1], 3)} m</p>
                      <p className={light ? "text-emerald-600" : "text-emerald-300"}>Ancho: {fmt(info.geometry.oriented.size[2], 3)} m</p>
                    </>
                  ) : (
                    <>
                      <p className={light ? "text-rose-600" : "text-rose-300"}>X: {fmt(info.geometry.size[0], 3)} m</p>
                      <p className={light ? "text-emerald-600" : "text-emerald-300"}>Y: {fmt(info.geometry.size[1], 3)} m</p>
                      <p className={light ? "text-sky-600" : "text-sky-300"}>Z: {fmt(info.geometry.size[2], 3)} m</p>
                    </>
                  )}
                </div>
              )}
              {infoFace?.clipped && (
                <p className={cx("mt-1 flex items-center gap-1 text-[10px] font-semibold", light ? "text-amber-700" : "text-amber-300")}>
                  <Scissors size={10} /> Cara recortada por un plano: el área NO es rectangular
                </p>
              )}
              {infoOpenings.length > 0 && (
                <p className={cx("mt-1 flex items-center gap-1 text-[10px]", light ? "text-violet-700" : "text-violet-300")}>
                  <SquareDashedBottom size={10} /> {infoOpenings.length} vano(s) ={" "}
                  {fmt(infoOpenings.reduce((a, o) => a + o.area, 0), 2)} m² descontados
                </p>
              )}
              {info.dimensions?.grossArea != null && (
                <p className={cx("mt-1 text-[10px]", light ? "text-slate-600" : "text-mist")}>
                  Área bruta {fmt(info.dimensions.grossArea, 2)} m² · neta {fmt(info.dimensions.netArea, 2)} m²
                </p>
              )}
              {(info.activities?.length ?? 0) > 0 ? (
                <div className={cx("mt-1.5 border-t pt-1", light ? "border-slate-200" : "border-line")}>
                  <p className={cx("flex items-center gap-1 text-[9px] font-bold uppercase tracking-wider", light ? "text-emerald-700" : "text-emerald-300")}>
                    <PackageCheck size={10} /> Ya medido en {info.activities!.length} actividad(es)
                  </p>
                  {info.activities!.map((a) => (
                    <p key={a.id} className={cx("truncate text-[10px]", light ? "text-slate-700" : "text-slate-300")}>
                      <span className="font-mono font-bold">{a.code}</span> · {a.name}
                    </p>
                  ))}
                </div>
              ) : (
                <div className={cx("mt-1.5 flex items-center gap-1 border-t pt-1 text-[9.5px] font-semibold", light ? "border-slate-200 text-rose-600" : "border-line text-rose-300")}>
                  <PackageX size={10} /> Sin cantidad registrada todavía
                </div>
              )}
            </div>
          )}
        </div>

        {showMeasured && (
          <div className={cx("pointer-events-none absolute right-3 top-3 flex items-center gap-2 rounded-md border px-2 py-1 text-[10px] backdrop-blur",
            light ? "border-slate-300 bg-white/85 text-slate-600" : "border-line-strong bg-ink-900/85 text-mist")}>
            <span className="flex items-center gap-1"><span className="h-2 w-2 rounded-full bg-emerald-500" /> con cantidad</span>
            <span className="flex items-center gap-1"><span className="h-2 w-2 rounded-full bg-rose-500" /> sin cantidad</span>
          </div>
        )}

        <div className={cx("pointer-events-none absolute bottom-2 left-3 flex flex-wrap items-center gap-2 rounded-md px-2 py-1 text-[10px] backdrop-blur",
          light ? "bg-white/80 text-slate-600" : "bg-ink-900/80 text-fog")}>
          <Ruler size={11} />
          <span className={light ? "text-rose-600" : "text-rose-300"}>X ancho</span>
          <span className={light ? "text-emerald-600" : "text-emerald-300"}>Y fondo</span>
          <span className={light ? "text-sky-600" : "text-sky-300"}>Z alto</span>
          <span className="opacity-70">· clic: seleccionar y acotar · arrastrar: girar · Shift: desplazar · rueda: zoom</span>
        </div>
        <div className={cx("pointer-events-none absolute bottom-2 right-3 flex items-center gap-1 rounded-md px-2 py-1 text-[10px] backdrop-blur",
          light ? "bg-white/80 text-slate-500" : "bg-ink-900/80 text-fog")}>
          <Grid3x3 size={10} /> {mode === "3D" ? "Perspectiva cónica" : "Proyección ortogonal"}
        </div>
      </div>
    </div>
  );
}
