"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { ArrowLeft, Printer, FileText, ClipboardList, Loader2 } from "lucide-react";
import { Btn, cx } from "@/components/ui";
import { api, fmt, METHOD_META, nuevaFecha } from "@/lib/client";

interface Doc {
  proyecto: { codigo: string; nombre: string; cliente: string | null; ubicacion: string | null; descripcion: string | null };
  empresa: { name?: string; nit?: string; address?: string; phone?: string; email?: string; responsible?: string; role?: string; license?: string; logo?: string };
  ajustes: { notes?: string; currency?: string; ivaSobreUtilidad?: boolean };
  plantilla: {
    budgetTitle: string; budgetSubtitle: string; budgetIntroduction: string; budgetScope: string;
    reportTitle: string; reportSubtitle: string; reportIntroduction: string; reportScope: string;
    sourcesTitle: string; decisionsTitle: string; observationsTitle: string;
    footerText: string; preparedByLabel: string; reviewedByLabel: string;
    showCompany: boolean; showPrices: boolean; showAIU: boolean;
  };
  presupuesto: {
    capitulos: { codigo: string; nombre: string; total: number; sections: { codigo: string; nombre: string; total: number; items: { codigo: string; nombre: string; unidad: string; cantidad: number; precioUnitario: number; total: number; sinPrecio: boolean }[] }[] }[];
    costoDirecto: number; administracion: number; imprevistos: number; utilidad: number; iva: number; total: number; moneda: string;
    porcentajes?: { administracion: number; imprevistos: number; utilidad: number; iva: number };
    ivaBaseTexto?: string; baseIva?: number;
  };
  informe: {
    resumen: {
      fuentes: number; fuentesIfc: number; elementos: number; elementosExcluidos: number;
      cantidadesTotales: number; cantidadesValidadas: number; cantidadesPropuestas: number;
      cantidadesPendientes: number; cantidadesRechazadas: number; decisiones: number;
      metodos: { metodo: string; lineas: number; cantidad: number }[];
    };
    fuentes: { nombre: string; tipo: string; disciplina: string | null; archivo: string | null; esquema: string | null; elementos: number | null; advertencias: string[] }[];
    agrupaciones: { fecha: string; actor: string | null; detalle: Record<string, unknown> | null }[];
    cambiosActividad: { fecha: string; actor: string | null; accion: string; detalle: Record<string, unknown> | null }[];
    cambiosRegla: { fecha: string; actor: string | null; detalle: Record<string, unknown> | null }[];
    correcciones: { fecha: string; actor: string | null; detalle: Record<string, unknown> | null }[];
    derivaciones: { fecha: string; actor: string | null; detalle: Record<string, unknown> | null }[];
    rechazos: { fecha: string; actor: string | null; accion: string; detalle: Record<string, unknown> | null }[];
    exclusiones: { fecha: string; actor: string | null; accion: string; detalle: Record<string, unknown> | null }[];
    manuales: { fecha: string; actor: string | null; detalle: Record<string, unknown> | null }[];
    cantidadesObservadas: {
      actividad: string; cantidad: number | null; unidad: string; estado: string; metodo: string;
      regla: string | null; elementos: number; origen: string | null; nota: string | null;
      advertencias: string[]; elementosSinDato: number;
      correccion: Record<string, unknown> | null; derivada: Record<string, unknown> | null;
      validadaPor: string | null; validadaEn: string | null;
    }[];
  };
}

const PRINT_CSS = `
@page { size: A4; margin: 14mm 12mm 16mm 12mm; }
@media print {
  .no-print { display: none !important; }
  .doc-sheet { box-shadow: none !important; margin: 0 !important; border: 0 !important; width: 100% !important; }
  .page-break { page-break-before: always; }
  thead { display: table-header-group; }
  tr { page-break-inside: avoid; }
}
`;

export function Documentos({ projectId }: { projectId: string }) {
  const [doc, setDoc] = useState<Doc | null>(null);
  const [tab, setTab] = useState<"presupuesto" | "informe">("presupuesto");
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    api<Doc>(`/api/documents?projectId=${projectId}`).then(setDoc).catch((e) => setError(e.message));
  }, [projectId]);

  const money = (n: number) => `$ ${fmt(n, 0)}`;
  const fecha = new Date().toLocaleDateString("es-ES", { day: "2-digit", month: "long", year: "numeric" });

  if (error) return <div className="p-10 text-center text-sm text-rose-500">{error}</div>;
  if (!doc) {
    return (
      <div className="flex min-h-screen items-center justify-center gap-2 text-slate-500">
        <Loader2 size={16} className="animate-spin" /> Preparando documentos…
      </div>
    );
  }

  const { proyecto, empresa, presupuesto, informe, ajustes } = doc;
  const T = doc.plantilla;
  const obs = informe.cantidadesObservadas;

  return (
    <div className="min-h-screen bg-slate-200 pb-16">
      <style dangerouslySetInnerHTML={{ __html: PRINT_CSS }} />

      {/* Barra de control */}
      <div className="no-print sticky top-0 z-30 border-b border-line bg-ink-900/95 backdrop-blur">
        <div className="mx-auto flex max-w-[1100px] flex-wrap items-center gap-3 px-4 py-3">
          <Link href={`/proyectos/${projectId}`} className="flex items-center gap-1.5 text-xs font-semibold text-mist hover:text-acc">
            <ArrowLeft size={14} /> Volver al proyecto
          </Link>
          <div className="flex gap-1">
            {([["presupuesto", "Presupuesto preliminar", FileText], ["informe", "Informe de trazabilidad", ClipboardList]] as const).map(([k, l, Icon]) => (
              <button key={k} onClick={() => setTab(k)}
                className={cx("flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-xs font-semibold transition-colors",
                  tab === k ? "bg-acc/15 text-acc" : "text-mist hover:text-white")}>
                <Icon size={13} /> {l}
              </button>
            ))}
          </div>
          <Btn variant="primary" icon={Printer} className="ml-auto" onClick={() => window.print()}>
            Imprimir / Guardar PDF
          </Btn>
        </div>
      </div>

      {/* Hoja */}
      <div className="mx-auto mt-6 max-w-[1100px] px-4">
        <div className="doc-sheet mx-auto bg-white p-10 text-[11px] leading-relaxed text-slate-800 shadow-2xl" style={{ fontFamily: "var(--font-sans)" }}>

          {/* ---------- ENCABEZADO ---------- */}
          <header className="mb-6 flex items-start justify-between gap-6 border-b-2 border-slate-800 pb-4">
            <div className="flex items-start gap-4">
              {T.showCompany && empresa.logo ? (
                // eslint-disable-next-line @next/next/no-img-element
                <img src={empresa.logo} alt="Logo" className="h-16 w-auto object-contain" />
              ) : null}
              <div>
                <h1 className="text-base font-extrabold uppercase tracking-tight text-slate-900">
                  {T.showCompany ? (empresa.name || "Empresa constructora") : proyecto.nombre}
                </h1>
                <div className="mt-0.5 space-y-0.5 text-[10px] text-slate-600">
                  {empresa.nit && <p>NIT: {empresa.nit}</p>}
                  {empresa.address && <p>{empresa.address}</p>}
                  {(empresa.phone || empresa.email) && <p>{[empresa.phone, empresa.email].filter(Boolean).join(" · ")}</p>}
                </div>
              </div>
            </div>
            <div className="text-right">
              <p className="text-[9px] font-bold uppercase tracking-[0.2em] text-slate-500">
                {tab === "presupuesto" ? T.budgetTitle : T.reportTitle}
              </p>
              <p className="max-w-64 text-[9px] leading-snug text-slate-500">
                {tab === "presupuesto" ? T.budgetSubtitle : T.reportSubtitle}
              </p>
              <p className="mt-1 font-mono text-sm font-bold text-slate-900">{proyecto.codigo}</p>
              <p className="text-[10px] text-slate-600">{fecha}</p>
              <p className="mt-1 text-[9px] text-slate-500">Generado con BIMCost Quantity</p>
            </div>
          </header>

          <section className="mb-6 grid grid-cols-2 gap-x-8 gap-y-1 rounded border border-slate-300 bg-slate-50 p-3 text-[10.5px]">
            <p><span className="font-bold text-slate-700">Proyecto:</span> {proyecto.nombre}</p>
            <p><span className="font-bold text-slate-700">Cliente:</span> {proyecto.cliente || "—"}</p>
            <p><span className="font-bold text-slate-700">Ubicación:</span> {proyecto.ubicacion || "—"}</p>
            <p><span className="font-bold text-slate-700">Responsable:</span> {empresa.responsible || "—"}{empresa.role ? ` · ${empresa.role}` : ""}</p>
          </section>

          {/* ---------- PRESUPUESTO ---------- */}
          {tab === "presupuesto" && (
            <>
              {T.budgetIntroduction && (
                <p className="mb-4 text-[10.5px] leading-relaxed text-slate-700">{T.budgetIntroduction}</p>
              )}
              <table className="w-full border-collapse text-[10.5px]">
                <thead>
                  <tr className="bg-slate-800 text-white">
                    <th className="border border-slate-700 px-2 py-1.5 text-left font-semibold">Código</th>
                    <th className="border border-slate-700 px-2 py-1.5 text-left font-semibold">Descripción</th>
                    <th className="w-16 border border-slate-700 px-2 py-1.5 text-center font-semibold">Unidad</th>
                    <th className="w-24 border border-slate-700 px-2 py-1.5 text-right font-semibold">Cantidad</th>
                    {T.showPrices && <th className="w-28 border border-slate-700 px-2 py-1.5 text-right font-semibold">Vr. unitario</th>}
                    {T.showPrices && <th className="w-32 border border-slate-700 px-2 py-1.5 text-right font-semibold">Vr. total</th>}
                  </tr>
                </thead>
                <tbody>
                  {presupuesto.capitulos.map((ch) => (
                    <>
                      <tr key={ch.codigo} className="bg-slate-200 font-bold text-slate-900">
                        <td className="border border-slate-300 px-2 py-1.5 font-mono">{ch.codigo}</td>
                        <td className="border border-slate-300 px-2 py-1.5 uppercase" colSpan={4}>{ch.nombre}</td>
                        <td className="border border-slate-300 px-2 py-1.5 text-right font-mono">{money(ch.total)}</td>
                      </tr>
                      {ch.sections.map((s) => (
                        <>
                          <tr key={s.codigo} className="bg-slate-100 text-slate-700">
                            <td className="border border-slate-300 px-2 py-1 font-mono text-[10px]">{s.codigo}</td>
                            <td className="border border-slate-300 px-2 py-1 text-[10px] font-semibold" colSpan={4}>{s.nombre}</td>
                            <td className="border border-slate-300 px-2 py-1 text-right font-mono text-[10px]">{money(s.total)}</td>
                          </tr>
                          {s.items.map((it) => (
                            <tr key={it.codigo}>
                              <td className="border border-slate-300 px-2 py-1 font-mono text-[10px]">{it.codigo}</td>
                              <td className="border border-slate-300 px-2 py-1">{it.nombre}</td>
                              <td className="border border-slate-300 px-2 py-1 text-center font-mono text-[10px]">{it.unidad}</td>
                              <td className="border border-slate-300 px-2 py-1 text-right font-mono tabular-nums">{fmt(it.cantidad, it.unidad === "M3" ? 3 : 2)}</td>
                              {T.showPrices && (
                                <td className="border border-slate-300 px-2 py-1 text-right font-mono tabular-nums">
                                  {it.sinPrecio ? <span className="text-amber-700">sin precio</span> : money(it.precioUnitario)}
                                </td>
                              )}
                              {T.showPrices && (
                                <td className="border border-slate-300 px-2 py-1 text-right font-mono tabular-nums font-semibold">{money(it.total)}</td>
                              )}
                            </tr>
                          ))}
                        </>
                      ))}
                    </>
                  ))}
                </tbody>
              </table>

              {T.showAIU && (
              <table className="mt-5 ml-auto w-80 border-collapse text-[11px]">
                <tbody>
                  {([
                    { l: "Costo directo", v: presupuesto.costoDirecto, strong: false },
                    { l: `Administración ${presupuesto.porcentajes?.administracion ?? 0}%`, v: presupuesto.administracion, strong: false },
                    { l: `Imprevistos ${presupuesto.porcentajes?.imprevistos ?? 0}%`, v: presupuesto.imprevistos, strong: false },
                    { l: `Utilidad ${presupuesto.porcentajes?.utilidad ?? 0}%`, v: presupuesto.utilidad, strong: false },
                    { l: `IVA ${presupuesto.porcentajes?.iva ?? 0}% sobre ${presupuesto.ivaBaseTexto ?? "utilidad"}`, v: presupuesto.iva, strong: false },
                    { l: "TOTAL PRESUPUESTO", v: presupuesto.total, strong: true },
                  ]).map(({ l, v, strong }) => (
                    <tr key={l} className={strong ? "bg-slate-800 text-white" : ""}>
                      <td className={cx("border border-slate-300 px-2 py-1.5", strong ? "font-extrabold" : "font-semibold text-slate-700")}>{l}</td>
                      <td className={cx("border border-slate-300 px-2 py-1.5 text-right font-mono tabular-nums", strong && "font-extrabold")}>
                        {money(v)}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
              )}

              <div className="mt-6 rounded border border-slate-300 bg-slate-50 p-3 text-[9.5px] leading-relaxed text-slate-600">
                <p className="font-bold text-slate-700">Alcance de este documento</p>
                <p className="mt-1">{T.budgetScope}</p>
                <p className="mt-1">{T.footerText}</p>
                {ajustes.notes ? <p className="mt-2 italic">{ajustes.notes}</p> : null}
              </div>

              <div className="mt-12 flex justify-between gap-10">
                {[[T.preparedByLabel, empresa.responsible, empresa.role, empresa.license], [T.reviewedByLabel, "", "", ""]].map(([rol, nombre, cargo, lic], i) => (
                  <div key={i} className="flex-1">
                    <div className="border-t border-slate-500 pt-1 text-[10px]">
                      <p className="font-bold text-slate-700">{rol}</p>
                      <p className="text-slate-600">{nombre || "\u00A0"}</p>
                      <p className="text-[9px] text-slate-500">{cargo || "\u00A0"}{lic ? ` · M.P. ${lic}` : ""}</p>
                    </div>
                  </div>
                ))}
              </div>
            </>
          )}

          {/* ---------- INFORME ---------- */}
          {tab === "informe" && (
            <>
              {T.reportIntroduction && (
                <p className="mb-4 text-[10.5px] leading-relaxed text-slate-700">{T.reportIntroduction}</p>
              )}
              <Section title="1. Resumen del cómputo">
                <div className="grid grid-cols-4 gap-2">
                  {[
                    ["Fuentes de información", informe.resumen.fuentes],
                    ["Modelos IFC", informe.resumen.fuentesIfc],
                    ["Elementos leídos", informe.resumen.elementos],
                    ["Elementos excluidos", informe.resumen.elementosExcluidos],
                    ["Cantidades validadas", informe.resumen.cantidadesValidadas],
                    ["En propuesta", informe.resumen.cantidadesPropuestas],
                    ["Pendientes", informe.resumen.cantidadesPendientes],
                    ["Decisiones registradas", informe.resumen.decisiones],
                  ].map(([l, v]) => (
                    <div key={String(l)} className="rounded border border-slate-300 bg-slate-50 px-2 py-1.5">
                      <p className="font-mono text-base font-bold text-slate-900">{String(v)}</p>
                      <p className="text-[9px] uppercase tracking-wide text-slate-500">{String(l)}</p>
                    </div>
                  ))}
                </div>
                {informe.resumen.metodos.length > 0 && (
                  <p className="mt-2 text-[10px] text-slate-600">
                    <span className="font-semibold">Métodos de medición empleados:</span>{" "}
                    {informe.resumen.metodos.map((m) => `${METHOD_META[m.metodo]?.label ?? m.metodo} (${m.lineas} líneas)`).join(" · ")}
                  </p>
                )}
              </Section>

              <Section title={`2. ${T.sourcesTitle}`}>
                <table className="w-full border-collapse text-[10px]">
                  <thead><tr className="bg-slate-100">
                    <th className="border border-slate-300 px-2 py-1 text-left">Fuente</th>
                    <th className="border border-slate-300 px-2 py-1 text-left">Tipo</th>
                    <th className="border border-slate-300 px-2 py-1 text-left">Archivo</th>
                    <th className="border border-slate-300 px-2 py-1 text-right">Elementos</th>
                    <th className="border border-slate-300 px-2 py-1 text-left">Observaciones</th>
                  </tr></thead>
                  <tbody>
                    {informe.fuentes.map((f, i) => (
                      <tr key={i}>
                        <td className="border border-slate-300 px-2 py-1 font-semibold">{f.nombre}</td>
                        <td className="border border-slate-300 px-2 py-1">{f.tipo}{f.disciplina ? ` · ${f.disciplina}` : ""}</td>
                        <td className="border border-slate-300 px-2 py-1 font-mono text-[9px]">{f.archivo ?? "—"}{f.esquema ? ` (${f.esquema})` : ""}</td>
                        <td className="border border-slate-300 px-2 py-1 text-right font-mono">{f.elementos ?? "—"}</td>
                        <td className="border border-slate-300 px-2 py-1 text-[9px] text-slate-600">{f.advertencias.join(" ") || "—"}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </Section>

              <Section title="3. Criterios de agrupación aplicados">
                {informe.agrupaciones.length === 0 ? <Empty /> : (
                  <ul className="space-y-1">
                    {informe.agrupaciones.slice(0, 6).map((a, i) => {
                      const d = (a.detalle ?? {}) as { criterios?: string[]; grupos?: number; elementosAnalizados?: number; clasesExcluidas?: string[] };
                      return (
                        <li key={i} className="rounded border border-slate-200 bg-slate-50 px-2 py-1.5 text-[10px]">
                          <span className="font-semibold">{nuevaFecha(a.fecha)}</span> — {d.grupos ?? 0} grupos sobre {d.elementosAnalizados ?? 0} elementos.
                          {" "}Criterios: <span className="font-mono">{(d.criterios ?? []).join(" + ")}</span>.
                          {d.clasesExcluidas?.length ? <> Clases excluidas: <span className="font-mono">{d.clasesExcluidas.join(", ")}</span>.</> : null}
                          {a.actor ? <> Ejecutó: {a.actor}.</> : null}
                        </li>
                      );
                    })}
                  </ul>
                )}
              </Section>

              <Section title={`4. ${T.decisionsTitle}`}>
                <DecisionBlock title="4.1 Cambios de actividad respecto a la propuesta automática" rows={informe.cambiosActividad.map((d) => ({
                  fecha: d.fecha, actor: d.actor,
                  texto: `${(d.detalle as { actividad?: string })?.actividad ?? ""} — grupo: ${(d.detalle as { grupo?: string })?.grupo ?? "—"}`,
                  nota: (d.detalle as { nota?: string })?.nota ?? null,
                }))} />
                <DecisionBlock title="4.2 Cambios en la regla de medición" rows={informe.cambiosRegla.map((d) => {
                  const det = (d.detalle ?? {}) as { valorAnterior?: number; valorNuevo?: number; configuracionNueva?: Record<string, unknown>; nota?: string };
                  return {
                    fecha: d.fecha, actor: d.actor,
                    texto: `${fmt(det.valorAnterior ?? null)} → ${fmt(det.valorNuevo ?? null)} · ${JSON.stringify(det.configuracionNueva ?? {})}`,
                    nota: det.nota ?? null,
                  };
                })} />
                <DecisionBlock title="4.3 Correcciones manuales de cantidades" rows={informe.correcciones.map((d) => {
                  const det = (d.detalle ?? {}) as { valorAnterior?: number; valorNuevo?: number; unidad?: string; nota?: string };
                  return {
                    fecha: d.fecha, actor: d.actor,
                    texto: `${fmt(det.valorAnterior ?? null)} → ${fmt(det.valorNuevo ?? null)} ${det.unidad ?? ""}`,
                    nota: det.nota ?? null,
                  };
                })} />
                <DecisionBlock title="4.4 Actividades derivadas (acabados sobre elementos ya medidos)" rows={informe.derivaciones.map((d) => {
                  const det = (d.detalle ?? {}) as { origen?: string; nuevaActividad?: string; cantidad?: number; unidad?: string; nota?: string };
                  return {
                    fecha: d.fecha, actor: d.actor,
                    texto: `${det.nuevaActividad ?? ""} ← derivada de ${det.origen ?? ""} (${fmt(det.cantidad ?? null)} ${det.unidad ?? ""})`,
                    nota: det.nota ?? null,
                  };
                })} />
                <DecisionBlock title="4.5 Propuestas y cantidades rechazadas" rows={informe.rechazos.map((d) => {
                  const det = (d.detalle ?? {}) as { grupo?: string; valor?: number; nota?: string };
                  return { fecha: d.fecha, actor: d.actor, texto: det.grupo ?? `valor ${fmt(det.valor ?? null)}`, nota: det.nota ?? null };
                })} />
                <DecisionBlock title="4.6 Elementos excluidos del análisis" rows={informe.exclusiones.map((d) => {
                  const det = (d.detalle ?? {}) as { elemento?: string; clase?: string; nota?: string };
                  return { fecha: d.fecha, actor: d.actor, texto: `${det.clase ?? ""} — ${det.elemento ?? ""}`, nota: det.nota ?? null };
                })} />
                <DecisionBlock title="4.7 Mediciones manuales" rows={informe.manuales.map((d) => {
                  const det = (d.detalle ?? {}) as { actividad?: string; valor?: number; unidad?: string; nota?: string };
                  return { fecha: d.fecha, actor: d.actor, texto: `${det.actividad ?? ""}: ${fmt(det.valor ?? null)} ${det.unidad ?? ""}`, nota: det.nota ?? null };
                })} />
              </Section>

              <Section title={`5. ${T.observationsTitle}`}>
                {obs.length === 0 ? <Empty /> : (
                  <table className="w-full border-collapse text-[9.5px]">
                    <thead><tr className="bg-slate-100">
                      <th className="border border-slate-300 px-2 py-1 text-left">Actividad</th>
                      <th className="border border-slate-300 px-2 py-1 text-right">Cantidad</th>
                      <th className="border border-slate-300 px-2 py-1 text-left">Método / regla</th>
                      <th className="border border-slate-300 px-2 py-1 text-left">Observación</th>
                    </tr></thead>
                    <tbody>
                      {obs.slice(0, 60).map((o, i) => (
                        <tr key={i}>
                          <td className="border border-slate-300 px-2 py-1">
                            <span className="font-semibold">{o.actividad}</span>
                            <span className="block text-[9px] text-slate-500">{o.origen ?? ""} · {o.elementos} elem. · {o.estado}</span>
                          </td>
                          <td className="border border-slate-300 px-2 py-1 text-right font-mono">{fmt(o.cantidad)} {o.unidad}</td>
                          <td className="border border-slate-300 px-2 py-1 text-[9px]">{METHOD_META[o.metodo]?.label ?? o.metodo}. {o.regla}</td>
                          <td className="border border-slate-300 px-2 py-1 text-[9px]">
                            {o.elementosSinDato > 0 && <span className="block text-amber-700">{o.elementosSinDato} elemento(s) sin datos de medición.</span>}
                            {o.correccion ? <span className="block">Corrección profesional aplicada.</span> : null}
                            {o.derivada ? <span className="block">Cantidad derivada de otra actividad.</span> : null}
                            {o.advertencias.map((a, j) => <span key={j} className="block">{a}</span>)}
                            {o.nota ? <span className="block italic">«{o.nota}»</span> : null}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                )}
                {obs.length > 60 && <p className="mt-1 text-[9px] italic text-slate-500">Se muestran las primeras 60 de {obs.length} observaciones.</p>}
              </Section>

              <Section title="6. Declaración de alcance">
                <p className="text-[10px] leading-relaxed text-slate-600">{T.reportScope}</p>
                <p className="mt-1 text-[9.5px] text-slate-500">{T.footerText}</p>
                <div className="mt-10 flex justify-between gap-10">
                  <div className="flex-1 border-t border-slate-500 pt-1 text-[10px]">
                    <p className="font-bold text-slate-700">{T.preparedByLabel}</p>
                    <p className="text-slate-600">{empresa.responsible || "\u00A0"}</p>
                    <p className="text-[9px] text-slate-500">{empresa.role || "\u00A0"}{empresa.license ? ` · M.P. ${empresa.license}` : ""}</p>
                  </div>
                  <div className="flex-1 border-t border-slate-500 pt-1 text-[10px]">
                    <p className="font-bold text-slate-700">{T.reviewedByLabel}</p>
                    <p className="text-slate-600">&nbsp;</p>
                  </div>
                </div>
              </Section>
            </>
          )}
        </div>
      </div>
    </div>
  );
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <section className="mb-5">
      <h2 className="mb-2 border-b border-slate-300 pb-1 text-[11px] font-extrabold uppercase tracking-wide text-slate-800">{title}</h2>
      {children}
    </section>
  );
}

function Empty() {
  return <p className="text-[10px] italic text-slate-500">Sin registros en esta categoría.</p>;
}

function DecisionBlock({ title, rows }: { title: string; rows: { fecha: string; actor: string | null; texto: string; nota: string | null }[] }) {
  if (!rows.length) return null;
  return (
    <div className="mb-3">
      <h3 className="mb-1 text-[10px] font-bold text-slate-700">{title} <span className="font-normal text-slate-500">({rows.length})</span></h3>
      <table className="w-full border-collapse text-[9.5px]">
        <tbody>
          {rows.slice(0, 25).map((r, i) => (
            <tr key={i}>
              <td className="w-32 border border-slate-200 px-2 py-1 text-slate-500">{nuevaFecha(r.fecha)}</td>
              <td className="w-28 border border-slate-200 px-2 py-1 text-slate-600">{r.actor ?? "—"}</td>
              <td className="border border-slate-200 px-2 py-1">
                {r.texto}
                {r.nota ? <span className="block italic text-slate-500">«{r.nota}»</span> : null}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
      {rows.length > 25 && <p className="mt-0.5 text-[9px] italic text-slate-500">…y {rows.length - 25} más.</p>}
    </div>
  );
}
