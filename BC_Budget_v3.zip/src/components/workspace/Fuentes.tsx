"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import {
  FileBox, FileSpreadsheet, Hand, LayoutTemplate, Upload, Sparkles,
  CircleAlert, ShieldCheck, MonitorCog, FolderOpen, Trash2, CopyPlus, TriangleAlert,
} from "lucide-react";
import { Btn, Card, Chip, Empty, Field, Input, Select, Spinner, SectionTitle, Alert, Modal } from "@/components/ui";
import { api, KIND_META, nuevaFecha } from "@/lib/client";
import { isDesktop, pickIfcFiles, importIfcDesktop, onDesktopOpenIfc } from "@/lib/desktop";

interface Source {
  id: string; kind: string; name: string; discipline: string | null;
  fileName: string | null; fileSize: number | null; ifcSchema: string | null;
  stats: Record<string, unknown> | null; createdAt: string;
}

const KIND_ICON: Record<string, typeof FileBox> = {
  IFC: FileBox, EXCEL: FileSpreadsheet, MANUAL: Hand, TEMPLATE: LayoutTemplate,
};

const DISCIPLINAS = ["ARQUITECTURA", "ESTRUCTURA", "HIDROSANITARIA", "ELÉCTRICO", "MECÁNICO", "GENERAL"];

export function Fuentes({ projectId, actor, onChanged, goTab }: { projectId: string; actor: string; onChanged: () => void; goTab: (t: "evidencia" | "agrupacion" | "correspondencias") => void }) {
  const [sources, setSources] = useState<Source[] | null>(null);
  const [busy, setBusy] = useState(false);
  const [demoBusy, setDemoBusy] = useState(false);
  const [msg, setMsg] = useState<{ tone: "ok" | "error" | "info" | "warn"; text: string } | null>(null);
  const [kind, setKind] = useState<"IFC" | "EXCEL">("IFC");
  const [name, setName] = useState("");
  const [discipline, setDiscipline] = useState("ARQUITECTURA");
  const [unitScale, setUnitScale] = useState("auto");
  const [desktop, setDesktop] = useState(false);
  const [dupWarn, setDupWarn] = useState<{
    mensaje: string; consecuencia: string; sugerencia: string;
    fuenteExistente: { id: string; nombre: string; archivo: string | null; elementos: number; motivo: string };
  } | null>(null);
  const [pendingUpload, setPendingUpload] = useState<FormData | null>(null);
  const [toDelete, setToDelete] = useState<Source | null>(null);
  const [impact, setImpact] = useState<{ elementos: number; cantidades: number; cantidadesValidadas: number; cantidadesDerivadas: number } | null>(null);
  const [deleting, setDeleting] = useState(false);

  useEffect(() => { setDesktop(isDesktop()); }, []);

  /** Importa modelos IFC leyéndolos del disco (solo BIMCost Desktop). */
  const importFromDisk = useCallback(async () => {
    const files = await pickIfcFiles();
    if (!files.length) return;
    setBusy(true);
    setMsg(null);
    try {
      let total = 0;
      for (const f of files) {
        const d = await importIfcDesktop({
          projectId, path: f.path, name: f.name, discipline,
          actor: actor || undefined, unitScale,
        });
        total += d.elementos;
      }
      setMsg({ tone: "ok", text: `${files.length} modelo(s) leídos directamente del disco: ${total} elementos de evidencia. Sin límite de memoria del navegador.` });
      load();
      onChanged();
    } catch (e) {
      setMsg({ tone: "error", text: (e as Error).message });
    } finally {
      setBusy(false);
    }
  }, [projectId, discipline, actor, unitScale, onChanged]);

  useEffect(() => { onDesktopOpenIfc(() => { void importFromDisk(); }); }, [importFromDisk]);
  const fileRef = useRef<HTMLInputElement>(null);

  const load = useCallback(() => {
    api<{ sources: Source[] }>(`/api/projects/${projectId}/sources`).then((d) => setSources(d.sources));
  }, [projectId]);
  useEffect(() => { load(); }, [load]);

  const upload = async () => {
    const file = fileRef.current?.files?.[0];
    if (!file) {
      setMsg({ tone: "error", text: "Seleccione un archivo primero." });
      return;
    }
    setBusy(true);
    setMsg(null);
    try {
      const fd = new FormData();
      fd.set("kind", kind);
      fd.set("name", name);
      fd.set("discipline", discipline);
      fd.set("actor", actor);
      fd.set("unitScale", unitScale);
      fd.set("file", file);
      const res = await fetch(`/api/projects/${projectId}/sources`, { method: "POST", body: fd });
      const data = await res.json();
      if (res.status === 409 && data.error === "FUENTE_DUPLICADA") {
        setDupWarn(data.duplicado);
        setPendingUpload(fd);
        return;
      }
      if (!res.ok) throw new Error(data.error || "Error al importar");
      if (kind === "IFC") {
        setMsg({
          tone: "ok",
          text: `«${data.source.name}» importado: ${data.elementos} elementos leídos como evidencia (${data.source.ifcSchema}). La fuente conserva su identidad — ningún archivo reemplaza a otro.`,
        });
      } else {
        setMsg({ tone: "ok", text: `«${data.source.name}» importado: ${data.importadas} filas. ${data.sinCodigoCatalogo > 0 ? `⚠ ${data.sinCodigoCatalogo} con código ausente en el catálogo maestro.` : ""} Todas quedan PENDIENTES de validación.` });
      }
      setName("");
      if (fileRef.current) fileRef.current.value = "";
      load();
      onChanged();
    } catch (e) {
      setMsg({ tone: "error", text: (e as Error).message });
    } finally {
      setBusy(false);
    }
  };

  /** Reintenta la importación autorizando explícitamente el duplicado. */
  const forceUpload = async () => {
    if (!pendingUpload) return;
    setBusy(true);
    try {
      pendingUpload.set("allowDuplicate", "1");
      const res = await fetch(`/api/projects/${projectId}/sources`, { method: "POST", body: pendingUpload });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Error al importar");
      setMsg({ tone: "warn", text: `«${data.source.name}» importado como copia autorizada: ${data.elementos} elementos. Revise que no se dupliquen cantidades.` });
      setDupWarn(null);
      setPendingUpload(null);
      if (fileRef.current) fileRef.current.value = "";
      load();
      onChanged();
    } catch (e) {
      setMsg({ tone: "error", text: (e as Error).message });
    } finally {
      setBusy(false);
    }
  };

  /** Consulta el impacto antes de eliminar una fuente. */
  const askDelete = async (s2: Source) => {
    setToDelete(s2);
    setImpact(null);
    try {
      const d = await api<{ impacto: { elementos: number; cantidades: number; cantidadesValidadas: number; cantidadesDerivadas: number } }>(`/api/sources/${s2.id}`);
      setImpact(d.impacto);
    } catch {
      setImpact({ elementos: 0, cantidades: 0, cantidadesValidadas: 0, cantidadesDerivadas: 0 });
    }
  };

  const confirmDelete = async () => {
    if (!toDelete) return;
    setDeleting(true);
    try {
      const d = await api<{ eliminado: { fuente: string; elementos: number; cantidades: number } }>(
        `/api/sources/${toDelete.id}?actor=${encodeURIComponent(actor || "")}`,
        { method: "DELETE" }
      );
      setMsg({
        tone: "ok",
        text: `Fuente «${d.eliminado.fuente}» eliminada: ${d.eliminado.elementos} elementos y ${d.eliminado.cantidades} cantidad(es) asociadas. El historial de decisiones se conserva.`,
      });
      setToDelete(null);
      setImpact(null);
      load();
      onChanged();
    } catch (e) {
      setMsg({ tone: "error", text: (e as Error).message });
    } finally {
      setDeleting(false);
    }
  };

  const demo = async () => {
    setDemoBusy(true);
    setMsg(null);
    try {
      const d = await api<{ summary: { fuente: string; elementos?: number; filas?: number }[] }>(`/api/projects/${projectId}/demo`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ actor }),
      });
      const els = d.summary.reduce((a, s) => a + (s.elementos ?? 0), 0);
      setMsg({ tone: "ok", text: `Demostración cargada: ${d.summary.length} fuentes, ${els} elementos IFC de evidencia y ${d.summary.find((s) => s.filas)?.filas ?? 0} filas Excel. Revise la pestaña Evidencia IFC.` });
      load();
      onChanged();
    } catch (e) {
      setMsg({ tone: "error", text: (e as Error).message });
    } finally {
      setDemoBusy(false);
    }
  };

  const ifcCount = sources?.filter((s) => s.kind === "IFC").length ?? 0;

  return (
    <div className="space-y-5 bc-fade-up">
      <SectionTitle
        title="Fuentes de información del proyecto"
        desc="Un proyecto recibe múltiples fuentes: cada una conserva su identidad y trazabilidad. Un IFC nunca reemplaza silenciosamente a otro."
      />

      {msg && <Alert tone={msg.tone}>{msg.text}</Alert>}
      {desktop && (
        <Alert tone="ok">
          <span className="flex items-start gap-2">
            <MonitorCog size={13} className="mt-0.5 shrink-0" />
            <span>
              <strong>BIMCost Desktop</strong> activo: use «Abrir desde el disco» para leer modelos IFC grandes sin
              pasarlos por la memoria del navegador.
            </span>
          </span>
        </Alert>
      )}

      <div className="grid gap-4 lg:grid-cols-5">
        {/* Subir fuente */}
        <Card className="p-5 lg:col-span-3">
          <div className="mb-3 flex items-center gap-2">
            <Upload size={15} className="text-acc" />
            <h3 className="text-sm font-bold text-white">Importar fuente</h3>
          </div>
          <div className="mb-3 flex gap-2">
            {(["IFC", "EXCEL"] as const).map((k) => (
              <button
                key={k}
                onClick={() => setKind(k)}
                className={`flex flex-1 items-center justify-center gap-2 rounded-lg border px-3 py-2 text-xs font-semibold transition-colors ${kind === k ? "border-acc/60 bg-acc/10 text-acc" : "border-line bg-ink-800 text-mist hover:text-white"}`}
              >
                {k === "IFC" ? <FileBox size={14} /> : <FileSpreadsheet size={14} />}
                Archivo {k === "IFC" ? "IFC (.ifc STEP)" : "Excel (.xlsx / .csv)"}
              </button>
            ))}
          </div>
          <div className="grid gap-3 sm:grid-cols-2">
            <Field label="Nombre de la fuente" hint="Ej: IFC Arquitectura">
              <Input value={name} onChange={(e) => setName(e.target.value)} placeholder={kind === "IFC" ? "IFC Arquitectura" : "Partidas preliminares"} />
            </Field>
            <Field label="Disciplina">
              <Select value={discipline} onChange={(e) => setDiscipline(e.target.value)}>
                {DISCIPLINAS.map((d) => <option key={d}>{d}</option>)}
              </Select>
            </Field>
          </div>
          <div className="mt-3 grid gap-3 sm:grid-cols-[1fr_200px]">
            <Field label={kind === "IFC" ? "Archivo IFC (ISO-10303-21)" : "Hoja con columnas: Código | Actividad | Unidad | Cantidad | (Nota)"}>
              <Input ref={fileRef} type="file" accept={kind === "IFC" ? ".ifc,.ifcxml,.step" : ".xlsx,.xls,.csv"} className="py-1.5 text-xs" />
            </Field>
            {kind === "IFC" && (
              <Field label="Unidad del modelo" hint="Solo si las cantidades salen mal">
                <Select value={unitScale} onChange={(e) => setUnitScale(e.target.value)}>
                  <option value="auto">Automática (recomendado)</option>
                  <option value="m">Metros</option>
                  <option value="cm">Centímetros</option>
                  <option value="mm">Milímetros</option>
                  <option value="ft">Pies</option>
                  <option value="in">Pulgadas</option>
                </Select>
              </Field>
            )}
          </div>
          {kind === "EXCEL" ? (
            <p className="mt-2 text-[11px] leading-relaxed text-fog">
              Las filas se enlazan al catálogo maestro por <span className="font-mono text-slate-300">Código</span>. Toda cantidad importada llega
              como <strong className="text-amber-300">PENDIENTE</strong>: el software no la convierte en hecho sin su validación.
            </p>
          ) : (
            <p className="mt-2 text-[11px] leading-relaxed text-fog">
              BIMCost Quantity lee el IFC como <strong className="text-slate-200">evidencia</strong>: elementos, tipos, materiales, niveles,
              propiedades y cantidades IFC. No interpreta texto como geometría.
            </p>
          )}
          <div className="mt-4 flex flex-wrap items-center justify-between gap-2">
            <div className="flex flex-wrap gap-2">
              <Btn variant="primary" icon={Upload} loading={busy} onClick={upload}>Importar al proyecto</Btn>
              {desktop && kind === "IFC" && (
                <Btn icon={FolderOpen} loading={busy} onClick={importFromDisk}
                  title="Lee el archivo directamente del disco: admite modelos muy grandes">
                  Abrir desde el disco
                </Btn>
              )}
            </div>
            <Btn icon={Sparkles} loading={demoBusy} onClick={demo}>
              {ifcCount === 0 ? "Cargar demostración CASA X (4 IFC + Excel)" : "Añadir fuentes de demostración"}
            </Btn>
          </div>
        </Card>

        {/* Regla de oro */}
        <Card className="border-acc/25 bg-gradient-to-b from-acc/5 to-transparent p-5 lg:col-span-2">
          <div className="flex items-center gap-2">
            <ShieldCheck size={15} className="text-acc" />
            <h3 className="text-sm font-bold text-white">Principio de consolidación</h3>
          </div>
          <ul className="mt-3 space-y-2.5 text-xs leading-relaxed text-mist">
            <li className="flex gap-2"><span className="mt-1 h-1 w-1 shrink-0 rounded-full bg-acc" />Arquitectura, estructura e instalaciones conviven en el mismo proyecto.</li>
            <li className="flex gap-2"><span className="mt-1 h-1 w-1 shrink-0 rounded-full bg-acc" />Cada cantidad recordará exactamente de qué fuente salió.</li>
            <li className="flex gap-2"><span className="mt-1 h-1 w-1 shrink-0 rounded-full bg-acc" />La agrupación y las propuestas se calculan sobre todas las fuentes conjuntamente.</li>
            <li className="flex gap-2"><span className="mt-1 h-1 w-1 shrink-0 rounded-full bg-acc" />Nada se decide automáticamente: EVIDENCIA → PROPUESTA → DECISIÓN PROFESIONAL.</li>
          </ul>
          {ifcCount > 0 && (
            <Btn className="mt-4 w-full" onClick={() => goTab("evidencia")}>Explorar la evidencia leída →</Btn>
          )}
        </Card>
      </div>

      {/* Lista de fuentes */}
      {sources === null ? (
        <Spinner label="Leyendo fuentes…" />
      ) : sources.length === 0 ? (
        <Empty icon={FileBox} title="Sin fuentes todavía" hint="Importe un IFC, un Excel o use la demostración CASA X para recorrer todo el flujo del software." />
      ) : (
        <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-3">
          {sources.map((s) => {
            const Icon = KIND_ICON[s.kind] ?? FileBox;
            const stats = s.stats ?? {};
            const clases = (stats.clases as Record<string, number> | undefined) ?? {};
            const warnings = (stats.advertencias as string[] | undefined) ?? [];
            return (
              <Card key={s.id} className="p-4">
                <div className="flex items-start justify-between gap-2">
                  <div className="flex items-center gap-2.5">
                    <span className={`rounded-lg border p-2 ${KIND_META[s.kind]?.cls ?? "border-line text-mist"}`}><Icon size={16} /></span>
                    <div>
                      <p className="text-sm font-bold text-white">{s.name}</p>
                      <p className="text-[11px] text-fog">{s.fileName ?? "—"}{s.fileSize ? ` · ${(s.fileSize / 1024).toFixed(0)} KB` : ""}</p>
                    </div>
                  </div>
                  <div className="flex shrink-0 items-center gap-1">
                    <Chip className={KIND_META[s.kind]?.cls}>{KIND_META[s.kind]?.label ?? s.kind}</Chip>
                    {s.kind !== "MANUAL" && (
                      <button onClick={() => askDelete(s)} title="Eliminar esta fuente del proyecto"
                        className="rounded-md p-1.5 text-fog transition-colors hover:bg-rose-500/15 hover:text-rose-300">
                        <Trash2 size={13} />
                      </button>
                    )}
                  </div>
                </div>
                <div className="mt-3 flex flex-wrap items-center gap-1.5 text-[11px] text-mist">
                  {s.discipline ? <Chip className="border-line-strong bg-ink-750">{s.discipline}</Chip> : null}
                  {s.ifcSchema ? <Chip className="border-line-strong bg-ink-750 font-mono">{s.ifcSchema}</Chip> : null}
                  <span className="ml-auto text-fog">{nuevaFecha(s.createdAt)}</span>
                </div>
                {s.kind === "IFC" ? (
                  <div className="mt-3 border-t border-line pt-3">
                    <p className="mb-1.5 text-[10px] font-bold uppercase tracking-widest text-fog">
                      Evidencia leída — {String(stats.elementos ?? 0)} elementos / {String(stats.entidades ?? 0)} entidades
                    </p>
                    <div className="mb-1.5 flex flex-wrap gap-1">
                      {stats.unidad ? (
                        <Chip className={stats.escalaCorregida
                          ? "border-amber-400/40 bg-amber-400/10 text-amber-300"
                          : "border-emerald-400/30 bg-emerald-400/10 text-emerald-300"}>
                          Unidad: {String(stats.unidad)}{stats.escalaCorregida ? " (corregida)" : ""}
                        </Chip>
                      ) : null}
                      {typeof stats.extensionModelo === "number" && stats.extensionModelo > 0 ? (
                        <Chip className="border-line bg-ink-750 font-mono text-mist">
                          extensión ≈ {String(stats.extensionModelo)} m
                        </Chip>
                      ) : null}
                      {typeof stats.conGeometria === "number" ? (
                        <Chip className="border-line bg-ink-750 text-mist">{String(stats.conGeometria)} con geometría</Chip>
                      ) : null}
                      {typeof stats.conCantidadesIfc === "number" ? (
                        <Chip className="border-line bg-ink-750 text-mist">{String(stats.conCantidadesIfc)} con cantidades IFC</Chip>
                      ) : null}
                    </div>
                    <div className="flex flex-wrap gap-1">
                      {Object.entries(clases).slice(0, 8).map(([c, n]) => (
                        <Chip key={c} className="border-cyan-400/25 bg-cyan-400/5 font-mono text-cyan-300">{c.replace(/^IFC/, "Ifc")} ×{n}</Chip>
                      ))}
                    </div>
                    {warnings.map((w, i) => (
                      <p key={i} className="mt-2 flex items-start gap-1.5 text-[11px] text-amber-300"><CircleAlert size={12} className="mt-0.5 shrink-0" />{w}</p>
                    ))}
                  </div>
                ) : s.kind === "EXCEL" ? (
                  <div className="mt-3 border-t border-line pt-3 text-[11px] text-mist">
                    {String(stats.filas ?? 0)} filas importadas → cantidades <span className="font-semibold text-amber-300">PENDIENTES</span> de validación.
                  </div>
                ) : (
                  <div className="mt-3 border-t border-line pt-3 text-[11px] text-mist">
                    {String((stats.nota as string) ?? "Fuente del proyecto")}
                  </div>
                )}
              </Card>
            );
          })}
        </div>
      )}

      {/* ---------- Modelo duplicado ---------- */}
      <Modal open={!!dupWarn} onClose={() => { setDupWarn(null); setPendingUpload(null); }} title="Este modelo ya está en el proyecto">
        {dupWarn && (
          <div className="space-y-3">
            <Alert tone="error">
              <span className="flex items-start gap-2">
                <TriangleAlert size={14} className="mt-0.5 shrink-0" />
                <span>{dupWarn.mensaje}</span>
              </span>
            </Alert>
            <Card className="p-3.5">
              <p className="mb-1 text-[10px] font-bold uppercase tracking-widest text-fog">Fuente ya existente</p>
              <p className="text-sm font-bold text-white">{dupWarn.fuenteExistente.nombre}</p>
              <p className="text-[11px] text-mist">
                {dupWarn.fuenteExistente.archivo ?? "—"} · {dupWarn.fuenteExistente.elementos} elementos
              </p>
            </Card>
            <p className="text-xs leading-relaxed text-mist">
              <strong className="text-amber-300">{dupWarn.consecuencia}</strong> {dupWarn.sugerencia}
            </p>
            <div className="flex flex-wrap justify-end gap-2">
              <Btn onClick={() => { setDupWarn(null); setPendingUpload(null); }}>Cancelar importación</Btn>
              <Btn variant="danger" icon={Trash2}
                onClick={() => {
                  const existing = sources?.find((x) => x.id === dupWarn.fuenteExistente.id);
                  setDupWarn(null);
                  setPendingUpload(null);
                  if (existing) askDelete(existing);
                }}>
                Eliminar la anterior
              </Btn>
              <Btn variant="warn" icon={CopyPlus} loading={busy} onClick={forceUpload}>
                Importar de todos modos
              </Btn>
            </div>
          </div>
        )}
      </Modal>

      {/* ---------- Eliminar fuente ---------- */}
      <Modal open={!!toDelete} onClose={() => { setToDelete(null); setImpact(null); }} title="Eliminar fuente del proyecto">
        {toDelete && (
          <div className="space-y-3">
            <p className="text-sm font-bold text-white">{toDelete.name}</p>
            <p className="text-[11px] text-mist">{toDelete.fileName ?? "—"}</p>
            {impact === null ? (
              <Spinner label="Calculando qué información depende de esta fuente…" />
            ) : (
              <>
                <Alert tone="warn">
                  <span className="flex items-start gap-2">
                    <TriangleAlert size={14} className="mt-0.5 shrink-0" />
                    <span>
                      Se eliminarán <strong>{impact.elementos} elemento(s)</strong> de evidencia y{" "}
                      <strong>{impact.cantidades} cantidad(es)</strong> medidas sobre ellos
                      {impact.cantidadesValidadas > 0 && <> (de las cuales {impact.cantidadesValidadas} ya estaban validadas)</>}
                      {impact.cantidadesDerivadas > 0 && <>, incluidas {impact.cantidadesDerivadas} actividad(es) derivadas</>}.
                    </span>
                  </span>
                </Alert>
                <p className="text-[11px] leading-relaxed text-fog">
                  El historial de decisiones profesionales se conserva: quedará registrado quién eliminó esta fuente y cuándo.
                  Las demás fuentes del proyecto no se ven afectadas.
                </p>
              </>
            )}
            <div className="flex justify-end gap-2">
              <Btn onClick={() => { setToDelete(null); setImpact(null); }}>Cancelar</Btn>
              <Btn variant="danger" icon={Trash2} loading={deleting} disabled={impact === null} onClick={confirmDelete}>
                Eliminar definitivamente
              </Btn>
            </div>
          </div>
        )}
      </Modal>
    </div>
  );
}
