"use client";

import { useCallback, useEffect, useState } from "react";
import {
  Network, Plus, ChevronDown, ChevronRight, Boxes, Settings2, FileText,
  CircleDollarSign, TriangleAlert, Building2, Percent, Upload, Link2, Trash2, Eraser,
} from "lucide-react";
import Link from "next/link";
import { Alert, Btn, Card, Chip, Empty, Field, Input, Modal, SectionTitle, Spinner, Textarea, cx } from "@/components/ui";
import { api, fmt, METHOD_META } from "@/lib/client";
import { ActivityPicker, type CatalogActivity } from "./ActivityPicker";
import { compareCodes } from "@/lib/codes";

interface Rollup { validada: number; propuesta: number; pendiente: number; lineas: number; fuentes: string[]; unidad: string | null; derivadas: number }
interface ActNode {
  id: string; code: string; name: string; activityId: string | null;
  unidad: string | null; metodo: string | null; unitPrice: number; total: number; rollup: Rollup | null;
  sinCantidad?: boolean;
}
interface SecNode { id: string; code: string; name: string; total: number; activities: ActNode[] }
interface ChNode { id: string; code: string; name: string; total: number; sections: SecNode[] }
interface Totales {
  costoDirecto: number; administracion: number; imprevistos: number; utilidad: number; iva: number; total: number;
  porcentajes: { administracion: number; imprevistos: number; utilidad: number; iva: number; ivaBases: string[]; baseIva: number };
  moneda: string; actividadesSinPrecio: number; actividadesSinCantidad?: number;
}

const IVA_BASES: { v: string; l: string; hint: string }[] = [
  { v: "UTILIDAD", l: "Utilidad", hint: "Uso habitual en Colombia (IVA sobre la utilidad del AIU)" },
  { v: "ADMINISTRACION", l: "Administración", hint: "Incluye la administración en la base gravable" },
  { v: "IMPREVISTOS", l: "Imprevistos", hint: "Incluye los imprevistos en la base gravable" },
  { v: "DIRECTO", l: "Costo directo", hint: "IVA sobre el valor de la obra (contratos gravados en su totalidad)" },
];

export function Estructura({
  projectId, actor, onChanged, goTab,
}: { projectId: string; actor: string; onChanged: () => void; goTab: (t: "cantidades") => void }) {
  const [tree, setTree] = useState<ChNode[] | null>(null);
  const [totales, setTotales] = useState<Totales | null>(null);
  const [participando, setParticipando] = useState<Set<string>>(new Set());
  const [open, setOpen] = useState<Record<string, boolean>>({});
  const [showAdd, setShowAdd] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [swapNode, setSwapNode] = useState<ActNode | null>(null);
  const [deleteNode, setDeleteNode] = useState<ActNode | null>(null);
  const [deleteInfo, setDeleteInfo] = useState<{ cantidades: number; validadas: number } | null>(null);
  const [busy, setBusy] = useState(false);
  const [notice, setNotice] = useState<string | null>(null);

  const [company, setCompany] = useState<Record<string, string>>({});
  const [aiu, setAiu] = useState({
    administracion: "0", imprevistos: "0", utilidad: "0", iva: "0",
    ivaBases: ["UTILIDAD"] as string[], currency: "COP", notes: "",
  });

  const load = useCallback(() => {
    api<{ tree: ChNode[]; totales: Totales; participando: string[] }>(`/api/structure?projectId=${projectId}`).then((d) => {
      setTree(d.tree);
      setTotales(d.totales);
      setParticipando(new Set(d.participando));
      setOpen((o) => {
        const next = { ...o };
        for (const ch of d.tree) if (!(ch.id in next)) next[ch.id] = true;
        return next;
      });
      setAiu((a) => ({
        ...a,
        administracion: String(d.totales.porcentajes.administracion ?? 0),
        imprevistos: String(d.totales.porcentajes.imprevistos ?? 0),
        utilidad: String(d.totales.porcentajes.utilidad ?? 0),
        iva: String(d.totales.porcentajes.iva ?? 0),
        ivaBases: d.totales.porcentajes.ivaBases ?? ["UTILIDAD"],
        currency: d.totales.moneda,
      }));
    });
    api<{ project: { company: Record<string, string> | null } }>(`/api/projects/${projectId}`).then((d) => {
      setCompany(d.project.company ?? {});
    });
  }, [projectId]);
  useEffect(() => { load(); }, [load]);

  const addActivity = async (a: CatalogActivity) => {
    setBusy(true);
    try {
      await api("/api/quantities", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ projectId, activityId: a.id, planned: true, actor: actor || undefined }),
      });
      setNotice(`Actividad ${a.code} añadida como PENDIENTE de medición.`);
      setShowAdd(false);
      load(); onChanged();
    } finally {
      setBusy(false);
    }
  };

  /** Cambia la actividad de TODAS las cantidades asociadas a esta línea. */
  const swapActivity = async (target: CatalogActivity) => {
    if (!swapNode?.activityId) return;
    setBusy(true);
    try {
      const d = await api<{ quantities: { id: string; activityId: string | null }[] }>(`/api/quantities?projectId=${projectId}`);
      const afectadas = d.quantities.filter((q) => q.activityId === swapNode.activityId);
      for (const q of afectadas) {
        await api(`/api/quantities/${q.id}`, {
          method: "PATCH", headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ action: "assign", activityId: target.id, actor: actor || undefined,
            note: `Reasignada desde ${swapNode.code} en la estructura del presupuesto` }),
        });
      }
      setNotice(`${afectadas.length} cantidad(es) reasignadas de ${swapNode.code} a ${target.code} — ${target.name}.`);
      setSwapNode(null);
      load(); onChanged();
    } finally {
      setBusy(false);
    }
  };

  /** Retira una actividad de la estructura (y sus cantidades si se confirma). */
  const removeActivity = async (node: ActNode, force: boolean) => {
    if (!node.activityId) return;
    setBusy(true);
    try {
      const params = new URLSearchParams({
        projectId, activityId: node.activityId, actor: actor || "",
        ...(force ? {} : { soloVacias: "1" }),
      });
      const res = await fetch(`/api/structure/activity?${params}`, { method: "DELETE" });
      const d = await res.json();
      if (res.status === 409 && d.error === "TIENE_CANTIDADES") {
        setDeleteInfo({ cantidades: d.detalle.cantidades, validadas: d.detalle.validadas });
        return;
      }
      if (!res.ok) throw new Error(d.error || "No se pudo eliminar la actividad");
      setNotice(`Actividad ${d.actividad} retirada de la estructura (${d.cantidadesEliminadas} cantidad(es), ${d.nodosRetirados} línea(s)).`);
      setDeleteNode(null);
      setDeleteInfo(null);
      load(); onChanged();
    } catch (e) {
      setNotice((e as Error).message);
    } finally {
      setBusy(false);
    }
  };

  /** Depura de una vez todas las líneas que quedaron sin cantidad. */
  const pruneEmpty = async () => {
    if (!confirm("¿Retirar de la estructura todas las actividades que quedaron sin cantidad? No afecta el catálogo ni la evidencia IFC.")) return;
    setBusy(true);
    try {
      const d = await api<{ actividadesEnCero: number; cantidadesEliminadas: number; nodosRetirados: number }>(
        "/api/structure/activity",
        {
          method: "POST", headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ projectId, action: "prune", actor: actor || undefined }),
        }
      );
      setNotice(d.actividadesEnCero === 0
        ? "No hay actividades en cero: la estructura ya está depurada."
        : `Depuración completa: ${d.actividadesEnCero} actividad(es) en cero retiradas de la estructura y de la exportación.`);
      load(); onChanged();
    } finally {
      setBusy(false);
    }
  };

  const saveSettings = async () => {
    setBusy(true);
    try {
      await api(`/api/projects/${projectId}`, {
        method: "PATCH", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          company,
          settings: {
            administracion: Number(aiu.administracion.replace(",", ".")) || 0,
            imprevistos: Number(aiu.imprevistos.replace(",", ".")) || 0,
            utilidad: Number(aiu.utilidad.replace(",", ".")) || 0,
            iva: Number(aiu.iva.replace(",", ".")) || 0,
            ivaBases: aiu.ivaBases,
            currency: aiu.currency,
            notes: aiu.notes,
          },
          actor: actor || undefined,
        }),
      });
      setNotice("Datos de empresa y porcentajes actualizados: se usarán en los documentos.");
      setShowSettings(false);
      load();
    } finally {
      setBusy(false);
    }
  };

  const onLogo = (file: File) => {
    const reader = new FileReader();
    reader.onload = () => setCompany((c) => ({ ...c, logo: String(reader.result) }));
    reader.readAsDataURL(file);
  };

  const money = (n: number) => `$ ${fmt(n, 0)}`;

  if (tree !== null && tree.length === 0) {
    return (
      <Empty icon={Network} title="La estructura del proyecto está vacía"
        hint="Se construye al validar correspondencias y cantidades. También puede añadir actividades del catálogo como líneas planificadas."
        action={<Btn variant="primary" icon={Plus} onClick={() => setShowAdd(true)}>Añadir desde el catálogo</Btn>} />
    );
  }

  return (
    <div className="space-y-5 bc-fade-up">
      <SectionTitle
        title="Estructura de cantidades y presupuesto preliminar"
        desc="Cantidades VALIDADAS × precio de referencia del catálogo maestro. Sin APU: el detalle económico corresponde a BC Budget."
        right={
          <div className="flex gap-2">
            <Btn icon={Eraser} loading={busy} onClick={pruneEmpty}>Depurar líneas en cero</Btn>
            <Btn icon={Settings2} onClick={() => setShowSettings(true)}>Empresa y AIU</Btn>
            <Link href={`/proyectos/${projectId}/documentos`}>
              <Btn variant="primary" icon={FileText}>Generar documentos</Btn>
            </Link>
            <Btn icon={Plus} onClick={() => setShowAdd(true)}>Añadir actividad</Btn>
          </div>
        }
      />

      {notice && <Alert tone="ok">{notice}</Alert>}
      {totales && (totales.actividadesSinCantidad ?? 0) > 0 && (
        <Alert tone="warn">
          <span className="flex items-start gap-2">
            <TriangleAlert size={13} className="mt-0.5 shrink-0" />
            <span>
              {totales.actividadesSinCantidad} actividad(es) figuran en la estructura <strong>sin cantidad</strong>.
              Suelen quedar al cambiar una línea de ítem. Use «Depurar líneas en cero» para que no aparezcan
              en el presupuesto ni en la exportación.
            </span>
          </span>
        </Alert>
      )}

      {totales && totales.actividadesSinPrecio > 0 && (
        <Alert tone="warn">
          <span className="flex items-start gap-2">
            <TriangleAlert size={13} className="mt-0.5 shrink-0" />
            {totales.actividadesSinPrecio} actividad(es) participan sin precio unitario en el catálogo. Impórtelos desde el
            listado de precios (pestaña Catálogo maestro) o edítelos allí; BC Budget también puede alimentarlos.
          </span>
        </Alert>
      )}

      {/* Totales */}
      {totales && (
        <div className="grid gap-3 sm:grid-cols-3 lg:grid-cols-6">
          {[
            { l: "Costo directo", v: totales.costoDirecto, acc: true },
            { l: `Administración ${totales.porcentajes.administracion}%`, v: totales.administracion },
            { l: `Imprevistos ${totales.porcentajes.imprevistos}%`, v: totales.imprevistos },
            { l: `Utilidad ${totales.porcentajes.utilidad}%`, v: totales.utilidad },
            { l: `IVA ${totales.porcentajes.iva}% s/ ${(totales.porcentajes.ivaBases ?? []).map((b) => b.toLowerCase().slice(0, 5)).join("+") || "—"}`, v: totales.iva },
            { l: "TOTAL", v: totales.total, strong: true },
          ].map((t) => (
            <Card key={t.l} className={cx("p-3.5", t.strong && "border-acc/40 bg-acc/5")}>
              <p className="text-[10px] font-bold uppercase tracking-widest text-fog">{t.l}</p>
              <p className={cx("mt-1 font-mono text-lg font-extrabold tabular-nums",
                t.strong ? "text-acc" : t.acc ? "text-white" : "text-slate-200")}>
                {money(t.v)}
              </p>
            </Card>
          ))}
        </div>
      )}

      {tree === null ? (
        <Spinner label="Construyendo estructura…" />
      ) : (
        <div className="space-y-3">
          {[...tree].sort((a, b) => compareCodes(a.code, b.code)).map((ch) => {
            const isOpen = open[ch.id] !== false;
            const nActs = ch.sections.reduce((a, s) => a + s.activities.length, 0);
            return (
              <Card key={ch.id} className="overflow-hidden">
                <button onClick={() => setOpen({ ...open, [ch.id]: !isOpen })}
                  className="flex w-full items-center gap-3 border-b border-line bg-ink-800/70 px-5 py-3 text-left hover:bg-ink-800">
                  {isOpen ? <ChevronDown size={15} className="text-acc" /> : <ChevronRight size={15} className="text-fog" />}
                  <span className="font-mono text-sm font-bold text-acc">{ch.code}</span>
                  <span className="text-sm font-bold tracking-wide text-white">{ch.name}</span>
                  <Chip className="ml-auto border-line bg-ink-750 text-mist">{nActs} actividades</Chip>
                  <span className="font-mono text-sm font-bold tabular-nums text-emerald-300">{money(ch.total)}</span>
                </button>
                {isOpen && [...ch.sections].sort((a, b) => compareCodes(a.code, b.code)).map((sec) => (
                  <div key={sec.id} className="border-b border-line/50 last:border-0">
                    <div className="flex items-center gap-2 bg-ink-850 px-5 py-1.5">
                      <span className="font-mono text-[11px] font-semibold text-mist">{sec.code}</span>
                      <span className="text-xs font-semibold text-slate-300">{sec.name}</span>
                      <span className="ml-auto font-mono text-[11px] text-mist">{money(sec.total)}</span>
                    </div>
                    {sec.activities.length === 0 ? (
                      <p className="px-5 py-3 text-[11px] italic text-fog">Sección sin actividades participantes.</p>
                    ) : (
                      <table className="w-full text-left text-xs">
                        <tbody>
                          {[...sec.activities].sort((a, b) => compareCodes(a.code, b.code)).map((a) => (
                            <tr key={a.id} className={cx("border-t border-line/40 transition-colors hover:bg-ink-800/50", a.sinCantidad && "opacity-60")}>
                              <td className="px-5 py-2.5 pl-10">
                                <p className="font-medium text-slate-100">
                                  <span className="mr-1.5 font-mono text-[11px] font-bold text-acc">{a.code}</span>{a.name}
                                  {a.sinCantidad && (
                                    <Chip className="ml-2 border-amber-400/40 bg-amber-400/10 text-amber-300">sin cantidad</Chip>
                                  )}
                                </p>
                                <div className="mt-1 flex flex-wrap gap-1">
                                  {a.metodo && <Chip className="border-violet-400/25 bg-violet-400/5 text-violet-300">{METHOD_META[a.metodo]?.short ?? a.metodo}</Chip>}
                                  {(a.rollup?.derivadas ?? 0) > 0 && <Chip className="border-violet-400/30 bg-violet-400/10 text-violet-300">{a.rollup!.derivadas} derivada(s)</Chip>}
                                  {(a.rollup?.fuentes ?? []).map((f) => (
                                    <Chip key={f} className="border-line bg-ink-750 text-mist"><Boxes size={10} /> {f}</Chip>
                                  ))}
                                </div>
                              </td>
                              <td className="w-28 px-3 py-2.5 text-right">
                                <p className="font-mono text-sm font-bold tabular-nums text-emerald-300">{fmt(a.rollup?.validada ?? 0, a.unidad === "M3" ? 3 : 2)}</p>
                                <p className="font-mono text-[10px] text-fog">{a.unidad ?? "—"}</p>
                              </td>
                              <td className="w-28 px-3 py-2.5 text-right">
                                {a.unitPrice > 0 ? (
                                  <p className="font-mono text-[11px] tabular-nums text-slate-300">{money(a.unitPrice)}</p>
                                ) : (
                                  <Chip className="border-amber-400/30 bg-amber-400/10 text-amber-300">sin precio</Chip>
                                )}
                              </td>
                              <td className="w-32 px-3 py-2.5 text-right font-mono text-sm font-bold tabular-nums text-white">{money(a.total)}</td>
                              <td className="w-36 px-3 py-2.5">
                                <div className="flex flex-wrap justify-end gap-1">
                                  {(a.rollup?.propuesta ?? 0) > 0 && <Chip className="border-sky-400/40 bg-sky-400/10 font-mono text-sky-300">+{fmt(a.rollup!.propuesta)} prop.</Chip>}
                                  {(a.rollup?.pendiente ?? 0) > 0 && <Chip className="border-amber-400/40 bg-amber-400/10 text-amber-300">{a.rollup!.pendiente} pend.</Chip>}
                                  <Btn size="sm" title="Cambiar la actividad de esta línea" onClick={() => setSwapNode(a)}><Link2 size={12} /></Btn>
                                  <Btn size="sm" variant="danger" title="Eliminar esta actividad del presupuesto"
                                    onClick={() => { setDeleteNode(a); setDeleteInfo(null); removeActivity(a, false); }}>
                                    <Trash2 size={12} />
                                  </Btn>
                                  <Btn size="sm" onClick={() => goTab("cantidades")}>Ver</Btn>
                                </div>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    )}
                  </div>
                ))}
              </Card>
            );
          })}
        </div>
      )}

      <Alert tone="info">
        Una actividad puede recibir cantidades de varias fuentes o de actividades derivadas: el total se consolida aquí,
        pero <strong>cada cantidad conserva su procedencia</strong> y puede auditarse en «Cantidades».
      </Alert>

      {/* Añadir actividad */}
      <Modal open={showAdd} onClose={() => setShowAdd(false)} title="Añadir actividad del catálogo al proyecto" wide>
        <p className="mb-3 text-xs text-mist">Se incorpora como línea <strong className="text-amber-300">PENDIENTE</strong> de medición.</p>
        <ActivityPicker allowCreate filterIds={participando} onPick={(a) => { if (!busy) addActivity(a); }} />
      </Modal>

      {/* Confirmar eliminación de una actividad con cantidades */}
      <Modal open={!!deleteNode && !!deleteInfo} onClose={() => { setDeleteNode(null); setDeleteInfo(null); }}
        title="Eliminar actividad del presupuesto">
        {deleteNode && deleteInfo && (
          <div className="space-y-3">
            <Alert tone="error">
              <span className="flex items-start gap-2">
                <TriangleAlert size={14} className="mt-0.5 shrink-0" />
                <span>
                  <strong>{deleteNode.code} — {deleteNode.name}</strong> tiene {deleteInfo.cantidades} cantidad(es)
                  {deleteInfo.validadas > 0 && <>, de las cuales {deleteInfo.validadas} ya están validadas</>}.
                  Al eliminarla se retiran también esas cantidades y sus derivadas.
                </span>
              </span>
            </Alert>
            <p className="text-[11px] leading-relaxed text-fog">
              El catálogo maestro y la evidencia IFC no se modifican. La eliminación queda registrada en el
              historial de decisiones del proyecto.
            </p>
            <div className="flex justify-end gap-2">
              <Btn onClick={() => { setDeleteNode(null); setDeleteInfo(null); }}>Cancelar</Btn>
              <Btn variant="danger" icon={Trash2} loading={busy} onClick={() => removeActivity(deleteNode, true)}>
                Eliminar actividad y sus cantidades
              </Btn>
            </div>
          </div>
        )}
      </Modal>

      {/* Cambiar actividad de una línea del presupuesto */}
      <Modal open={!!swapNode} onClose={() => setSwapNode(null)} wide title="Cambiar la actividad de esta línea">
        {swapNode && (
          <div className="space-y-3">
            <Alert tone="warn">
              Línea actual: <strong>{swapNode.code} — {swapNode.name}</strong>.
              Todas las cantidades asociadas se reasignarán a la nueva actividad y se volverán a medir con su método.
              Cada reasignación queda registrada como decisión profesional.
            </Alert>
            <ActivityPicker allowCreate onPick={(a) => { if (!busy) swapActivity(a); }} />
          </div>
        )}
      </Modal>

      {/* Empresa y AIU */}
      <Modal open={showSettings} onClose={() => setShowSettings(false)} title="Datos para documentos: empresa y porcentajes" wide>
        <div className="space-y-4">
          <div className="rounded-xl border border-line bg-ink-800/40 p-3.5">
            <p className="mb-2 flex items-center gap-1.5 text-[11px] font-bold uppercase tracking-[0.14em] text-mist">
              <Building2 size={12} /> Empresa constructora / responsable
            </p>
            <div className="grid gap-3 sm:grid-cols-2">
              <Field label="Razón social"><Input value={company.name ?? ""} onChange={(e) => setCompany({ ...company, name: e.target.value })} /></Field>
              <Field label="NIT / identificación"><Input value={company.nit ?? ""} onChange={(e) => setCompany({ ...company, nit: e.target.value })} /></Field>
              <Field label="Dirección"><Input value={company.address ?? ""} onChange={(e) => setCompany({ ...company, address: e.target.value })} /></Field>
              <Field label="Teléfono"><Input value={company.phone ?? ""} onChange={(e) => setCompany({ ...company, phone: e.target.value })} /></Field>
              <Field label="Correo"><Input value={company.email ?? ""} onChange={(e) => setCompany({ ...company, email: e.target.value })} /></Field>
              <Field label="Responsable"><Input value={company.responsible ?? ""} onChange={(e) => setCompany({ ...company, responsible: e.target.value })} /></Field>
              <Field label="Cargo"><Input value={company.role ?? ""} onChange={(e) => setCompany({ ...company, role: e.target.value })} /></Field>
              <Field label="Matrícula profesional"><Input value={company.license ?? ""} onChange={(e) => setCompany({ ...company, license: e.target.value })} /></Field>
            </div>
            <div className="mt-3 flex items-center gap-3">
              <label className="flex cursor-pointer items-center gap-2 rounded-lg border border-line-strong bg-ink-800 px-3 py-2 text-xs text-mist hover:border-acc/50">
                <Upload size={13} /> {company.logo ? "Cambiar logo" : "Subir logo"}
                <input type="file" accept="image/*" className="hidden" onChange={(e) => e.target.files?.[0] && onLogo(e.target.files[0])} />
              </label>
              {company.logo && (
                <>
                  { }
                  <img src={company.logo} alt="Logo" className="h-10 rounded border border-line bg-white/5 object-contain px-2" />
                  <button className="text-[11px] text-rose-300 hover:underline" onClick={() => setCompany({ ...company, logo: "" })}>Quitar</button>
                </>
              )}
            </div>
          </div>

          <div className="rounded-xl border border-line bg-ink-800/40 p-3.5">
            <p className="mb-2 flex items-center gap-1.5 text-[11px] font-bold uppercase tracking-[0.14em] text-mist">
              <Percent size={12} /> Porcentajes del presupuesto preliminar
            </p>
            <div className="grid gap-3 sm:grid-cols-4">
              <Field label="Administración %"><Input value={aiu.administracion} onChange={(e) => setAiu({ ...aiu, administracion: e.target.value })} className="font-mono" inputMode="decimal" /></Field>
              <Field label="Imprevistos %"><Input value={aiu.imprevistos} onChange={(e) => setAiu({ ...aiu, imprevistos: e.target.value })} className="font-mono" inputMode="decimal" /></Field>
              <Field label="Utilidad %"><Input value={aiu.utilidad} onChange={(e) => setAiu({ ...aiu, utilidad: e.target.value })} className="font-mono" inputMode="decimal" /></Field>
              <Field label="IVA %"><Input value={aiu.iva} onChange={(e) => setAiu({ ...aiu, iva: e.target.value })} className="font-mono" inputMode="decimal" /></Field>
            </div>
            <div className="mt-3">
              <p className="mb-1.5 text-[11px] font-semibold uppercase tracking-[0.14em] text-mist">Base gravable del IVA</p>
              <div className="grid gap-1.5 sm:grid-cols-2">
                {IVA_BASES.map((b) => {
                  const on = aiu.ivaBases.includes(b.v);
                  return (
                    <button key={b.v} type="button"
                      onClick={() => setAiu({
                        ...aiu,
                        ivaBases: on ? aiu.ivaBases.filter((x) => x !== b.v) : [...aiu.ivaBases, b.v],
                      })}
                      className={cx("flex items-start gap-2 rounded-lg border px-3 py-2 text-left transition-colors",
                        on ? "border-acc/60 bg-acc/10" : "border-line bg-ink-800 hover:border-line-strong")}>
                      <span className={cx("mt-0.5 flex h-4 w-4 shrink-0 items-center justify-center rounded border text-[10px] font-bold",
                        on ? "border-acc bg-acc text-ink-950" : "border-line-strong text-transparent")}>✓</span>
                      <span>
                        <span className={cx("block text-xs font-semibold", on ? "text-white" : "text-slate-300")}>{b.l}</span>
                        <span className="block text-[10px] text-fog">{b.hint}</span>
                      </span>
                    </button>
                  );
                })}
              </div>
              {totales && (
                <p className="mt-1.5 text-[10.5px] text-fog">
                  Base gravable actual: <span className="font-mono text-slate-300">$ {fmt(totales.porcentajes.baseIva ?? 0, 0)}</span>
                  {" "}× {aiu.iva}% = <span className="font-mono text-slate-300">$ {fmt(totales.iva, 0)}</span>
                </p>
              )}
            </div>
            <div className="mt-3 grid gap-3 sm:grid-cols-2">
              <Field label="Moneda"><Input value={aiu.currency} onChange={(e) => setAiu({ ...aiu, currency: e.target.value })} /></Field>
              <Field label="Nota para los documentos"><Textarea value={aiu.notes} onChange={(e) => setAiu({ ...aiu, notes: e.target.value })} placeholder="Validez de la oferta, condiciones…" /></Field>
            </div>
          </div>

          <Alert tone="info">
            <span className="flex items-start gap-2">
              <CircleDollarSign size={13} className="mt-0.5 shrink-0" />
              Estos valores solo producen un <strong>presupuesto preliminar sin APU</strong>. El análisis de precios unitarios,
              insumos, mano de obra y desperdicios corresponde a BC Budget.
            </span>
          </Alert>

          <div className="flex justify-end gap-2">
            <Btn onClick={() => setShowSettings(false)}>Cancelar</Btn>
            <Btn variant="primary" icon={Settings2} loading={busy} onClick={saveSettings}>Guardar</Btn>
          </div>
        </div>
      </Modal>
    </div>
  );
}
