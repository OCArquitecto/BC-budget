"use client";

import { useEffect, useState } from "react";
import {
  History, Download, FileJson, FileSpreadsheet, ShieldCheck, ScanSearch,
  FileBox, Ruler, GitCompareArrows, PackageX, FolderInput, HelpCircle, UserRound,
} from "lucide-react";
import { Alert, Btn, Card, Chip, SectionTitle, Spinner } from "@/components/ui";
import { api, nuevaFecha } from "@/lib/client";

interface DecisionRow {
  id: string; entityType: string; entityId: string | null;
  action: string; detail: Record<string, unknown> | null;
  actor: string | null; createdAt: string;
}

const ACTION_META: Record<string, { label: string; icon: typeof History; cls: string }> = {
  CREO_PROYECTO: { label: "Creó el proyecto", icon: FolderInput, cls: "text-acc" },
  IMPORTO_IFC: { label: "Importó IFC", icon: FileBox, cls: "text-cyan-300" },
  IMPORTO_EXCEL: { label: "Importó Excel", icon: FileSpreadsheet, cls: "text-emerald-300" },
  EJECUTO_AGRUPACION: { label: "Ejecutó agrupación", icon: ScanSearch, cls: "text-sky-300" },
  VALIDO_CORRESPONDENCIA: { label: "Validó correspondencia", icon: ShieldCheck, cls: "text-emerald-400" },
  CAMBIO_Y_VALIDO_ACTIVIDAD: { label: "Cambió y validó actividad", icon: GitCompareArrows, cls: "text-emerald-400" },
  RECHAZO_PROPUESTA: { label: "Rechazó propuesta", icon: GitCompareArrows, cls: "text-rose-400" },
  VALIDO_CANTIDAD: { label: "Validó cantidad", icon: ShieldCheck, cls: "text-emerald-400" },
  RECHAZO_CANTIDAD: { label: "Rechazó cantidad", icon: Ruler, cls: "text-rose-400" },
  CORRIGIO_CANTIDAD: { label: "Corrigió cantidad", icon: Ruler, cls: "text-amber-300" },
  REMIDIO_CANTIDAD: { label: "Re-midió cantidad", icon: Ruler, cls: "text-sky-300" },
  INGRESO_CANTIDAD_MANUAL: { label: "Ingresó medición manual", icon: Ruler, cls: "text-violet-300" },
  PLANIFICO_ACTIVIDAD: { label: "Planificó actividad", icon: Ruler, cls: "text-mist" },
  ASIGNO_ACTIVIDAD: { label: "Asignó actividad", icon: GitCompareArrows, cls: "text-acc" },
  EXCLUYO_ELEMENTO: { label: "Excluyó elemento", icon: PackageX, cls: "text-rose-300" },
  REINCORPORO_ELEMENTO: { label: "Reincorporó elemento", icon: PackageX, cls: "text-emerald-300" },
};

const PREGUNTAS = [
  { q: "¿QUÉ?", a: "Actividad del catálogo maestro" },
  { q: "¿CUÁNTO?", a: "Cantidad + unidad" },
  { q: "¿DE DÓNDE?", a: "Fuente + elementos + evidencia" },
  { q: "¿CÓMO?", a: "Regla + método de medición" },
  { q: "¿POR QUÉ ESA ACTIVIDAD?", a: "Correspondencia + decisión profesional" },
  { q: "¿QUIÉN LO VALIDÓ?", a: "Firma y fecha del profesional" },
];

export function Trazabilidad({ projectId }: { projectId: string }) {
  const [rows, setRows] = useState<DecisionRow[] | null>(null);

  useEffect(() => {
    api<{ decisions: DecisionRow[] }>(`/api/decisions?projectId=${projectId}`).then((d) => setRows(d.decisions));
  }, [projectId]);

  return (
    <div className="space-y-5 bc-fade-up">
      <SectionTitle
        title="Trazabilidad y exportación"
        desc="Toda cantidad puede responder de dónde salió. Toda decisión profesional queda firmada y fechada."
        right={
          <div className="flex gap-2">
            <a href={`/api/export?projectId=${projectId}&format=json`} download>
              <Btn icon={FileJson}>Exportar JSON (BC Budget)</Btn>
            </a>
            <a href={`/api/export?projectId=${projectId}&format=csv`} download>
              <Btn icon={FileSpreadsheet}>Exportar CSV</Btn>
            </a>
          </div>
        }
      />

      {/* Contrato de salida */}
      <Card className="border-acc/25 bg-gradient-to-br from-acc/5 to-transparent p-5">
        <div className="flex items-start gap-3">
          <HelpCircle size={18} className="mt-0.5 shrink-0 text-acc" />
          <div className="flex-1">
            <h3 className="text-sm font-bold text-white">La pregunta fundamental del software</h3>
            <p className="mt-1 text-xs leading-relaxed text-mist">
              «¿Qué se va a construir, cuánto hay y cómo puedo demostrar de dónde salió esa cantidad?»
              La exportación entrega a BC Budget solo <strong>QUÉ</strong> y <strong>CUÁNTO</strong> con evidencia;
              los costos (APU, precios, AIU) se calculan después, nunca aquí.
            </p>
            <div className="mt-3 grid gap-1.5 sm:grid-cols-2 lg:grid-cols-3">
              {PREGUNTAS.map((p) => (
                <div key={p.q} className="rounded-lg border border-line bg-ink-800/60 px-3 py-2">
                  <p className="font-mono text-[10.5px] font-bold text-acc">{p.q}</p>
                  <p className="text-[11px] text-slate-300">{p.a}</p>
                </div>
              ))}
            </div>
          </div>
          <Download size={16} className="text-fog" />
        </div>
      </Card>

      {/* Historial */}
      <h3 className="flex items-center gap-2 text-sm font-bold text-white"><History size={15} className="text-acc" /> Registro de decisiones profesionales</h3>
      {rows === null ? (
        <Spinner label="Leyendo historial…" />
      ) : rows.length === 0 ? (
        <Alert tone="info">Aún no hay decisiones registradas en este proyecto.</Alert>
      ) : (
        <div className="relative space-y-2 pl-6 before:absolute before:bottom-2 before:left-[9px] before:top-2 before:w-px before:bg-line">
          {rows.map((d) => {
            const meta = ACTION_META[d.action] ?? { label: d.action, icon: History, cls: "text-mist" };
            const Icon = meta.icon;
            return (
              <div key={d.id} className="relative">
                <span className="absolute -left-6 top-2 flex h-[19px] w-[19px] items-center justify-center rounded-full border border-line bg-ink-850">
                  <Icon size={10} className={meta.cls} />
                </span>
                <Card className="px-4 py-3">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className={`text-xs font-bold ${meta.cls}`}>{meta.label}</span>
                    <Chip className="border-line bg-ink-750 text-mist"><UserRound size={10} /> {d.actor ?? "sistema"}</Chip>
                    <span className="ml-auto text-[10.5px] text-fog">{nuevaFecha(d.createdAt)}</span>
                  </div>
                  {d.detail && (
                    <div className="mt-1.5 flex flex-wrap gap-1">
                      {Object.entries(d.detail)
                        .filter(([k, v]) => v !== null && v !== undefined && v !== "" && !["mensaje", "advertencia"].includes(k))
                        .slice(0, 8)
                        .map(([k, v]) => (
                          <Chip key={k} className="border-line/70 bg-ink-800 text-slate-300" title={typeof v === "object" ? JSON.stringify(v, null, 2) : undefined}>
                            <span className="text-fog">{k}:</span>&nbsp;
                            <span className="max-w-56 truncate font-mono">{typeof v === "object" ? JSON.stringify(v) : String(v)}</span>
                          </Chip>
                        ))}
                    </div>
                  )}
                </Card>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
