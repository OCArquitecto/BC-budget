"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import {
  ScanSearch, PackageX, PackageCheck, Info, Ruler as RulerIcon, Database, Braces, Eye,
} from "lucide-react";
import { Alert, Btn, Card, Chip, Drawer, Empty, Input, Kv, Select, Spinner, SectionTitle, cx } from "@/components/ui";
import { api, fmt, nuevaFecha } from "@/lib/client";
import { Viewer3D } from "./Viewer3D";

interface ElementRow {
  id: string; globalId: string | null; ifcClass: string; name: string | null;
  objectType: string | null; description: string | null; typeName: string | null;
  material: string | null; level: string | null; layer: string | null; tag: string | null;
  properties: Record<string, Record<string, string | number | boolean | null>> | null;
  quantities: Record<string, number> | null;
  dimensions: Record<string, number | null> | null;
  dimensionSources: Record<string, string> | null;
  geometry: { kind: string; size: [number, number, number]; center: [number, number, number]; yaw: number } | null;
  excluded: boolean; createdAt: string;
  source: { id: string; name: string; discipline: string | null } | null;
}

interface Summary {
  total: number;
  clases: { valor: string; total: number; excluidos: number }[];
  materiales: { valor: string; total: number; excluidos: number }[];
  niveles: { valor: string; total: number; excluidos: number }[];
  propiedades: { clave: string; elementos: number }[];
  fuentes: { id: string; name: string; kind: string; elementos: number }[];
}

const DIM_LABEL: Record<string, string> = {
  length: "Largo", width: "Ancho/Espesor", height: "Alto", thickness: "Espesor",
  area: "Área", grossArea: "Área bruta", netArea: "Área neta", surfaceArea: "Superficie",
  crossSectionArea: "Sección", perimeter: "Perímetro", volume: "Volumen", netVolume: "Volumen neto", count: "Conteo",
};

function dimsBrief(d: Record<string, number | null> | null): string {
  if (!d) return "—";
  const parts: string[] = [];
  if (d.netArea != null) parts.push(`${fmt(d.netArea)} m² neto`);
  if (d.netVolume != null) parts.push(`${fmt(d.netVolume, 3)} m³`);
  if (d.length != null) parts.push(`L=${fmt(d.length)} m`);
  if (d.height != null) parts.push(`H=${fmt(d.height)} m`);
  if (d.thickness != null || d.width != null) parts.push(`e=${fmt(d.thickness ?? d.width)} m`);
  return parts.length ? parts.slice(0, 3).join(" · ") : "—";
}

export function Evidencia({ projectId, actor, onChanged }: { projectId: string; actor: string; onChanged: () => void }) {
  const [summary, setSummary] = useState<Summary | null>(null);
  const [rows, setRows] = useState<ElementRow[] | null>(null);
  const [filters, setFilters] = useState({ ifcClass: "", level: "", material: "", sourceId: "", q: "", showExcluded: true });
  const [detail, setDetail] = useState<ElementRow | null>(null);
  const [busyId, setBusyId] = useState<string | null>(null);

  useEffect(() => {
    api<Summary>(`/api/evidence-summary?projectId=${projectId}`).then(setSummary);
  }, [projectId]);

  const load = useCallback(() => {
    const p = new URLSearchParams({ projectId, excluded: String(filters.showExcluded) });
    if (filters.ifcClass) p.set("ifcClass", filters.ifcClass);
    if (filters.level) p.set("level", filters.level);
    if (filters.material) p.set("material", filters.material);
    if (filters.sourceId) p.set("sourceId", filters.sourceId);
    if (filters.q) p.set("q", filters.q);
    setRows(null);
    api<{ elements: ElementRow[] }>(`/api/elements?${p}`).then((d) => setRows(d.elements));
  }, [projectId, filters]);
  useEffect(() => { load(); }, [load]);

  const toggleExclude = async (el: ElementRow) => {
    setBusyId(el.id);
    try {
      await api(`/api/elements/${el.id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ excluded: !el.excluded, actor }),
      });
      setDetail((d) => (d && d.id === el.id ? { ...d, excluded: !el.excluded } : d));
      load();
      onChanged();
    } finally {
      setBusyId(null);
    }
  };

  const tableRows = useMemo(() => rows ?? [], [rows]);

  if (summary && summary.total === 0) {
    return (
      <Empty
        icon={ScanSearch}
        title="No hay evidencia IFC todavía"
        hint="Importe archivos IFC en la pestaña Fuentes. BIMCost Quantity leerá lo que realmente existe: elementos, tipos, materiales, niveles, propiedades y cantidades IFC."
      />
    );
  }

  return (
    <div className="space-y-5 bc-fade-up">
      <SectionTitle
        title="Evidencia IFC — qué existe realmente en los modelos"
        desc="Antes de cualquier análisis, revise la información disponible. Ningún modelo BIM se asume igual a otro."
      />

      <Alert tone="warn">
        <div className="flex items-start gap-2">
          <Info size={14} className="mt-0.5 shrink-0" />
          <span>
            <strong>Regla fundamental:</strong> BIMCost no convierte texto del IFC en cantidades geométricas.
            Una etiqueta como «MURO INTERIOR» es <em>evidencia</em>, no metros cuadrados. La cantidad exige
            interpretación, regla de medición y decisión profesional.
          </span>
        </div>
      </Alert>

      {/* Resumen de evidencia */}
      {summary && (
        <div className="grid gap-3 md:grid-cols-4">
          <Card className="p-4">
            <p className="text-[10px] font-bold uppercase tracking-widest text-fog">Clases IFC</p>
            <div className="mt-2 flex flex-wrap gap-1">
              {summary.clases.slice(0, 7).map((c) => (
                <button key={c.valor} onClick={() => setFilters((f) => ({ ...f, ifcClass: f.ifcClass === c.valor ? "" : c.valor }))}>
                  <Chip className={filters.ifcClass === c.valor ? "border-acc/60 bg-acc/15 font-mono text-acc" : "border-line bg-ink-750 font-mono text-mist hover:text-white"}>
                    {c.valor.replace(/^IFC/, "Ifc")} ×{c.total}
                  </Chip>
                </button>
              ))}
            </div>
          </Card>
          <Card className="p-4">
            <p className="text-[10px] font-bold uppercase tracking-widest text-fog">Materiales</p>
            <div className="mt-2 flex flex-wrap gap-1">
              {summary.materiales.slice(0, 6).map((m) => (
                <button key={m.valor} onClick={() => setFilters((f) => ({ ...f, material: f.material === m.valor ? "" : (m.valor === "(sin dato)" ? "" : m.valor) }))}>
                  <Chip className={filters.material === m.valor ? "border-acc/60 bg-acc/15 text-acc" : "border-line bg-ink-750 text-mist hover:text-white"}>
                    {m.valor} ×{m.total}
                  </Chip>
                </button>
              ))}
            </div>
          </Card>
          <Card className="p-4">
            <p className="text-[10px] font-bold uppercase tracking-widest text-fog">Niveles</p>
            <div className="mt-2 flex flex-wrap gap-1">
              {summary.niveles.slice(0, 6).map((m) => (
                <button key={m.valor} onClick={() => setFilters((f) => ({ ...f, level: f.level === m.valor ? "" : (m.valor === "(sin dato)" ? "" : m.valor) }))}>
                  <Chip className={filters.level === m.valor ? "border-acc/60 bg-acc/15 text-acc" : "border-line bg-ink-750 text-mist hover:text-white"}>
                    {m.valor} ×{m.total}
                  </Chip>
                </button>
              ))}
            </div>
          </Card>
          <Card className="p-4">
            <p className="text-[10px] font-bold uppercase tracking-widest text-fog">Propiedades personalizadas</p>
            <p className="mt-1 font-mono text-xl font-bold text-white">{summary.propiedades.length}</p>
            <p className="text-[10.5px] text-fog">
              claves de psets detectadas{summary.propiedades[0] ? ` · p. ej. ${summary.propiedades[0].clave}` : ""}
            </p>
          </Card>
        </div>
      )}

      {/* Filtros */}
      <Card className="flex flex-wrap items-end gap-2 p-3.5">
        <div className="w-40"><Select value={filters.ifcClass} onChange={(e) => setFilters({ ...filters, ifcClass: e.target.value })}>
          <option value="">Todas las clases</option>
          {summary?.clases.map((c) => <option key={c.valor} value={c.valor}>{c.valor}</option>)}
        </Select></div>
        <div className="w-40"><Select value={filters.level} onChange={(e) => setFilters({ ...filters, level: e.target.value })}>
          <option value="">Todos los niveles</option>
          {summary?.niveles.filter((n) => n.valor !== "(sin dato)").map((n) => <option key={n.valor} value={n.valor}>{n.valor}</option>)}
        </Select></div>
        <div className="w-44"><Select value={filters.material} onChange={(e) => setFilters({ ...filters, material: e.target.value })}>
          <option value="">Todos los materiales</option>
          {summary?.materiales.filter((n) => n.valor !== "(sin dato)").map((n) => <option key={n.valor} value={n.valor}>{n.valor}</option>)}
        </Select></div>
        <div className="w-44"><Select value={filters.sourceId} onChange={(e) => setFilters({ ...filters, sourceId: e.target.value })}>
          <option value="">Todas las fuentes</option>
          {summary?.fuentes.filter((f) => f.kind === "IFC").map((f) => <option key={f.id} value={f.id}>{f.name} ({f.elementos})</option>)}
        </Select></div>
        <div className="w-52"><Input placeholder="Buscar por nombre…" value={filters.q} onChange={(e) => setFilters({ ...filters, q: e.target.value })} /></div>
        <label className="flex cursor-pointer items-center gap-2 rounded-lg border border-line bg-ink-800 px-3 py-2 text-xs text-mist">
          <input type="checkbox" checked={filters.showExcluded} onChange={(e) => setFilters({ ...filters, showExcluded: e.target.checked })} className="accent-cyan-400" />
          Ver excluidos
        </label>
      </Card>

      {/* Visor 3D de lo filtrado */}
      {rows && rows.length > 0 && (
        <Card className="p-3.5">
          <div className="mb-2.5 flex flex-wrap items-center justify-between gap-2">
            <p className="text-[11px] font-bold uppercase tracking-widest text-fog">
              Visor 3D — verifique qué elemento es cuál y qué dimensión corresponde a cada eje
            </p>
            <Chip className="border-line bg-ink-750 text-mist">
              {rows.filter((r) => r.geometry).length} de {rows.length} con geometría
            </Chip>
          </div>
          <Viewer3D
            elements={rows.slice(0, 900)}
            height={360}
            selectedId={detail?.id ?? null}
            onSelect={(id) => setDetail(id ? rows.find((r) => r.id === id) ?? null : null)}
          />
        </Card>
      )}

      {/* Tabla de elementos */}
      {rows === null ? (
        <Spinner label="Leyendo elementos…" />
      ) : tableRows.length === 0 ? (
        <Empty icon={ScanSearch} title="Sin elementos para estos filtros" hint="Ajuste los filtros o importe más fuentes IFC." />
      ) : (
        <Card className="overflow-hidden">
          <div className="max-h-[560px] overflow-auto">
            <table className="w-full text-left text-xs">
              <thead className="sticky top-0 z-10 bg-ink-800 text-[10px] uppercase tracking-wider text-fog">
                <tr>
                  <th className="px-4 py-2.5 font-semibold">Clase</th>
                  <th className="px-4 py-2.5 font-semibold">Elemento / tipo</th>
                  <th className="px-4 py-2.5 font-semibold">Material</th>
                  <th className="px-4 py-2.5 font-semibold">Nivel</th>
                  <th className="px-4 py-2.5 font-semibold">Dimensiones / cantidades</th>
                  <th className="px-4 py-2.5 font-semibold">Fuente</th>
                  <th className="px-4 py-2.5 text-right font-semibold">Estado</th>
                </tr>
              </thead>
              <tbody>
                {tableRows.map((el) => (
                  <tr
                    key={el.id}
                    onClick={() => setDetail(el)}
                    className={`cursor-pointer border-t border-line/50 transition-colors hover:bg-ink-800/70 ${el.excluded ? "opacity-45" : ""}`}
                  >
                    <td className="px-4 py-2.5"><Chip className="border-cyan-400/25 bg-cyan-400/5 font-mono text-cyan-300">{el.ifcClass.replace(/^IFC/, "Ifc")}</Chip></td>
                    <td className="max-w-72 px-4 py-2.5">
                      <p className="truncate font-medium text-slate-100">{el.name ?? "(sin nombre)"}</p>
                      {el.typeName ? <p className="truncate text-[10.5px] text-fog">{el.typeName}</p> : null}
                    </td>
                    <td className="px-4 py-2.5 text-mist">{el.material ?? "—"}</td>
                    <td className="px-4 py-2.5 text-mist">{el.level ?? "—"}</td>
                    <td className="px-4 py-2.5 font-mono text-[11px] text-slate-300">{dimsBrief(el.dimensions)}</td>
                    <td className="px-4 py-2.5"><Chip className="border-line bg-ink-750 text-mist">{el.source?.name ?? "?"}</Chip></td>
                    <td className="px-4 py-2.5 text-right">
                      {el.excluded
                        ? <Chip className="border-rose-400/40 bg-rose-400/10 text-rose-300"><PackageX size={11} /> Excluido</Chip>
                        : <Chip className="border-emerald-400/30 bg-emerald-400/10 text-emerald-300"><PackageCheck size={11} /> Activo</Chip>}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <div className="border-t border-line bg-ink-800/60 px-4 py-2 text-[10.5px] text-fog">
            {tableRows.length} elementos (máx. 1500 por consulta) · clic en una fila para ver toda la evidencia
          </div>
        </Card>
      )}

      {/* Drawer de detalle */}
      <Drawer open={!!detail} onClose={() => setDetail(null)} title={detail ? (
        <span className="flex items-center gap-2">
          <Eye size={14} className="text-acc" />
          Evidencia del elemento
        </span>
      ) : ""}>
        {detail && (
          <div className="space-y-4">
            <div>
              <div className="flex items-center gap-2">
                <Chip className="border-cyan-400/40 bg-cyan-400/10 font-mono text-cyan-300">{detail.ifcClass}</Chip>
                {detail.excluded ? <Chip className="border-rose-400/40 bg-rose-400/10 text-rose-300">Excluido del análisis</Chip> : null}
              </div>
              <h4 className="mt-2 text-base font-bold text-white">{detail.name ?? "(sin nombre)"}</h4>
              {detail.typeName ? <p className="text-xs text-mist">Tipo: {detail.typeName}</p> : null}
            </div>

            <Card className="p-3.5">
              <p className="mb-1 text-[10px] font-bold uppercase tracking-widest text-fog">Identificación y procedencia</p>
              <Kv k="GlobalId IFC" v={<span className="break-all">{detail.globalId ?? "—"}</span>} mono />
              <Kv k="Fuente" v={detail.source?.name ?? "—"} />
              <Kv k="Disciplina" v={detail.source?.discipline ?? "—"} />
              <Kv k="Etiqueta" v={detail.tag ?? "—"} mono />
              <Kv k="ObjectType" v={detail.objectType ?? "—"} />
              <Kv k="Material" v={detail.material ?? "(sin dato)"} />
              <Kv k="Nivel" v={detail.level ?? "(sin dato)"} />
              <Kv k="Capa" v={detail.layer ?? "(sin dato)"} />
              <Kv k="Leído el" v={nuevaFecha(detail.createdAt)} />
            </Card>

            {detail.geometry && (
              <Card className="p-3.5">
                <p className="mb-2 text-[10px] font-bold uppercase tracking-widest text-fog">Geometría calculada del IFC</p>
                <Viewer3D elements={[detail]} height={220} />
                <div className="mt-2 grid grid-cols-3 gap-2 text-center">
                  {(["X (ancho)", "Y (profundidad)", "Z (altura)"] as const).map((lab, i) => (
                    <div key={lab} className="rounded-lg border border-line bg-ink-800 px-2 py-1.5">
                      <p className="font-mono text-sm font-bold text-white">{fmt(detail.geometry!.size[i], 3)}</p>
                      <p className="text-[9.5px] uppercase tracking-wide text-fog">{lab}</p>
                    </div>
                  ))}
                </div>
                <p className="mt-1.5 text-[10.5px] text-fog">Origen geométrico: {detail.geometry.kind}</p>
              </Card>
            )}

            <Card className="p-3.5">
              <p className="mb-1 flex items-center gap-1.5 text-[10px] font-bold uppercase tracking-widest text-fog">
                <RulerIcon size={11} /> Dimensiones utilizables para medir
              </p>
              {detail.dimensions && Object.values(detail.dimensions).some((v) => v != null) ? (
                Object.entries(detail.dimensions).filter(([, v]) => v != null).map(([k, v]) => (
                  <div key={k} className="border-b border-line/60 py-2 last:border-0">
                    <div className="flex items-start justify-between gap-4">
                      <span className="text-[11px] font-semibold uppercase tracking-[0.12em] text-fog">{DIM_LABEL[k] ?? k}</span>
                      <span className="text-right font-mono text-xs text-slate-200">{fmt(v, 3)}</span>
                    </div>
                    {detail.dimensionSources?.[k] && (
                      <p className={cx("mt-0.5 text-[10px]",
                        detail.dimensionSources[k].startsWith("cantidad IFC") ? "text-emerald-300/80" : "text-sky-300/70")}>
                        {detail.dimensionSources[k]}
                      </p>
                    )}
                  </div>
                ))
              ) : (
                <p className="py-1 text-[11px] text-fog">Sin dimensiones declaradas ni geometría: la medición deberá ser manual.</p>
              )}
            </Card>

            <Card className="p-3.5">
              <p className="mb-1 flex items-center gap-1.5 text-[10px] font-bold uppercase tracking-widest text-fog"><Database size={11} /> Cantidades IFC declaradas en el modelo</p>
              {detail.quantities && Object.keys(detail.quantities).length ? (
                Object.entries(detail.quantities).map(([k, v]) => <Kv key={k} k={k} v={fmt(v, 4)} mono />)
              ) : (
                <p className="py-1 text-[11px] text-fog">El elemento no trae IfcElementQuantity. BIMCost no inventará estas cantidades.</p>
              )}
            </Card>

            <Card className="p-3.5">
              <p className="mb-1 flex items-center gap-1.5 text-[10px] font-bold uppercase tracking-widest text-fog"><Braces size={11} /> Propiedades (Psets)</p>
              {detail.properties && Object.keys(detail.properties).length ? (
                Object.entries(detail.properties).map(([pset, props]) => (
                  <div key={pset} className="mb-2.5 last:mb-0">
                    <p className="mb-0.5 font-mono text-[10.5px] font-semibold text-acc">{pset}</p>
                    <div className="rounded-lg border border-line/60 bg-ink-800/50 px-2.5 py-1">
                      {Object.entries(props).map(([k, v]) => <Kv key={k} k={k} v={v === null ? "—" : String(v)} mono />)}
                    </div>
                  </div>
                ))
              ) : (
                <p className="py-1 text-[11px] text-fog">Sin conjuntos de propiedades.</p>
              )}
            </Card>

            <Alert tone="info">
              ¿La evidencia es incorrecta o no aplica? Excluya el elemento del análisis:{" "}
              <strong>la exclusión no elimina la evidencia original</strong> y queda registrada como decisión profesional.
            </Alert>

            <Btn
              variant={detail.excluded ? "ok" : "danger"}
              className="w-full"
              icon={detail.excluded ? PackageCheck : PackageX}
              loading={busyId === detail.id}
              onClick={() => toggleExclude(detail)}
            >
              {detail.excluded ? "Reincorporar al análisis" : "Excluir del análisis (conservando evidencia)"}
            </Btn>
          </div>
        )}
      </Drawer>
    </div>
  );
}
