"use client";

import type { ReactNode, ButtonHTMLAttributes, InputHTMLAttributes, SelectHTMLAttributes, Ref } from "react";
import { X, Loader2, type LucideIcon } from "lucide-react";

export function cx(...parts: (string | false | null | undefined)[]) {
  return parts.filter(Boolean).join(" ");
}

/* ------------------------------- Botón ----------------------------- */
type BtnProps = ButtonHTMLAttributes<HTMLButtonElement> & {
  variant?: "primary" | "ghost" | "danger" | "ok" | "warn";
  size?: "sm" | "md";
  icon?: LucideIcon;
  loading?: boolean;
};

export function Btn({ variant = "ghost", size = "md", icon: Icon, loading, className, children, disabled, ...rest }: BtnProps) {
  const base = "inline-flex items-center gap-1.5 rounded-lg border font-medium transition-all duration-150 disabled:opacity-40 disabled:pointer-events-none select-none";
  const sizes = size === "sm" ? "px-2.5 py-1.5 text-xs" : "px-3.5 py-2 text-sm";
  const variants: Record<string, string> = {
    primary: "border-transparent bg-acc text-ink-950 hover:brightness-110 bc-glow font-semibold",
    ghost: "border-line-strong bg-ink-750 text-slate-200 hover:border-acc/50 hover:text-white",
    danger: "border-rose-500/40 bg-rose-500/10 text-rose-300 hover:bg-rose-500/20",
    ok: "border-emerald-500/40 bg-emerald-500/10 text-emerald-300 hover:bg-emerald-500/20",
    warn: "border-amber-500/40 bg-amber-500/10 text-amber-300 hover:bg-amber-500/20",
  };
  return (
    <button className={cx(base, sizes, variants[variant], className)} disabled={disabled || loading} {...rest}>
      {loading ? <Loader2 size={size === "sm" ? 13 : 15} className="animate-spin" /> : Icon ? <Icon size={size === "sm" ? 13 : 15} /> : null}
      {children}
    </button>
  );
}

/* -------------------------------- Chip ------------------------------ */
export function Chip({ className, children, title }: { className?: string; children: ReactNode; title?: string }) {
  return (
    <span title={title} className={cx("inline-flex items-center gap-1 rounded-md border px-2 py-0.5 text-[11px] font-medium whitespace-nowrap", className ?? "border-line bg-ink-750 text-mist")}>
      {children}
    </span>
  );
}

export function StatusChip({ status, meta }: { status: string; meta: Record<string, { label: string; cls: string; dot: string }> }) {
  const m = meta[status] ?? { label: status, cls: "border-line bg-ink-750 text-mist", dot: "bg-slate-400" };
  return (
    <Chip className={m.cls}>
      <span className={cx("h-1.5 w-1.5 rounded-full", m.dot)} />
      {m.label}
    </Chip>
  );
}

/* -------------------------------- Card ------------------------------ */
export function Card({ className, children }: { className?: string; children: ReactNode }) {
  return <div className={cx("rounded-xl border border-line bg-ink-850", className)}>{children}</div>;
}

/* ----------------------------- Inputs -------------------------------- */
export function Input(props: InputHTMLAttributes<HTMLInputElement> & { ref?: Ref<HTMLInputElement> }) {
  return (
    <input
      {...props}
      className={cx(
        "w-full rounded-lg border border-line-strong bg-ink-800 px-3 py-2 text-sm text-slate-100 placeholder:text-fog outline-none focus:border-acc/60 transition-colors",
        props.className
      )}
    />
  );
}

export function Select(props: SelectHTMLAttributes<HTMLSelectElement>) {
  return (
    <select
      {...props}
      className={cx(
        "w-full rounded-lg border border-line-strong bg-ink-800 px-3 py-2 text-sm text-slate-100 outline-none focus:border-acc/60 transition-colors",
        props.className
      )}
    />
  );
}

export function Field({ label, hint, children }: { label: string; hint?: string; children: ReactNode }) {
  return (
    <label className="block">
      <span className="mb-1.5 block text-[11px] font-semibold uppercase tracking-[0.14em] text-mist">{label}</span>
      {children}
      {hint ? <span className="mt-1 block text-[11px] text-fog">{hint}</span> : null}
    </label>
  );
}

export function Textarea(props: React.TextareaHTMLAttributes<HTMLTextAreaElement>) {
  return (
    <textarea
      {...props}
      className={cx(
        "w-full rounded-lg border border-line-strong bg-ink-800 px-3 py-2 text-sm text-slate-100 placeholder:text-fog outline-none focus:border-acc/60 transition-colors min-h-[76px]",
        props.className
      )}
    />
  );
}

/* ------------------------------- Modal ------------------------------- */
export function Modal({ open, onClose, title, children, wide }: { open: boolean; onClose: () => void; title: ReactNode; children: ReactNode; wide?: boolean }) {
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/70 backdrop-blur-sm" onClick={onClose} />
      <div className={cx("relative w-full rounded-2xl border border-line-strong bg-ink-850 shadow-2xl bc-fade-up max-h-[88vh] overflow-y-auto", wide ? "max-w-3xl" : "max-w-lg")}>
        <div className="sticky top-0 z-10 flex items-center justify-between border-b border-line bg-ink-850/95 px-5 py-4 backdrop-blur">
          <h3 className="text-sm font-semibold text-white">{title}</h3>
          <button onClick={onClose} className="rounded-md p-1 text-mist hover:bg-ink-700 hover:text-white"><X size={16} /></button>
        </div>
        <div className="px-5 py-4">{children}</div>
      </div>
    </div>
  );
}

/* ------------------------------- Drawer ------------------------------ */
export function Drawer({ open, onClose, title, children, width }: { open: boolean; onClose: () => void; title: ReactNode; children: ReactNode; width?: string }) {
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-50">
      <div className="absolute inset-0 bg-black/60 backdrop-blur-[2px]" onClick={onClose} />
      <aside
        className="absolute right-0 top-0 h-full overflow-y-auto border-l border-line-strong bg-ink-850 shadow-2xl"
        style={{ width: width ?? "520px", maxWidth: "100vw" }}
      >
        <div className="sticky top-0 z-10 flex items-center justify-between border-b border-line bg-ink-850/95 px-5 py-4 backdrop-blur">
          <h3 className="text-sm font-semibold text-white">{title}</h3>
          <button onClick={onClose} className="rounded-md p-1 text-mist hover:bg-ink-700 hover:text-white"><X size={16} /></button>
        </div>
        <div className="px-5 py-4">{children}</div>
      </aside>
    </div>
  );
}

/* ------------------------------ Varios -------------------------------- */
export function Empty({ icon: Icon, title, hint, action }: { icon: LucideIcon; title: string; hint?: string; action?: ReactNode }) {
  return (
    <div className="flex flex-col items-center justify-center gap-2 rounded-xl border border-dashed border-line-strong bg-ink-850/50 px-6 py-14 text-center">
      <div className="rounded-xl border border-line bg-ink-800 p-3"><Icon size={22} className="text-acc" /></div>
      <p className="text-sm font-semibold text-slate-200">{title}</p>
      {hint ? <p className="max-w-md text-xs leading-relaxed text-mist">{hint}</p> : null}
      {action ? <div className="mt-3">{action}</div> : null}
    </div>
  );
}

export function Spinner({ label }: { label?: string }) {
  return (
    <div className="flex items-center justify-center gap-2 py-14 text-mist">
      <Loader2 size={16} className="animate-spin" />
      <span className="text-xs">{label ?? "Cargando…"}</span>
    </div>
  );
}

export function SectionTitle({ title, desc, right }: { title: string; desc?: string; right?: ReactNode }) {
  return (
    <div className="mb-4 flex flex-wrap items-end justify-between gap-3">
      <div>
        <h2 className="text-base font-bold tracking-tight text-white">{title}</h2>
        {desc ? <p className="mt-0.5 text-xs text-mist">{desc}</p> : null}
      </div>
      {right}
    </div>
  );
}

export function Alert({ tone = "info", children }: { tone?: "info" | "warn" | "ok" | "error"; children: ReactNode }) {
  const tones: Record<string, string> = {
    info: "border-sky-400/30 bg-sky-400/8 text-sky-200",
    warn: "border-amber-400/30 bg-amber-400/8 text-amber-200",
    ok: "border-emerald-400/30 bg-emerald-400/8 text-emerald-200",
    error: "border-rose-400/30 bg-rose-400/8 text-rose-200",
  };
  return <div className={cx("rounded-lg border px-3.5 py-2.5 text-xs leading-relaxed", tones[tone])}>{children}</div>;
}

export function Kv({ k, v, mono }: { k: string; v: ReactNode; mono?: boolean }) {
  return (
    <div className="flex items-start justify-between gap-4 border-b border-line/60 py-2 last:border-0">
      <span className="text-[11px] font-semibold uppercase tracking-[0.12em] text-fog">{k}</span>
      <span className={cx("text-right text-xs text-slate-200", mono && "font-mono")}>{v}</span>
    </div>
  );
}

export function HelpIcon({ text }: { text: string }) {
  return (
    <span title={text} className="inline-flex h-4 w-4 cursor-help items-center justify-center rounded-full border border-line-strong text-[9px] font-bold text-mist hover:border-acc/60 hover:text-acc">?</span>
  );
}
