"use client";

import { useEffect, useState } from "react";
import { BookOpen, Moon } from "lucide-react";

type Theme = "trabajo" | "lectura";

/**
 * Interruptor MODO TRABAJO (oscuro) ⇄ MODO LECTURA (crema).
 * Solo cambia el atributo data-theme del <html>; todos los colores
 * se resuelven en src/app/globals.css.
 */
export function ThemeToggle() {
  const [theme, setTheme] = useState<Theme>("trabajo");

  useEffect(() => {
    const saved = (localStorage.getItem("bc-theme") as Theme | null) ?? "trabajo";
    setTheme(saved);
  }, []);

  const apply = (next: Theme) => {
    setTheme(next);
    localStorage.setItem("bc-theme", next);
    if (next === "lectura") document.documentElement.setAttribute("data-theme", "lectura");
    else document.documentElement.removeAttribute("data-theme");
  };

  const isLectura = theme === "lectura";

  return (
    <button
      onClick={() => apply(isLectura ? "trabajo" : "lectura")}
      title={isLectura ? "Cambiar a modo trabajo (oscuro)" : "Cambiar a modo lectura (crema, descansa la vista)"}
      aria-label="Cambiar tema de la interfaz"
      className="flex items-center gap-1.5 rounded-lg border border-line bg-ink-800 px-2.5 py-1.5 text-[11px] font-semibold text-mist transition-colors hover:border-acc/50 hover:text-acc"
    >
      {isLectura ? <Moon size={13} /> : <BookOpen size={13} />}
      <span className="hidden sm:inline">{isLectura ? "Modo trabajo" : "Modo lectura"}</span>
    </button>
  );
}
