"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { Calculator, Coins, BookOpenCheck, FolderKanban, Sparkles } from "lucide-react";
import { cx } from "@/components/ui";
import { ThemeToggle } from "@/components/ThemeToggle";

export function Nav() {
  const pathname = usePathname();
  const links = [
    { href: "/", label: "Presupuestos", icon: FolderKanban, exact: true },
    { href: "/apus", label: "Catálogo de APUs", icon: Calculator, exact: false },
    { href: "/insumos", label: "Insumos & Precios", icon: Coins, exact: false },
  ];

  return (
    <header className="sticky top-0 z-40 border-b border-line bg-ink-900/90 backdrop-blur-md">
      <div className="mx-auto flex h-14 max-w-[1540px] items-center justify-between px-4 sm:px-6">
        {/* LOGO BUDGET */}
        <Link href="/" className="flex items-center gap-2.5">
          <span className="flex h-8 w-8 items-center justify-center rounded-lg border border-emerald-400/40 bg-emerald-400/10 text-emerald-400 shadow-[0_0_12px_rgba(16,185,129,0.25)]">
            <Calculator size={18} />
          </span>
          <span className="leading-none">
            <span className="block text-[13.5px] font-extrabold tracking-tight text-white">
              BIMCost <span className="text-emerald-400 font-black">Budget</span>
            </span>
            <span className="mt-0.5 block text-[9px] font-semibold uppercase tracking-[0.2em] text-fog">
              ¿CUÁNTO CUESTA? · APUs & .bcq
            </span>
          </span>
        </Link>

        {/* NAVEGACIÓN PRINCIPAL */}
        <nav className="flex items-center gap-1">
          {links.map((l) => {
            const active = l.exact ? pathname === l.href : pathname.startsWith(l.href);
            return (
              <Link
                key={l.href}
                href={l.href}
                className={cx(
                  "flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-xs font-semibold transition-colors",
                  active
                    ? "border border-emerald-400/30 bg-emerald-400/10 text-emerald-300"
                    : "text-mist hover:bg-ink-800 hover:text-white"
                )}
              >
                <l.icon size={14} className={active ? "text-emerald-400" : "text-fog"} />
                {l.label}
              </Link>
            );
          })}
          <span className="mx-1.5 h-4 w-px bg-line" />
          <ThemeToggle />
        </nav>
      </div>
    </header>
  );
}
