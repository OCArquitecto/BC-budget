"use client";

import { useEffect, useState, useMemo } from "react";
import { Coins, Search, Filter, Layers, Download, CheckCircle2, ChevronRight, BarChart3 } from "lucide-react";
import { Card, Chip, Input, Spinner, Btn, Alert, Drawer, cx } from "@/components/ui";
import { api, fmt } from "@/lib/client";
import type { InsumoCategory } from "@/db/schema";

export interface ResourceExplosionItem {
  insumoId?: string;
  code: string;
  name: string;
  unit: string;
  category: InsumoCategory;
  unitPrice: number;
  totalQuantity: number;
  totalCost: number;
  activitiesCount: number;
  participatingActivities: {
    activityCode: string;
    activityName: string;
    activityQuantity: number;
    unitConsumption: number;
    subtotalQuantity: number;
  }[];
}

const CATEGORY_TABS: { v: string; l: string; color: string }[] = [
  { v: "TODOS", l: "Todos los recursos", color: "text-white" },
  { v: "MATERIAL", l: "Materiales", color: "text-emerald-400" },
  { v: "MANO_DE_OBRA", l: "Mano de Obra", color: "text-amber-300" },
  { v: "EQUIPO", l: "Equipos y Herramientas", color: "text-sky-300" },
  { v: "TRANSPORTE", l: "Transporte", color: "text-violet-300" },
  { v: "SUBCONTRATO", l: "Subcontratos", color: "text-rose-300" },
];

export function ExplosionInsumos({ projectId, currency = "COP" }: { projectId: string; currency?: string }) {
  const [data, setData] = useState<{
    explosion: ResourceExplosionItem[];
    resumenPorCategoria: Record<InsumoCategory, { totalCost: number; itemsCount: number }>;
    granTotalCostoDirecto: number;
  } | null>(null);

  const [filterCat, setFilterCat] = useState("TODOS");
  const [q, setQ] = useState("");
  const [selectedInsumo, setSelectedInsumo] = useState<ResourceExplosionItem | null>(null);

  useEffect(() => {
    api<any>(`/api/budget/projects/${projectId}/explosion`).then(setData);
  }, [projectId]);

  const filtered = useMemo(() => {
    if (!data) return [];
    const needle = q.trim().toLowerCase();
    return data.explosion.filter((it) => {
      if (filterCat !== "TODOS" && it.category !== filterCat) return false;
      if (needle && !`${it.code} ${it.name}`.toLowerCase().includes(needle)) return false;
      return true;
    });
  }, [data, filterCat, q]);

  const money = (n: number) => `$ ${fmt(n, 0)}`;

  if (!data) return <Spinner label="Calculando explosión de insumos del proyecto…" />;

  return (
    <div className="space-y-5">
      {/* RESUMEN POR CATEGORÍAS */}
      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-5">
        {[
          { cat: "MATERIAL" as InsumoCategory, label: "Materiales", color: "text-emerald-400" },
          { cat: "MANO_DE_OBRA" as InsumoCategory, label: "Mano de Obra", color: "text-amber-300" },
          { cat: "EQUIPO" as InsumoCategory, label: "Equipos", color: "text-sky-300" },
          { cat: "TRANSPORTE" as InsumoCategory, label: "Transporte", color: "text-violet-300" },
          { cat: "SUBCONTRATO" as InsumoCategory, label: "Subcontratos", color: "text-rose-300" },
        ].map((c) => {
          const stats = data.resumenPorCategoria[c.cat] || { totalCost: 0, itemsCount: 0 };
          const pct = data.granTotalCostoDirecto > 0 ? (stats.totalCost / data.granTotalCostoDirecto) * 100 : 0;

          return (
            <div
              key={c.cat}
              className={cx(
                "cursor-pointer rounded-xl border border-line bg-ink-850 p-4 transition-colors hover:border-emerald-400/40",
                filterCat === c.cat && "border-emerald-400/60 bg-emerald-400/5"
              )}
              onClick={() => setFilterCat(filterCat === c.cat ? "TODOS" : c.cat)}
            >
              <p className="text-[10px] font-bold uppercase tracking-wider text-fog">{c.label}</p>
              <p className="mt-1 font-mono text-lg font-black text-white">{money(stats.totalCost)}</p>
              <div className="mt-1 flex items-center justify-between text-[11px] text-fog">
                <span>{stats.itemsCount} tipos de insumo</span>
                <span className={cx("font-bold font-mono", c.color)}>{fmt(pct, 1)}%</span>
              </div>
            </div>
          );
        })}
      </div>

      {/* FILTROS Y BÚSQUEDA */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex flex-wrap items-center gap-1.5">
          {CATEGORY_TABS.map((t) => (
            <button
              key={t.v}
              onClick={() => setFilterCat(t.v)}
              className={cx(
                "rounded-lg border px-3 py-1.5 text-xs font-semibold transition-colors",
                filterCat === t.v
                  ? "border-emerald-400/40 bg-emerald-400/10 text-emerald-300"
                  : "border-line bg-ink-800 text-mist hover:text-white"
              )}
            >
              {t.l}
            </button>
          ))}
        </div>

        <div className="relative w-64">
          <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-fog" />
          <Input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Buscar insumo..."
            className="pl-8 text-xs"
          />
        </div>
      </div>

      {/* TABLA DE EXPLOSIÓN */}
      <Card className="overflow-hidden">
        <div className="max-h-[540px] overflow-auto">
          <table className="w-full text-left text-xs">
            <thead className="sticky top-0 bg-ink-800 text-[10px] uppercase text-fog">
              <tr>
                <th className="w-24 px-4 py-2.5">Código</th>
                <th className="px-4 py-2.5">Insumo / Recurso</th>
                <th className="w-28 px-3 py-2.5">Categoría</th>
                <th className="w-20 px-2 py-2.5 text-center">Unidad</th>
                <th className="w-28 px-3 py-2.5 text-right">Cant. Requerida</th>
                <th className="w-28 px-3 py-2.5 text-right">Precio Unitario</th>
                <th className="w-36 px-4 py-2.5 text-right">Costo Total</th>
                <th className="w-20 px-3 py-2.5 text-center">Actividades</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((it, idx) => (
                <tr
                  key={idx}
                  onClick={() => setSelectedInsumo(it)}
                  className="cursor-pointer border-t border-line/40 transition-colors hover:bg-ink-800/60"
                >
                  <td className="px-4 py-2 font-mono font-bold text-emerald-400">{it.code}</td>
                  <td className="px-4 py-2 font-medium text-slate-100">{it.name}</td>
                  <td className="px-3 py-2">
                    <Chip className="border-line bg-ink-750 text-[10.5px]">
                      {it.category}
                    </Chip>
                  </td>
                  <td className="px-2 py-2 text-center font-mono text-fog">{it.unit}</td>
                  <td className="px-3 py-2 text-right font-mono font-bold text-white">
                    {fmt(it.totalQuantity, 2)}
                  </td>
                  <td className="px-3 py-2 text-right font-mono text-slate-300">
                    {money(it.unitPrice)}
                  </td>
                  <td className="px-4 py-2 text-right font-mono font-black text-emerald-300">
                    {money(it.totalCost)}
                  </td>
                  <td className="px-3 py-2 text-center">
                    <span className="rounded bg-ink-750 px-2 py-0.5 font-mono text-[11px] text-slate-300">
                      {it.activitiesCount}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>

      {/* DRAWER: DETALLE DE CONSUMO POR ACTIVIDAD */}
      <Drawer
        open={!!selectedInsumo}
        onClose={() => setSelectedInsumo(null)}
        title="Consumo de Insumo por Actividad"
      >
        {selectedInsumo && (
          <div className="space-y-4 text-xs">
            <div className="rounded-xl border border-emerald-400/40 bg-emerald-400/10 p-4">
              <span className="font-mono text-xs font-bold text-emerald-400">{selectedInsumo.code}</span>
              <h3 className="mt-1 text-base font-extrabold text-white">{selectedInsumo.name}</h3>
              <div className="mt-2 flex items-center justify-between">
                <span>Total Requerido: <strong className="font-mono text-white">{fmt(selectedInsumo.totalQuantity, 2)} {selectedInsumo.unit}</strong></span>
                <span className="font-mono font-black text-emerald-300">{money(selectedInsumo.totalCost)}</span>
              </div>
            </div>

            <p className="font-bold text-slate-200">Actividades que consumen este insumo ({selectedInsumo.participatingActivities.length}):</p>

            <div className="space-y-2 max-h-96 overflow-y-auto">
              {selectedInsumo.participatingActivities.map((pa, i) => (
                <div key={i} className="rounded-xl border border-line bg-ink-800/60 p-3">
                  <div className="flex items-center justify-between">
                    <span className="font-mono font-bold text-emerald-400">{pa.activityCode}</span>
                    <span className="font-mono text-slate-200">{fmt(pa.subtotalQuantity, 2)} {selectedInsumo.unit}</span>
                  </div>
                  <p className="mt-0.5 text-slate-200">{pa.activityName}</p>
                  <p className="mt-1 text-[11px] text-fog">
                    Cantidad actividad: {fmt(pa.activityQuantity, 2)} · Consumo unitario c/desp: {fmt(pa.unitConsumption, 4)}
                  </p>
                </div>
              ))}
            </div>

            <Btn className="w-full" onClick={() => setSelectedInsumo(null)}>Cerrar</Btn>
          </div>
        )}
      </Drawer>
    </div>
  );
}
