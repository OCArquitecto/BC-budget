"use client";

import { useCallback, useEffect, useState } from "react";
import Link from "next/link";
import {
  ArrowLeft, Calculator, Coins, GitCompare, Percent, FileText, Box,
  Building2, Layers, AlertCircle, RefreshCw, CheckCircle2, ChevronRight
} from "lucide-react";
import { Nav } from "@/components/Nav";
import { Btn, Chip, Spinner, cx } from "@/components/ui";
import { api, fmt } from "@/lib/client";

import { PresupuestoWbs } from "./PresupuestoWbs";
import { ExplosionInsumos } from "./ExplosionInsumos";
import { RevisionesDiff } from "./RevisionesDiff";
import { AiuConfig } from "./AiuConfig";
import { DocumentosPresupuesto } from "./DocumentosPresupuesto";
import { BudgetViewer } from "./BudgetViewer";

export interface BudgetProjectDetail {
  project: any;
  tree: any[];
  items: any[];
  revisions: any[];
  decisions: any[];
  financialSummary: {
    costoDirecto: number;
    administracion: number;
    imprevistos: number;
    utilidad: number;
    baseIva: number;
    iva: number;
    totalPresupuesto: number;
    porcentajes: {
      administracion: number;
      imprevistos: number;
      utilidad: number;
      iva: number;
      ivaBases: string[];
    };
    currency: string;
    stats: {
      totalActivities: number;
      withApu: number;
      withoutApu: number;
      pendingPriceReview: number;
      modifiedQuantity: number;
      pendingRevision: number;
    };
  };
}

type BudgetTabId = "presupuesto" | "visor" | "explosion" | "revisiones" | "configuracion" | "documentos";

export function BudgetWorkspace({ projectId }: { projectId: string }) {
  const [data, setData] = useState<BudgetProjectDetail | null>(null);
  const [tab, setTab] = useState<BudgetTabId>("presupuesto");
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(() => {
    api<BudgetProjectDetail>(`/api/budget/projects/${projectId}`)
      .then(setData)
      .catch((e) => setError(e.message));
  }, [projectId]);

  useEffect(() => {
    load();
  }, [load]);

  if (error) {
    return (
      <div className="min-h-screen">
        <Nav />
        <div className="mx-auto max-w-xl px-6 py-24 text-center">
          <p className="text-sm text-rose-300">{error}</p>
          <Link href="/" className="mt-4 inline-flex items-center gap-1 text-xs text-emerald-400">
            <ArrowLeft size={13} /> Volver al listado de presupuestos
          </Link>
        </div>
      </div>
    );
  }

  if (!data) {
    return (
      <div className="min-h-screen">
        <Nav />
        <Spinner label="Abriendo el presupuesto en BC Budget…" />
      </div>
    );
  }

  const { project, tree, financialSummary, revisions } = data;
  const stats = financialSummary.stats;
  const money = (n: number) => `$ ${fmt(n, 0)}`;

  const TABS: { id: BudgetTabId; label: string; icon: any; badge?: number; alert?: boolean }[] = [
    { id: "presupuesto", label: "Presupuesto (WBS)", icon: Calculator, badge: stats.withoutApu ? stats.withoutApu : undefined, alert: stats.withoutApu > 0 },
    { id: "visor", label: "Visor BIM", icon: Box },
    { id: "explosion", label: "Explosión de Insumos", icon: Coins },
    { id: "revisiones", label: "Revisiones .bcq & Diff", icon: GitCompare, badge: revisions.length },
    { id: "configuracion", label: "AIU, IVA & Empresa", icon: Percent },
    { id: "documentos", label: "Oferta & Documentos", icon: FileText },
  ];

  return (
    <div className="min-h-screen">
      <Nav />

      {/* ENCABEZADO SUPERIOR DEL PRESUPUESTO */}
      <div className="border-b border-line bg-ink-850/80 backdrop-blur-md">
        <div className="mx-auto max-w-[1540px] px-4 py-4 sm:px-6">
          <div className="flex flex-wrap items-start justify-between gap-4">
            <div>
              <div className="flex items-center gap-2">
                <Link href="/" className="rounded-md p-1 text-mist hover:bg-ink-700 hover:text-white" title="Volver a presupuestos">
                  <ArrowLeft size={15} />
                </Link>
                <span className="font-mono text-xs font-bold text-emerald-400">{project.code}</span>
                {project.sourceBcq?.revision && (
                  <Chip className="border-emerald-400/30 bg-emerald-400/10 font-mono text-emerald-300">
                    {project.sourceBcq.revision}
                  </Chip>
                )}
                {stats.withoutApu > 0 && (
                  <Chip className="border-amber-400/40 bg-amber-400/10 text-amber-300">
                    <AlertCircle size={11} /> {stats.withoutApu} sin APU validado
                  </Chip>
                )}
                {stats.pendingPriceReview > 0 && (
                  <Chip className="border-sky-400/40 bg-sky-400/10 text-sky-300">
                    {stats.pendingPriceReview} precios Quantity pendientes de actualizar
                  </Chip>
                )}
              </div>

              <h1 className="mt-1 text-xl font-black tracking-tight text-white">{project.name}</h1>
              <p className="text-xs text-mist">
                {project.client || "Sin cliente"} · {project.location || "Ubicación"}
              </p>
            </div>

            {/* CIFRAS FINANCIERAS RESUMEN */}
            <div className="flex items-center gap-3">
              <div className="flex items-center gap-4 rounded-xl border border-line bg-ink-800 px-4 py-2">
                <div>
                  <p className="text-[10px] font-bold uppercase tracking-wider text-fog">Costo Directo</p>
                  <p className="font-mono text-base font-bold text-slate-100">{money(financialSummary.costoDirecto)}</p>
                </div>
                <div className="h-7 w-px bg-line" />
                <div>
                  <p className="text-[10px] font-bold uppercase tracking-wider text-emerald-400">Total c/ AIU ({financialSummary.currency})</p>
                  <p className="font-mono text-lg font-black text-emerald-400">{money(financialSummary.totalPresupuesto)}</p>
                </div>
              </div>
            </div>
          </div>

          {/* PESTAÑAS */}
          <div className="mt-4 flex gap-1 overflow-x-auto pb-0.5">
            {TABS.map((t) => {
              const active = tab === t.id;
              return (
                <button
                  key={t.id}
                  onClick={() => setTab(t.id)}
                  className={cx(
                    "flex shrink-0 items-center gap-2 rounded-t-lg border-b-2 px-4 py-2 text-xs font-bold transition-colors",
                    active
                      ? "border-emerald-400 bg-ink-800 text-emerald-300"
                      : "border-transparent text-mist hover:bg-ink-800/50 hover:text-slate-200"
                  )}
                >
                  <t.icon size={14} className={active ? "text-emerald-400" : "text-fog"} />
                  <span>{t.label}</span>
                  {t.badge !== undefined && (
                    <span
                      className={cx(
                        "rounded px-1.5 py-0.2 font-mono text-[10px] font-bold",
                        t.alert
                          ? "bg-amber-400/20 text-amber-300"
                          : active
                            ? "bg-emerald-400/20 text-emerald-300"
                            : "bg-ink-700 text-mist"
                      )}
                    >
                      {t.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* CUERPO DE PESTAÑA */}
      <main className="mx-auto max-w-[1540px] px-4 py-6 sm:px-6">
        {tab === "presupuesto" && (
          <PresupuestoWbs
            projectId={projectId}
            tree={tree}
            onChanged={load}
            currency={project.currency}
            projectRegion={project.region || "COLOMBIA"}
            projectPriceDate={project.priceDate}
          />
        )}
        {tab === "visor" && <BudgetViewer projectId={projectId} />}
        {tab === "explosion" && <ExplosionInsumos projectId={projectId} currency={project.currency} />}
        {tab === "revisiones" && <RevisionesDiff projectId={projectId} revisions={revisions} onChanged={load} />}
        {tab === "configuracion" && <AiuConfig projectId={projectId} project={project} onChanged={load} />}
        {tab === "documentos" && (
          <DocumentosPresupuesto
            projectId={projectId}
            project={project}
            tree={tree}
            financialSummary={financialSummary}
          />
        )}
      </main>
    </div>
  );
}
