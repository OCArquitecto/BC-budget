"use client";

import { useEffect, useState } from "react";
import { Building2, Percent, Upload, Save, CheckCircle2, ShieldCheck, HelpCircle } from "lucide-react";
import { Card, Field, Input, Textarea, Btn, Alert, Chip, cx } from "@/components/ui";
import { api, fmt } from "@/lib/client";

const IVA_BASES: { v: "DIRECTO" | "ADMINISTRACION" | "IMPREVISTOS" | "UTILIDAD"; l: string; hint: string }[] = [
  { v: "UTILIDAD", l: "Utilidad", hint: "Uso estándar en Colombia (IVA sobre la utilidad del AIU)" },
  { v: "ADMINISTRACION", l: "Administración", hint: "Incluye la administración en la base gravable" },
  { v: "IMPREVISTOS", l: "Imprevistos", hint: "Incluye los imprevistos en la base gravable" },
  { v: "DIRECTO", l: "Costo Directo", hint: "IVA sobre el valor total de la obra (contratos gravados en su totalidad)" },
];

export function AiuConfig({
  projectId,
  project,
  onChanged,
}: {
  projectId: string;
  project: any;
  onChanged: () => void;
}) {
  const [company, setCompany] = useState<any>(project.company || {});
  const [projectInfo, setProjectInfo] = useState({
    name: project.name || "",
    client: project.client || "",
    location: project.location || "",
    region: project.region || project.location || "COLOMBIA",
    priceDate: project.priceDate ? new Date(project.priceDate).toISOString().slice(0, 10) : new Date().toISOString().slice(0, 10),
    description: project.description || "",
    currency: project.currency || "COP",
  });

  const st = project.settings || {};
  const [aiu, setAiu] = useState({
    administracion: String(st.administracion ?? 18),
    imprevistos: String(st.imprevistos ?? 3),
    utilidad: String(st.utilidad ?? 5),
    iva: String(st.iva ?? 19),
    ivaBases: (st.ivaBases || ["UTILIDAD"]) as ("DIRECTO" | "ADMINISTRACION" | "IMPREVISTOS" | "UTILIDAD")[],
    notes: st.notes || "",
  });

  const [busy, setBusy] = useState(false);
  const [notice, setNotice] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const onLogoUpload = (file: File) => {
    if (file.size > 2 * 1024 * 1024) {
      setError("El logo no debe superar 2 MB.");
      return;
    }
    const reader = new FileReader();
    reader.onload = () => setCompany((c: any) => ({ ...c, logo: String(reader.result) }));
    reader.readAsDataURL(file);
  };

  const save = async () => {
    setBusy(true);
    setError(null);
    try {
      await api(`/api/budget/projects/${projectId}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: projectInfo.name,
          client: projectInfo.client,
          location: projectInfo.location,
          region: projectInfo.region,
          priceDate: projectInfo.priceDate,
          description: projectInfo.description,
          currency: projectInfo.currency,
          company,
          settings: {
            ...st,
            administracion: Number(aiu.administracion.replace(",", ".")) || 0,
            imprevistos: Number(aiu.imprevistos.replace(",", ".")) || 0,
            utilidad: Number(aiu.utilidad.replace(",", ".")) || 0,
            iva: Number(aiu.iva.replace(",", ".")) || 0,
            ivaBases: aiu.ivaBases,
            currency: projectInfo.currency,
            notes: aiu.notes,
          },
          actor: "Presupuestador",
        }),
      });
      setNotice("Configuración presupuestal y de empresa guardada.");
      onChanged();
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="space-y-5">
      {notice && <Alert tone="ok">{notice}</Alert>}
      {error && <Alert tone="error">{error}</Alert>}

      {/* INFORMACIÓN DEL PROYECTO */}
      <Card className="p-5">
        <h3 className="mb-3 flex items-center gap-2 text-sm font-bold text-white">
          <Building2 size={16} className="text-emerald-400" /> Información General del Proyecto
        </h3>
        <div className="grid gap-3 sm:grid-cols-2">
          <Field label="Nombre del proyecto *">
            <Input value={projectInfo.name} onChange={(e) => setProjectInfo({ ...projectInfo, name: e.target.value })} />
          </Field>
          <Field label="Cliente / Contratante">
            <Input value={projectInfo.client} onChange={(e) => setProjectInfo({ ...projectInfo, client: e.target.value })} />
          </Field>
          <Field label="Ubicación del proyecto">
            <Input value={projectInfo.location} onChange={(e) => setProjectInfo({ ...projectInfo, location: e.target.value })} />
          </Field>
          <Field label="Zona de precios">
            <Input value={projectInfo.region} onChange={(e) => setProjectInfo({ ...projectInfo, region: e.target.value })} placeholder="ANTIOQUIA / BOGOTÁ / CARIBE…" />
          </Field>
          <Field label="Fecha de corte de precios">
            <Input type="date" value={projectInfo.priceDate} onChange={(e) => setProjectInfo({ ...projectInfo, priceDate: e.target.value })} />
          </Field>
          <Field label="Moneda de presupuestación">
            <Input value={projectInfo.currency} onChange={(e) => setProjectInfo({ ...projectInfo, currency: e.target.value.toUpperCase() })} className="font-mono uppercase font-bold" />
          </Field>
          <div className="sm:col-span-2">
            <Field label="Descripción / Alcance">
              <Textarea value={projectInfo.description} onChange={(e) => setProjectInfo({ ...projectInfo, description: e.target.value })} />
            </Field>
          </div>
        </div>
      </Card>

      {/* PORCENTAJES DE AIU & IVA */}
      <Card className="p-5">
        <h3 className="mb-2 flex items-center gap-2 text-sm font-bold text-white">
          <Percent size={16} className="text-emerald-400" /> Porcentajes de AIU (Administración, Imprevistos, Utilidad) e IVA
        </h3>
        <p className="mb-4 text-xs text-mist">
          Configuración económica para el cálculo de costos indirectos e impuestos sobre el Costo Directo.
        </p>

        <div className="grid gap-4 sm:grid-cols-4">
          <Field label="Administración %">
            <Input value={aiu.administracion} onChange={(e) => setAiu({ ...aiu, administracion: e.target.value })} className="font-mono text-sm" />
          </Field>
          <Field label="Imprevistos %">
            <Input value={aiu.imprevistos} onChange={(e) => setAiu({ ...aiu, imprevistos: e.target.value })} className="font-mono text-sm" />
          </Field>
          <Field label="Utilidad %">
            <Input value={aiu.utilidad} onChange={(e) => setAiu({ ...aiu, utilidad: e.target.value })} className="font-mono text-sm font-bold text-emerald-400" />
          </Field>
          <Field label="IVA %">
            <Input value={aiu.iva} onChange={(e) => setAiu({ ...aiu, iva: e.target.value })} className="font-mono text-sm" />
          </Field>
        </div>

        {/* BASE GRAVABLE DEL IVA */}
        <div className="mt-4 rounded-xl border border-line bg-ink-800/40 p-4">
          <p className="mb-1 text-xs font-bold uppercase tracking-wider text-slate-200">
            Base gravable del IVA (Selección múltiple)
          </p>
          <p className="mb-3 text-[11px] text-fog">
            Seleccione sobre qué conceptos del presupuesto se liquidará el porcentaje de IVA:
          </p>

          <div className="grid gap-2 sm:grid-cols-2">
            {IVA_BASES.map((b) => {
              const isChecked = aiu.ivaBases.includes(b.v);
              return (
                <button
                  key={b.v}
                  type="button"
                  onClick={() =>
                    setAiu({
                      ...aiu,
                      ivaBases: isChecked ? aiu.ivaBases.filter((x) => x !== b.v) : [...aiu.ivaBases, b.v],
                    })
                  }
                  className={cx(
                    "flex items-start gap-2.5 rounded-xl border p-3 text-left transition-colors",
                    isChecked ? "border-emerald-400/50 bg-emerald-400/10" : "border-line bg-ink-800 hover:border-line-strong"
                  )}
                >
                  <span
                    className={cx(
                      "mt-0.5 flex h-4 w-4 shrink-0 items-center justify-center rounded border text-[10px] font-bold",
                      isChecked ? "border-emerald-400 bg-emerald-400 text-slate-950" : "border-line-strong text-transparent"
                    )}
                  >
                    ✓
                  </span>
                  <div>
                    <span className={cx("block text-xs font-bold", isChecked ? "text-white" : "text-slate-300")}>
                      {b.l}
                    </span>
                    <span className="block text-[10.5px] text-fog">{b.hint}</span>
                  </div>
                </button>
              );
            })}
          </div>
        </div>
      </Card>

      {/* EMPRESA Y MEMBRETE */}
      <Card className="p-5">
        <h3 className="mb-3 flex items-center gap-2 text-sm font-bold text-white">
          <ShieldCheck size={16} className="text-emerald-400" /> Membrete de la Empresa Constructora / Consultora
        </h3>
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
          <Field label="Razón Social"><Input value={company.name || ""} onChange={(e) => setCompany({ ...company, name: e.target.value })} /></Field>
          <Field label="NIT / Identificación"><Input value={company.nit || ""} onChange={(e) => setCompany({ ...company, nit: e.target.value })} /></Field>
          <Field label="Dirección"><Input value={company.address || ""} onChange={(e) => setCompany({ ...company, address: e.target.value })} /></Field>
          <Field label="Teléfono"><Input value={company.phone || ""} onChange={(e) => setCompany({ ...company, phone: e.target.value })} /></Field>
          <Field label="Correo"><Input value={company.email || ""} onChange={(e) => setCompany({ ...company, email: e.target.value })} /></Field>
          <Field label="Profesional Responsable"><Input value={company.responsible || ""} onChange={(e) => setCompany({ ...company, responsible: e.target.value })} /></Field>
          <Field label="Cargo"><Input value={company.role || ""} onChange={(e) => setCompany({ ...company, role: e.target.value })} /></Field>
          <Field label="Matrícula Profesional"><Input value={company.license || ""} onChange={(e) => setCompany({ ...company, license: e.target.value })} /></Field>
        </div>

        <div className="mt-4 flex items-center gap-4">
          <label className="flex cursor-pointer items-center gap-2 rounded-lg border border-line-strong bg-ink-800 px-3 py-2 text-xs font-semibold text-slate-200 hover:border-emerald-400/50">
            <Upload size={14} className="text-emerald-400" /> {company.logo ? "Cambiar logo" : "Subir logo de la empresa"}
            <input type="file" accept="image/*" className="hidden" onChange={(e) => e.target.files?.[0] && onLogoUpload(e.target.files[0])} />
          </label>
          {company.logo && (
            <div className="flex items-center gap-2">
              <img src={company.logo} alt="Logo" className="h-10 max-w-40 rounded border border-line bg-white object-contain p-1" />
              <button type="button" onClick={() => setCompany({ ...company, logo: null })} className="text-xs text-rose-400 hover:underline">
                Quitar
              </button>
            </div>
          )}
        </div>
      </Card>

      <div className="flex justify-end">
        <Btn variant="primary" icon={Save} loading={busy} onClick={save} className="bg-emerald-500 font-bold text-slate-950 hover:bg-emerald-400">
          Guardar toda la configuración
        </Btn>
      </div>
    </div>
  );
}
