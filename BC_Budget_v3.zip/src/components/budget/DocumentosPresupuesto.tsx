"use client";

import React, { useEffect, useState } from "react";
import { Printer, FileSpreadsheet, Download, FileText, CheckCircle2, ShieldCheck, Building2, Package } from "lucide-react";
import { Card, Btn, Chip, cx } from "@/components/ui";
import { fmt } from "@/lib/client";

export function DocumentosPresupuesto({
  projectId,
  project,
  tree,
  financialSummary,
}: {
  projectId: string;
  project: any;
  tree: any[];
  financialSummary: any;
}) {
  const [tab, setTab] = useState<"presupuesto" | "capitulos">("presupuesto");
  const [priceLevels, setPriceLevels] = useState({ actividad: true, seccion: true, capitulo: true, total: true });
  const company = project.company || {};
  const st = project.settings || {};
  const fs = financialSummary || {};
  const dateStr = new Date().toLocaleDateString("es-ES", { day: "2-digit", month: "long", year: "numeric" });
  const money = (n: number) => `$ ${fmt(n, 0)}`;
  const levelParam = Object.entries(priceLevels).filter(([, v]) => v).map(([k]) => k).join(",");

  return (
    <div className="space-y-6">
      {/* BARRA SUPERIOR DE ACCIONES */}
      <div className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-line bg-ink-850 p-4">
        <div className="flex items-center gap-2">
          <button
            onClick={() => setTab("presupuesto")}
            className={cx(
              "rounded-lg px-3 py-1.5 text-xs font-bold transition-colors",
              tab === "presupuesto" ? "bg-emerald-400/15 text-emerald-300 border border-emerald-400/40" : "text-mist hover:text-white"
            )}
          >
            Presupuesto Detallado
          </button>
          <button
            onClick={() => setTab("capitulos")}
            className={cx(
              "rounded-lg px-3 py-1.5 text-xs font-bold transition-colors",
              tab === "capitulos" ? "bg-emerald-400/15 text-emerald-300 border border-emerald-400/40" : "text-mist hover:text-white"
            )}
          >
            Resumen por Capítulos
          </button>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <div className="mr-2 flex flex-wrap items-center gap-2 rounded-lg border border-line bg-ink-800 px-2 py-1">
            <span className="text-[9px] font-bold uppercase tracking-wider text-fog">Mostrar precios en</span>
            {Object.entries({ actividad: "Actividades", seccion: "Subcapítulos", capitulo: "Capítulos", total: "Total" }).map(([key, label]) => (
              <label key={key} className="flex cursor-pointer items-center gap-1 text-[10px] text-mist">
                <input type="checkbox" checked={priceLevels[key as keyof typeof priceLevels]}
                  onChange={(e) => setPriceLevels({ ...priceLevels, [key]: e.target.checked })} className="accent-emerald-400" />{label}
              </label>
            ))}
          </div>
          <a href={`/api/budget/projects/${projectId}/export?format=xlsx&levels=${levelParam}`} download>
            <Btn size="sm" icon={FileSpreadsheet}>
              Exportar Excel (.xlsx)
            </Btn>
          </a>
          <a href={`/api/budget/projects/${projectId}/export?format=csv&levels=${levelParam}`} download>
            <Btn size="sm" icon={Download}>
              Exportar CSV
            </Btn>
          </a>
          <a href={`/api/budget/projects/${projectId}/export-bcq`} download>
            <Btn size="sm" icon={Package}
              className="border-emerald-400/40 bg-emerald-400/10 font-bold text-emerald-300 hover:bg-emerald-400/20">
              Exportar .bcq enriquecido
            </Btn>
          </a>
          <Btn size="sm" variant="primary" icon={Printer} onClick={() => window.print()} className="bg-emerald-500 font-bold text-slate-950 hover:bg-emerald-400">
            Imprimir / Guardar PDF
          </Btn>
        </div>
      </div>

      {/* HOJA IMPRIMIBLE */}
      <div className="mx-auto max-w-[1000px] bg-white p-10 text-slate-900 shadow-2xl rounded-sm text-[11px] leading-relaxed">
        {/* ENCABEZADO CON LOGO */}
        <div className="flex items-start justify-between border-b-2 border-slate-900 pb-4">
          <div className="flex items-start gap-4">
            {company.logo ? (
              <img src={company.logo} alt="Logo" className="h-16 w-auto max-w-44 object-contain" />
            ) : (
              <div className="flex h-12 w-12 items-center justify-center rounded bg-slate-900 text-emerald-400 font-black text-xl">
                BC
              </div>
            )}
            <div>
              <h2 className="text-base font-black uppercase tracking-tight text-slate-900">
                {company.name || "CONSTRUCTORA & CONSULTORÍA"}
              </h2>
              <p className="text-[10px] text-slate-600">NIT: {company.nit || "900.000.000-1"}</p>
              <p className="text-[10px] text-slate-600">{company.address} {company.phone ? `· Tel: ${company.phone}` : ""}</p>
              <p className="text-[10px] text-slate-600">{company.email}</p>
            </div>
          </div>

          <div className="text-right">
            <span className="inline-block rounded bg-slate-100 px-2 py-0.5 font-mono text-[10px] font-bold text-slate-800">
              OFERTA ECONÓMICA
            </span>
            <p className="mt-1 font-mono text-xs font-bold text-slate-900">{project.code}</p>
            <p className="text-[10px] text-slate-500">{dateStr}</p>
            <p className="text-[9px] text-slate-400">Ecosistema BIMCost Budget</p>
          </div>
        </div>

        {/* METADATOS DEL PROYECTO */}
        <div className="my-5 grid grid-cols-2 gap-x-6 gap-y-1 rounded bg-slate-50 p-3 text-[10.5px] border border-slate-200">
          <p><span className="font-bold text-slate-700">Proyecto:</span> {project.name}</p>
          <p><span className="font-bold text-slate-700">Cliente:</span> {project.client || "—"}</p>
          <p><span className="font-bold text-slate-700">Ubicación:</span> {project.location || "—"}</p>
          <p><span className="font-bold text-slate-700">Responsable:</span> {company.responsible || "—"} {company.role ? `(${company.role})` : ""}</p>
        </div>

        {/* TABLA: PRESUPUESTO DETALLADO */}
        {tab === "presupuesto" ? (
          <table className="w-full border-collapse text-[10.5px]">
            <thead>
              <tr className="bg-slate-900 text-white text-[10px]">
                <th className="border border-slate-700 px-2 py-1.5 text-left font-bold">Ítem</th>
                <th className="border border-slate-700 px-2 py-1.5 text-left font-bold">Descripción de la Actividad</th>
                <th className="w-12 border border-slate-700 px-1 py-1.5 text-center font-bold">Und</th>
                <th className="w-20 border border-slate-700 px-2 py-1.5 text-right font-bold">Cantidad</th>
                <th className="w-24 border border-slate-700 px-2 py-1.5 text-right font-bold">Vr. Unitario</th>
                <th className="w-28 border border-slate-700 px-2 py-1.5 text-right font-bold">Vr. Total</th>
              </tr>
            </thead>
            <tbody>
              {tree.map((ch: any) => (
                <React.Fragment key={ch.code}>
                  {/* CAPITULO */}
                  <tr className="bg-slate-200 font-extrabold text-slate-900">
                    <td className="border border-slate-300 px-2 py-1 font-mono">{ch.code}</td>
                    <td className="border border-slate-300 px-2 py-1 uppercase" colSpan={4}>{ch.name}</td>
                    <td className="border border-slate-300 px-2 py-1 text-right font-mono font-bold">{priceLevels.capitulo ? money(ch.directCost) : ""}</td>
                  </tr>

                  {ch.sections.map((sec: any) => (
                    <React.Fragment key={sec.code}>
                      {/* SECCION */}
                      <tr className="bg-slate-100 font-semibold text-slate-700">
                        <td className="border border-slate-300 px-2 py-1 font-mono text-[9.5px]">{sec.code}</td>
                        <td className="border border-slate-300 px-2 py-1 text-[10px]" colSpan={4}>{sec.name}</td>
                        <td className="border border-slate-300 px-2 py-1 text-right font-mono text-[9.5px]">{priceLevels.seccion ? money(sec.directCost) : ""}</td>
                      </tr>

                      {/* ACTIVIDADES */}
                      {sec.activities.map((act: any) => {
                        const it = act.item;
                        return (
                          <tr key={act.id}>
                            <td className="border border-slate-300 px-2 py-1 font-mono text-[9.5px]">{act.code}</td>
                            <td className="border border-slate-300 px-2 py-1">{act.name}</td>
                            <td className="border border-slate-300 px-1 py-1 text-center font-mono">{act.unit || it?.unit}</td>
                            <td className="border border-slate-300 px-2 py-1 text-right font-mono tabular-nums">{fmt(it?.finalQuantity, 2)}</td>
                            <td className="border border-slate-300 px-2 py-1 text-right font-mono tabular-nums">{priceLevels.actividad ? money(it?.unitCost || 0) : ""}</td>
                            <td className="border border-slate-300 px-2 py-1 text-right font-mono font-bold tabular-nums">{priceLevels.actividad ? money(it?.directCost || 0) : ""}</td>
                          </tr>
                        );
                      })}
                    </React.Fragment>
                  ))}
                </React.Fragment>
              ))}
            </tbody>
          </table>
        ) : (
          /* TABLA: RESUMEN POR CAPÍTULOS */
          <table className="w-full border-collapse text-xs">
            <thead>
              <tr className="bg-slate-900 text-white text-[10px]">
                <th className="w-20 border border-slate-700 px-3 py-2 text-left font-bold">Capítulo</th>
                <th className="px-3 py-2 text-left font-bold">Descripción del Capítulo</th>
                <th className="w-36 border border-slate-700 px-3 py-2 text-right font-bold">Total Capítulo</th>
                <th className="w-20 border border-slate-700 px-3 py-2 text-right font-bold">% Incidencia</th>
              </tr>
            </thead>
            <tbody>
              {tree.map((ch: any) => {
                const pct = fs.costoDirecto > 0 ? (ch.directCost / fs.costoDirecto) * 100 : 0;
                return (
                  <tr key={ch.code} className="border-t border-slate-300">
                    <td className="px-3 py-2 font-mono font-bold">{ch.code}</td>
                    <td className="px-3 py-2 font-bold uppercase">{ch.name}</td>
                    <td className="px-3 py-2 text-right font-mono font-bold">{priceLevels.capitulo ? money(ch.directCost) : ""}</td>
                    <td className="px-3 py-2 text-right font-mono">{fmt(pct, 1)}%</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        )}

        {/* LIQUIDACIÓN DE AIU & TOTAL */}
        <div className="mt-6 flex justify-end">
          <table className="w-80 border-collapse text-[10.5px]">
            <tbody>
              <tr className="border-t border-slate-300">
                <td className="px-2 py-1 font-bold text-slate-700">COSTO DIRECTO:</td>
                <td className="px-2 py-1 text-right font-mono font-bold">{priceLevels.total ? money(fs.costoDirecto || 0) : ""}</td>
              </tr>
              <tr>
                <td className="px-2 py-1 text-slate-600">Administración ({fs.porcentajes?.administracion || 18}%):</td>
                <td className="px-2 py-1 text-right font-mono">{priceLevels.total ? money(fs.administracion || 0) : ""}</td>
              </tr>
              <tr>
                <td className="px-2 py-1 text-slate-600">Imprevistos ({fs.porcentajes?.imprevistos || 3}%):</td>
                <td className="px-2 py-1 text-right font-mono">{priceLevels.total ? money(fs.imprevistos || 0) : ""}</td>
              </tr>
              <tr>
                <td className="px-2 py-1 text-slate-600">Utilidad ({fs.porcentajes?.utilidad || 5}%):</td>
                <td className="px-2 py-1 text-right font-mono">{priceLevels.total ? money(fs.utilidad || 0) : ""}</td>
              </tr>
              <tr>
                <td className="px-2 py-1 text-slate-600">IVA ({fs.porcentajes?.iva || 19}% sobre {(fs.porcentajes?.ivaBases || ["UTILIDAD"]).join("+")}):</td>
                <td className="px-2 py-1 text-right font-mono">{priceLevels.total ? money(fs.iva || 0) : ""}</td>
              </tr>
              <tr className="bg-slate-900 text-white font-extrabold text-xs">
                <td className="px-2 py-2">TOTAL PRESUPUESTO:</td>
                <td className="px-2 py-2 text-right font-mono font-black">{priceLevels.total ? money(fs.totalPresupuesto || 0) : ""}</td>
              </tr>
            </tbody>
          </table>
        </div>

        {/* NOTAS Y FIRMAS */}
        <div className="mt-8 border-t border-slate-300 pt-3 text-[9.5px] text-slate-600">
          <p className="font-bold text-slate-700">Condiciones comerciales y notas:</p>
          <p className="mt-0.5">{st.notes || "Validez de la oferta: 30 días calendario. Precios sujetos a revisión por variación de insumos."}</p>
        </div>

        <div className="mt-12 flex justify-between gap-12 pt-4">
          <div className="flex-1 border-t border-slate-700 pt-1 text-[10px]">
            <p className="font-bold text-slate-800">Elaboró:</p>
            <p className="font-semibold text-slate-700">{company.responsible || "Ing. Responsable de Presupuesto"}</p>
            <p className="text-[9px] text-slate-500">{company.role} {company.license ? `· M.P. ${company.license}` : ""}</p>
          </div>
          <div className="flex-1 border-t border-slate-700 pt-1 text-[10px]">
            <p className="font-bold text-slate-800">Revisó y Aprobó:</p>
            <p className="font-semibold text-slate-700">Dirección de Proyectos</p>
            <p className="text-[9px] text-slate-500">Cliente / Contratante</p>
          </div>
        </div>
      </div>
    </div>
  );
}
