"use client";

import { useState, useRef } from "react";
import { GitCompare, RefreshCw, Upload, Sparkles, CheckCircle2, AlertCircle, ArrowRight, FileBox, Plus } from "lucide-react";
import { Card, Chip, Btn, Alert, Modal, Input, Field, cx } from "@/components/ui";
import { api, fmt, nuevaFecha } from "@/lib/client";

export interface RevisionRow {
  id: string;
  revisionNumber: number;
  revisionName: string;
  packageId: string | null;
  summary: any | null;
  importedBy: string | null;
  importedAt: string;
}

export function RevisionesDiff({
  projectId,
  revisions,
  onChanged,
}: {
  projectId: string;
  revisions: RevisionRow[];
  onChanged: () => void;
}) {
  const [selectedRev, setSelectedRev] = useState<RevisionRow | null>(revisions[0] || null);
  const [showUpload, setShowUpload] = useState(false);
  const [busy, setBusy] = useState(false);
  const [demoBusy, setDemoBusy] = useState(false);
  const [notice, setNotice] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const fileRef = useRef<HTMLInputElement>(null);

  const handleImportNewRevision = async () => {
    const file = fileRef.current?.files?.[0];
    if (!file) {
      setError("Seleccione un archivo .bcq");
      return;
    }
    setBusy(true);
    setError(null);
    try {
      const fd = new FormData();
      fd.append("file", file);
      fd.append("actor", "Presupuestador");

      const res = await fetch("/api/budget/import-bcq", { method: "POST", body: fd });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Error al importar revisión");

      setNotice(`Nueva revisión importada (${data.revision}): ${data.totalActivities} actividades procesadas.`);
      setShowUpload(false);
      onChanged();
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setBusy(false);
    }
  };

  const handleSimulateRev2 = async () => {
    setDemoBusy(true);
    setError(null);
    try {
      const data = await api<any>("/api/budget/import-bcq", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ sample: "CASA_SARA", revision: "REV-02", actor: "Muestra BIMCost" }),
      });
      setNotice(`Revisión REV-02 importada: los APUs asignados fueron preservados y las variaciones de cantidades han sido calculadas.`);
      onChanged();
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setDemoBusy(false);
    }
  };

  const currentDiff = selectedRev?.summary?.diffSummary;

  return (
    <div className="space-y-5">
      {notice && <Alert tone="ok">{notice}</Alert>}
      {error && <Alert tone="error">{error}</Alert>}

      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h3 className="text-sm font-bold text-white">Historial de Revisiones .bcq</h3>
          <p className="text-xs text-mist">
            Cuando el equipo de diseño actualiza el modelo y exporta una nueva revisión desde BC Quantity,
            Budget actualiza las cantidades preservando sus APUs y precios.
          </p>
        </div>
        <div className="flex gap-2">
          <Btn icon={Upload} onClick={() => setShowUpload(true)}>
            Importar nueva revisión .bcq
          </Btn>
          <Btn icon={Sparkles} loading={demoBusy} onClick={handleSimulateRev2}>
            Simular REV-02 (Ajuste de cubierta)
          </Btn>
        </div>
      </div>

      {/* LISTA DE REVISIONES */}
      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
        {revisions.map((rev) => {
          const isSelected = selectedRev?.id === rev.id;
          const diff = rev.summary?.diffSummary;

          return (
            <div
              key={rev.id}
              onClick={() => setSelectedRev(rev)}
              className={cx(
                "cursor-pointer rounded-xl border p-4 transition-all",
                isSelected
                  ? "border-emerald-400/60 bg-emerald-400/10 shadow-[0_4px_20px_rgba(16,185,129,0.15)]"
                  : "border-line bg-ink-850 hover:border-line-strong"
              )}
            >
              <div className="flex items-center justify-between">
                <span className="font-mono text-sm font-black text-emerald-400">{rev.revisionName}</span>
                <span className="font-mono text-[10px] text-fog">{nuevaFecha(rev.importedAt)}</span>
              </div>
              <p className="mt-1 text-xs text-slate-200">
                Importado por: <span className="font-semibold">{rev.importedBy || "Usuario"}</span>
              </p>

              <div className="mt-3 flex flex-wrap gap-1.5 text-[10.5px]">
                <Chip className="border-line bg-ink-750 font-mono">
                  {rev.summary?.totalActivities || 0} actividades
                </Chip>
                {diff?.activitiesModified?.length > 0 && (
                  <Chip className="border-amber-400/40 bg-amber-400/10 text-amber-300 font-mono">
                    {diff.activitiesModified.length} modificadas
                  </Chip>
                )}
                {diff?.activitiesAdded?.length > 0 && (
                  <Chip className="border-emerald-400/40 bg-emerald-400/10 text-emerald-300 font-mono">
                    +{diff.activitiesAdded.length} nuevas
                  </Chip>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* DETALLE Y DIFF DE LA REVISIÓN SELECCIONADA */}
      {selectedRev && (
        <Card className="p-5">
          <div className="mb-4 flex items-center justify-between border-b border-line pb-3">
            <div>
              <span className="text-[10px] font-bold uppercase tracking-wider text-fog">Detalle de Comparativo</span>
              <h4 className="text-base font-extrabold text-white">Revisión {selectedRev.revisionName}</h4>
            </div>
            {selectedRev.packageId && (
              <Chip className="border-line bg-ink-750 font-mono text-[11px] text-fog">
                Paquete: {selectedRev.packageId}
              </Chip>
            )}
          </div>

          {!currentDiff || (!currentDiff.activitiesModified?.length && !currentDiff.activitiesAdded?.length && !currentDiff.activitiesRemoved?.length) ? (
            <div className="py-8 text-center text-xs text-mist">
              <CheckCircle2 size={24} className="mx-auto mb-2 text-emerald-400" />
              Esta revisión inicial contiene la base de cantidades del proyecto ({selectedRev.summary?.totalActivities || 0} actividades).
            </div>
          ) : (
            <div className="space-y-4">
              {/* MODIFICADAS */}
              {currentDiff.activitiesModified?.length > 0 && (
                <div>
                  <p className="mb-2 text-xs font-bold uppercase tracking-wider text-amber-300">
                    Actividades con variaciones de cantidad ({currentDiff.activitiesModified.length})
                  </p>
                  <div className="overflow-auto rounded-xl border border-line">
                    <table className="w-full text-left text-xs">
                      <thead className="bg-ink-800 text-[10px] uppercase text-fog">
                        <tr>
                          <th className="px-3 py-2">Código</th>
                          <th className="px-3 py-2">Actividad</th>
                          <th className="px-3 py-2 text-right">Cant. Anterior</th>
                          <th className="px-3 py-2 text-right">Nueva Cant.</th>
                          <th className="px-3 py-2 text-right">Diferencia</th>
                        </tr>
                      </thead>
                      <tbody>
                        {currentDiff.activitiesModified.map((a: any) => (
                          <tr key={a.code} className="border-t border-line/40">
                            <td className="px-3 py-2 font-mono font-bold text-emerald-400">{a.code}</td>
                            <td className="px-3 py-2 text-slate-200">{a.name}</td>
                            <td className="px-3 py-2 text-right font-mono text-fog">{fmt(a.oldQuantity, 2)}</td>
                            <td className="px-3 py-2 text-right font-mono font-bold text-white">{fmt(a.newQuantity, 2)} {a.unit}</td>
                            <td className={cx("px-3 py-2 text-right font-mono font-bold", a.diff > 0 ? "text-emerald-400" : "text-rose-400")}>
                              {a.diff > 0 ? `+${fmt(a.diff, 2)}` : fmt(a.diff, 2)}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}

              {/* AÑADIDAS */}
              {currentDiff.activitiesAdded?.length > 0 && (
                <div>
                  <p className="mb-2 text-xs font-bold uppercase tracking-wider text-emerald-400">
                    Nuevas actividades añadidas ({currentDiff.activitiesAdded.length})
                  </p>
                  <div className="rounded-xl border border-line bg-ink-800/40 p-3">
                    {currentDiff.activitiesAdded.map((a: any) => (
                      <div key={a.code} className="flex items-center justify-between py-1 text-xs">
                        <span><strong className="font-mono text-emerald-400">{a.code}</strong> {a.name}</span>
                        <span className="font-mono text-slate-200">{fmt(a.quantity, 2)} {a.unit}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}
        </Card>
      )}

      {/* MODAL: SUBIR NUEVA REVISION */}
      <Modal open={showUpload} onClose={() => setShowUpload(false)} title="Importar nueva revisión .bcq">
        <div className="space-y-4">
          <Alert tone="info">
            Suba la nueva revisión <code className="font-mono">.bcq</code> exportada desde Quantity. Budget recalculará las cantidades preservando sus APUs.
          </Alert>

          <Field label="Archivo .bcq de la nueva revisión">
            <Input ref={fileRef} type="file" accept=".bcq,.zip" className="py-2 text-xs" />
          </Field>

          <div className="flex justify-end gap-2 pt-2">
            <Btn onClick={() => setShowUpload(false)}>Cancelar</Btn>
            <Btn variant="primary" icon={Upload} loading={busy} onClick={handleImportNewRevision}>
              Procesar revisión
            </Btn>
          </div>
        </div>
      </Modal>
    </div>
  );
}
