"use client";

import { useMemo, useState } from "react";
import { Search, Check, Coins, MapPin, CalendarDays } from "lucide-react";
import { Modal, Input, Select, Chip, Btn } from "@/components/ui";
import { fmt, nuevaFecha } from "@/lib/client";
import type { InsumoCategory } from "@/db/schema";

const CATS: { v: string; l: string }[] = [
  { v: "TODOS", l: "Todos" }, { v: "MATERIAL", l: "Materiales" },
  { v: "MANO_DE_OBRA", l: "Mano de obra" }, { v: "EQUIPO", l: "Equipos" },
  { v: "TRANSPORTE", l: "Transporte" }, { v: "SUBCONTRATO", l: "Subcontratos" },
];

export function InsumoPickerModal({ open, onClose, insumos, onPick, initialCategory }: {
  open: boolean;
  onClose: () => void;
  insumos: any[];
  onPick: (insumo: any) => void;
  initialCategory?: InsumoCategory;
}) {
  const [q, setQ] = useState("");
  const [cat, setCat] = useState(initialCategory ?? "TODOS");
  const filtered = useMemo(() => {
    const n = q.toLowerCase().trim();
    return insumos.filter((i) =>
      (cat === "TODOS" || i.category === cat) &&
      (!n || `${i.code} ${i.name} ${i.supplier ?? ""} ${i.source ?? ""} ${i.region ?? ""}`.toLowerCase().includes(n))
    ).slice(0, 250);
  }, [insumos, q, cat]);

  return (
    <Modal open={open} onClose={onClose} title="Buscar insumo en el catálogo de la empresa" wide>
      <div className="space-y-3">
        <div className="grid gap-2 sm:grid-cols-[1fr_190px]">
          <div className="relative">
            <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-fog" />
            <Input value={q} onChange={(e) => setQ(e.target.value)} className="pl-8"
              placeholder="Código, nombre completo, proveedor, fuente o región…" autoFocus />
          </div>
          <Select value={cat} onChange={(e) => setCat(e.target.value as InsumoCategory | "TODOS")}>
            {CATS.map((c) => <option key={c.v} value={c.v}>{c.l}</option>)}
          </Select>
        </div>
        <div className="max-h-[470px] overflow-auto rounded-xl border border-line">
          {filtered.length === 0 ? (
            <p className="p-10 text-center text-xs text-mist">No se encontraron insumos. Créelo desde “Insumos & Precios”.</p>
          ) : filtered.map((i) => (
            <button key={i.id} onClick={() => { onPick(i); onClose(); }}
              className="group grid w-full grid-cols-[100px_1fr_125px] items-center gap-3 border-b border-line/50 px-3 py-2.5 text-left last:border-0 hover:bg-ink-750">
              <div>
                <p className="font-mono text-[11px] font-bold text-emerald-400">{i.code}</p>
                <Chip className="mt-1 border-line bg-ink-800 text-[9px] text-mist">{i.category.replaceAll("_", " ")}</Chip>
              </div>
              <div className="min-w-0">
                <p className="text-xs font-semibold leading-relaxed text-slate-100">{i.name}</p>
                <div className="mt-1 flex flex-wrap gap-x-3 gap-y-1 text-[10px] text-fog">
                  <span>{i.unit}</span>
                  <span>{i.supplier || "Sin proveedor"}</span>
                  <span className="flex items-center gap-1"><MapPin size={9} />{i.region || "COLOMBIA"}</span>
                  <span className="flex items-center gap-1"><CalendarDays size={9} />{nuevaFecha(i.priceDate)}</span>
                </div>
                {i.source && <p className="mt-0.5 truncate text-[10px] text-fog">Fuente: {i.source}</p>}
              </div>
              <div className="text-right">
                <p className="font-mono text-sm font-black text-white">$ {fmt(i.unitPrice, 0)}</p>
                <p className="font-mono text-[10px] text-fog">/{i.unit} · {i.currency}</p>
                <Check size={13} className="ml-auto mt-1 text-emerald-400 opacity-0 group-hover:opacity-100" />
              </div>
            </button>
          ))}
        </div>
        <div className="flex items-center justify-between text-[10.5px] text-fog">
          <span>{filtered.length} resultado(s) visibles de {insumos.length}</span>
          <Btn size="sm" onClick={onClose}>Cerrar</Btn>
        </div>
      </div>
    </Modal>
  );
}
