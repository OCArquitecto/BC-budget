"use client";

import { useState } from "react";
import {
  Calculator, Coins, ChevronDown, ChevronRight, PencilLine,
  CheckCircle2, AlertCircle, RefreshCw, Layers, ShieldCheck,
  FileBox, HelpCircle, ArrowRight, Wand2, Sparkles, Trash2, SlidersHorizontal, Plus
} from "lucide-react";
import { Btn, Card, Chip, Modal, Input, Textarea, Drawer, Alert, Field, Select, cx } from "@/components/ui";
import { api, fmt } from "@/lib/client";
import { ApuPickerModal, type MasterApuSummary } from "./ApuPickerModal";
import { ApuEditorModal, type ApuComponentItem } from "./ApuEditorModal";

export interface BudgetItemRow {
  id: string;
  nodeId: string;
  activityCode: string;
  activityName: string;
  unit: string;
  quantityBcq: number;
  quantityOverride: number | null;
  overrideReason: string | null;
  finalQuantity: number;
  referenceUnitPrice: number;
  referencePriceSource: string | null;
  priceReviewRequired: boolean;
  apuId: string | null;
  customApu: any | null;
  unitCost: number;
  directCost: number;
  sourceMeta: any | null;
  status: "APU_ASIGNADO" | "SIN_APU" | "CANTIDAD_MODIFICADA" | "REVISION_PENDIENTE";
  notes: string | null;
}

export interface WbsSection {
  id: string;
  code: string;
  name: string;
  directCost: number;
  activities: {
    id: string;
    code: string;
    name: string;
    unit: string | null;
    item?: BudgetItemRow;
  }[];
}

export interface WbsChapter {
  id: string;
  code: string;
  name: string;
  directCost: number;
  sections: WbsSection[];
}

export function PresupuestoWbs({
  projectId,
  tree,
  onChanged,
  currency = "COP",
  projectRegion = "COLOMBIA",
  projectPriceDate,
}: {
  projectId: string;
  tree: WbsChapter[];
  onChanged: () => void;
  currency?: string;
  projectRegion?: string;
  projectPriceDate?: string;
}) {
  const [openChapters, setOpenChapters] = useState<Record<string, boolean>>({});
  const [pickingApuFor, setPickingApuFor] = useState<BudgetItemRow | null>(null);
  const [editingApuFor, setEditingApuFor] = useState<BudgetItemRow | null>(null);
  const [overrideModalFor, setOverrideModalFor] = useState<BudgetItemRow | null>(null);
  const [overrideValue, setOverrideValue] = useState("");
  const [overrideReason, setOverrideReason] = useState("");
  const [traceabilityFor, setTraceabilityFor] = useState<BudgetItemRow | null>(null);
  const [busy, setBusy] = useState(false);
  const [notice, setNotice] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [structureModal, setStructureModal] = useState<{
    mode: "create" | "edit"; kind: "CAPITULO" | "SECCION" | "ACTIVIDAD";
    node?: any; parentId?: string | null;
  } | null>(null);
  const [structureForm, setStructureForm] = useState({ code: "", name: "", unit: "UND", quantity: "0", referenceUnitPrice: "0" });

  const toggleChapter = (chCode: string) => {
    setOpenChapters((prev) => ({
      ...prev,
      [chCode]: prev[chCode] === undefined ? false : !prev[chCode],
    }));
  };

  const handlePickMasterApu = async (apu: MasterApuSummary) => {
    if (!pickingApuFor) return;
    setBusy(true);
    try {
      await api(`/api/budget/projects/${projectId}/items`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          itemId: pickingApuFor.id,
          action: "assign_apu",
          apuId: apu.id,
        }),
      });
      setNotice(`APU «${apu.name}» asignado a ${pickingApuFor.activityCode}.`);
      setPickingApuFor(null);
      onChanged();
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setBusy(false);
    }
  };

  const handleSaveCustomApu = async (apuData: any) => {
    if (!editingApuFor) return;
    setBusy(true);
    try {
      if (apuData.saveToMaster) {
        const d = await api<{ apu: MasterApuSummary }>("/api/budget/apus", {
          method: "POST", headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ ...apuData, actor: "Presupuestador" }),
        });
        await api(`/api/budget/projects/${projectId}/items`, {
          method: "PATCH", headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ itemId: editingApuFor.id, action: "assign_apu", apuId: d.apu.id, actor: "Presupuestador" }),
        });
        setNotice(`Versión ${apuData.versionLabel} guardada en el banco de la empresa y asignada a ${editingApuFor.activityCode}.`);
      } else {
        await api(`/api/budget/projects/${projectId}/items`, {
          method: "PATCH", headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ itemId: editingApuFor.id, action: "custom_apu", customApu: apuData, actor: "Presupuestador" }),
        });
        setNotice(`APU específico del proyecto guardado para ${editingApuFor.activityCode}.`);
      }
      setEditingApuFor(null);
      onChanged();
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setBusy(false);
    }
  };

  const handleSaveOverride = async () => {
    if (!overrideModalFor) return;
    setBusy(true);
    try {
      const val = overrideValue.trim() === "" ? null : Number(overrideValue.replace(",", "."));
      await api(`/api/budget/projects/${projectId}/items`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          itemId: overrideModalFor.id,
          action: "override_quantity",
          quantityOverride: val,
          overrideReason,
        }),
      });
      setNotice(`Cantidad actualizada para ${overrideModalFor.activityCode}.`);
      setOverrideModalFor(null);
      onChanged();
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setBusy(false);
    }
  };

  const openStructure = (mode: "create" | "edit", kind: "CAPITULO" | "SECCION" | "ACTIVIDAD", node?: any, parentId?: string | null) => {
    setStructureModal({ mode, kind, node, parentId });
    setStructureForm({
      code: node?.code || "", name: node?.name || "", unit: node?.unit || "UND",
      quantity: node?.item?.finalQuantity != null ? String(node.item.finalQuantity) : "0",
      referenceUnitPrice: node?.item?.referenceUnitPrice != null ? String(node.item.referenceUnitPrice) : "0",
    });
  };
  const saveStructure = async () => {
    if (!structureModal) return;
    setBusy(true); setError(null);
    try {
      const body = structureModal.mode === "create"
        ? { kind: structureModal.kind, parentId: structureModal.parentId, ...structureForm, actor: "Presupuestador" }
        : { nodeId: structureModal.node.id, code: structureForm.code, name: structureForm.name, unit: structureForm.unit, actor: "Presupuestador" };
      await api(`/api/budget/projects/${projectId}/structure`, {
        method: structureModal.mode === "create" ? "POST" : "PATCH",
        headers: { "Content-Type": "application/json" }, body: JSON.stringify(body),
      });
      setNotice(`${structureModal.kind.toLowerCase()} ${structureModal.mode === "create" ? "creado" : "actualizado"}.`);
      setStructureModal(null); onChanged();
    } catch (e) { setError((e as Error).message); } finally { setBusy(false); }
  };
  const deleteStructure = async (node: any) => {
    if (!confirm(`¿Eliminar ${node.code} — ${node.name}${node.kind !== "ACTIVIDAD" ? " y todos sus descendientes" : ""}?`)) return;
    try {
      await api(`/api/budget/projects/${projectId}/structure?nodeId=${node.id}&actor=Presupuestador`, { method: "DELETE" });
      setNotice(`${node.code} retirado de la estructura; la decisión quedó auditada.`); onChanged();
    } catch (e) { setError((e as Error).message); }
  };

  const money = (n: number) => `$ ${fmt(n, 0)}`;
  const allItems = tree.flatMap((ch) => ch.sections.flatMap((sec) => sec.activities.map((a) => a.item).filter(Boolean))) as BudgetItemRow[];
  const pendingPriceReview = allItems.filter((it) => it.priceReviewRequired).length;

  return (
    <div className="space-y-4">
      {notice && <Alert tone="ok">{notice}</Alert>}
      {error && <Alert tone="error">{error}</Alert>}
      {pendingPriceReview > 0 && (
        <Alert tone="warn">
          <strong>{pendingPriceReview} actividad(es)</strong> conservan el precio unitario traído del catálogo de Quantity,
          pero todavía no tienen un APU de empresa validado para {projectRegion} y la fecha de este proyecto.
          Use “Asignar APU” o cree una nueva versión; Budget guardará esa experiencia para los siguientes proyectos.
        </Alert>
      )}

      <div className="flex justify-end">
        <Btn size="sm" icon={Plus} onClick={() => openStructure("create", "CAPITULO")}>Añadir capítulo</Btn>
      </div>

      {tree.length === 0 ? (
        <Card className="p-12 text-center text-sm text-mist">
          La estructura presupuestal está vacía. Importe un archivo <code className="text-emerald-400">.bcq</code> para comenzar.
        </Card>
      ) : (
        <div className="space-y-3">
          {tree.map((ch) => {
            const isOpen = openChapters[ch.code] !== false;
            const nActivities = ch.sections.reduce((acc, s) => acc + s.activities.length, 0);

            return (
              <Card key={ch.code} className="overflow-hidden">
                {/* ENCABEZADO DE CAPÍTULO */}
                <button
                  onClick={() => toggleChapter(ch.code)}
                  className="flex w-full items-center justify-between border-b border-line bg-ink-800/80 px-4 py-3 text-left transition-colors hover:bg-ink-800"
                >
                  <div className="flex items-center gap-2.5">
                    {isOpen ? <ChevronDown size={16} className="text-emerald-400" /> : <ChevronRight size={16} className="text-fog" />}
                    <span className="font-mono text-xs font-bold text-emerald-400">{ch.code}</span>
                    <span className="text-xs font-black tracking-wide text-white uppercase">{ch.name}</span>
                    <Chip className="border-line bg-ink-750 text-mist">{nActivities} ítems</Chip>
                  </div>
                  <div className="flex items-center gap-1" onClick={(e) => e.stopPropagation()}>
                    <button onClick={() => openStructure("create", "SECCION", undefined, ch.id)} className="rounded p-1 text-fog hover:text-emerald-400" title="Añadir subcapítulo"><Plus size={12} /></button>
                    <button onClick={() => openStructure("edit", "CAPITULO", ch)} className="rounded p-1 text-fog hover:text-amber-300" title="Editar capítulo"><PencilLine size={12} /></button>
                    <button onClick={() => deleteStructure(ch)} className="rounded p-1 text-fog hover:text-rose-400" title="Eliminar capítulo"><Trash2 size={12} /></button>
                    <span className="ml-2 font-mono text-sm font-black text-emerald-400">{money(ch.directCost)}</span>
                  </div>
                </button>

                {/* SECCIONES Y ACTIVIDADES */}
                {isOpen &&
                  ch.sections.map((sec) => (
                    <div key={sec.code} className="border-b border-line/60 last:border-0">
                      {/* TITULO DE SECCION */}
                      <div className="flex items-center justify-between bg-ink-850 px-4 py-2 pl-8 text-xs font-semibold text-slate-300">
                        <div className="flex items-center gap-2">
                          <span className="font-mono text-fog">{sec.code}</span>
                          <span>{sec.name}</span>
                        </div>
                        <div className="flex items-center gap-1">
                          <button onClick={() => openStructure("create", "ACTIVIDAD", undefined, sec.id)} className="rounded p-1 text-fog hover:text-emerald-400" title="Añadir actividad"><Plus size={12} /></button>
                          <button onClick={() => openStructure("edit", "SECCION", sec)} className="rounded p-1 text-fog hover:text-amber-300" title="Editar subcapítulo"><PencilLine size={12} /></button>
                          <button onClick={() => deleteStructure(sec)} className="rounded p-1 text-fog hover:text-rose-400" title="Eliminar subcapítulo"><Trash2 size={12} /></button>
                          <span className="ml-2 font-mono text-xs text-mist">{money(sec.directCost)}</span>
                        </div>
                      </div>

                      {/* TABLA DE ACTIVIDADES / LÍNEAS DE PRESUPUESTO */}
                      <table className="w-full text-left text-xs">
                        <thead className="bg-ink-900/60 text-[10px] uppercase text-fog">
                          <tr>
                            <th className="w-24 px-4 py-2 pl-12">Ítem</th>
                            <th className="px-4 py-2">Actividad / Descripción</th>
                            <th className="w-16 px-2 py-2 text-center">Und</th>
                            <th className="w-24 px-2 py-2 text-right">Cant. BCQ</th>
                            <th className="w-28 px-2 py-2 text-right">Cant. Final</th>
                            <th className="w-48 px-3 py-2">APU Asignado</th>
                            <th className="w-28 px-3 py-2 text-right">Costo Unit.</th>
                            <th className="w-32 px-4 py-2 text-right">Costo Directo</th>
                            <th className="w-24 px-3 py-2 text-right">Acciones</th>
                          </tr>
                        </thead>
                        <tbody>
                          {sec.activities.map((act) => {
                            const it = act.item;
                            if (!it) return null;

                            const isModified = it.status === "CANTIDAD_MODIFICADA";
                            const isPendingRev = it.status === "REVISION_PENDIENTE";
                            const hasApu = !!(it.apuId || it.customApu);

                            return (
                              <tr
                                key={act.id}
                                className={cx(
                                  "border-t border-line/40 transition-colors hover:bg-ink-800/60",
                                  isPendingRev && "bg-sky-400/5",
                                  isModified && "bg-amber-400/5"
                                )}
                              >
                                <td className="px-4 py-2.5 pl-12 font-mono font-bold text-emerald-400">
                                  {act.code}
                                </td>
                                <td className="max-w-xs px-4 py-2.5">
                                  <p className="font-medium text-slate-100">{act.name}</p>
                                  {it.sourceMeta && (
                                    <div className="mt-0.5 flex flex-wrap items-center gap-1.5 text-[10.5px]">
                                      {it.sourceMeta.elementCount > 0 && (
                                        <button
                                          onClick={() => setTraceabilityFor(it)}
                                          className="inline-flex items-center gap-1 text-fog hover:text-emerald-400"
                                        >
                                          <FileBox size={11} /> {it.sourceMeta.elementCount} elem. IFC
                                        </button>
                                      )}
                                      {it.sourceMeta.derivedFrom && (
                                        <span className="font-mono text-violet-300">
                                          ← Derivada de {it.sourceMeta.derivedFrom.activityCode}
                                        </span>
                                      )}
                                      {it.overrideReason && (
                                        <span className="italic text-amber-300">«{it.overrideReason}»</span>
                                      )}
                                      {it.referenceUnitPrice > 0 && (
                                        <span className="font-mono text-sky-300">PU Quantity: $ {fmt(it.referenceUnitPrice, 0)}/{it.unit}</span>
                                      )}
                                    </div>
                                  )}
                                </td>
                                <td className="px-2 py-2.5 text-center">
                                  <Chip className="border-line-strong bg-ink-750 font-mono text-slate-200">
                                    {act.unit || it.unit}
                                  </Chip>
                                </td>
                                <td className="px-2 py-2.5 text-right font-mono text-mist">
                                  {fmt(it.quantityBcq, 2)}
                                </td>
                                <td className="px-2 py-2.5 text-right">
                                  <button
                                    onClick={() => {
                                      setOverrideModalFor(it);
                                      setOverrideValue(it.quantityOverride !== null ? String(it.quantityOverride) : "");
                                      setOverrideReason(it.overrideReason || "");
                                    }}
                                    className="group inline-flex items-center gap-1 font-mono font-bold text-white hover:text-amber-300"
                                    title="Ajustar cantidad para presupuesto"
                                  >
                                    <span className={cx(isModified && "text-amber-300 font-black")}>
                                      {fmt(it.finalQuantity, 2)}
                                    </span>
                                    <PencilLine size={11} className="opacity-0 group-hover:opacity-100 text-fog" />
                                  </button>
                                </td>

                                {/* APU ASIGNADO */}
                                <td className="px-3 py-2.5">
                                  {hasApu ? (
                                    <div className="flex items-center justify-between gap-1">
                                      <button
                                        onClick={() => setEditingApuFor(it)}
                                        className="max-w-[150px] truncate text-left text-xs font-semibold text-emerald-300 hover:underline"
                                        title="Ver o editar desglose del APU"
                                      >
                                        {it.customApu ? it.customApu.name : "APU Maestro Asignado"}
                                      </button>
                                      <button
                                        onClick={() => setPickingApuFor(it)}
                                        className="text-fog hover:text-emerald-400"
                                        title="Cambiar APU"
                                      >
                                        <SlidersHorizontal size={12} />
                                      </button>
                                    </div>
                                  ) : (
                                    <div className="space-y-1">
                                      {it.referenceUnitPrice > 0 && (
                                        <Chip className="border-sky-400/35 bg-sky-400/10 text-[9.5px] text-sky-300">precio Quantity · pendiente validar</Chip>
                                      )}
                                      <button
                                        onClick={() => setPickingApuFor(it)}
                                        className="inline-flex items-center gap-1 rounded-md border border-amber-400/30 bg-amber-400/10 px-2 py-1 text-[11px] font-semibold text-amber-300 hover:bg-amber-400/20"
                                      >
                                        <Calculator size={11} /> Ver sugerencias / asignar
                                      </button>
                                    </div>
                                  )}
                                </td>

                                <td className="px-3 py-2.5 text-right font-mono text-slate-200">
                                  {it.unitCost > 0 ? (
                                    <span className={it.priceReviewRequired ? "text-sky-300" : "text-slate-200"} title={it.priceReviewRequired ? "Precio importado de Quantity pendiente de validar" : "Costo directo unitario del APU"}>
                                      {money(it.unitCost)}
                                    </span>
                                  ) : <span className="text-fog">—</span>}
                                </td>
                                <td className="px-4 py-2.5 text-right font-mono font-bold text-white">
                                  {it.directCost > 0 ? money(it.directCost) : <span className="text-fog">$ 0</span>}
                                </td>

                                <td className="px-3 py-2.5 text-right">
                                  <button onClick={() => openStructure("edit", "ACTIVIDAD", { ...act, item: it })}
                                    className="rounded p-1.5 text-fog hover:bg-ink-700 hover:text-amber-300" title="Editar actividad"><PencilLine size={13} /></button>
                                  <button onClick={() => deleteStructure({ ...act, kind: "ACTIVIDAD" })}
                                    className="rounded p-1.5 text-fog hover:bg-rose-500/15 hover:text-rose-400" title="Eliminar actividad"><Trash2 size={13} /></button>
                                  <button
                                    onClick={() => setTraceabilityFor(it)}
                                    className="rounded p-1.5 text-fog hover:bg-ink-700 hover:text-white"
                                    title="Trazabilidad .bcq"
                                  >
                                    <HelpCircle size={14} />
                                  </button>
                                </td>
                              </tr>
                            );
                          })}
                        </tbody>
                      </table>
                    </div>
                  ))}
              </Card>
            );
          })}
        </div>
      )}

      <Modal open={!!structureModal} onClose={() => setStructureModal(null)}
        title={`${structureModal?.mode === "create" ? "Añadir" : "Editar"} ${structureModal?.kind?.toLowerCase() || "nodo"}`}>
        {structureModal && <div className="space-y-3">
          <div className="grid grid-cols-[120px_1fr] gap-3">
            <Field label="Código *"><Input value={structureForm.code} onChange={(e) => setStructureForm({ ...structureForm, code: e.target.value })} className="font-mono" /></Field>
            <Field label="Nombre *"><Input value={structureForm.name} onChange={(e) => setStructureForm({ ...structureForm, name: e.target.value })} /></Field>
          </div>
          {structureModal.kind === "ACTIVIDAD" && <div className="grid grid-cols-3 gap-3">
            <Field label="Unidad"><Input value={structureForm.unit} onChange={(e) => setStructureForm({ ...structureForm, unit: e.target.value.toUpperCase() })} className="font-mono" /></Field>
            {structureModal.mode === "create" && <Field label="Cantidad"><Input value={structureForm.quantity} onChange={(e) => setStructureForm({ ...structureForm, quantity: e.target.value })} inputMode="decimal" className="font-mono" /></Field>}
            {structureModal.mode === "create" && <Field label="Precio de referencia"><Input value={structureForm.referenceUnitPrice} onChange={(e) => setStructureForm({ ...structureForm, referenceUnitPrice: e.target.value })} inputMode="decimal" className="font-mono" /></Field>}
          </div>}
          <Alert tone="info">La creación, modificación o eliminación queda registrada en la auditoría del presupuesto.</Alert>
          <div className="flex justify-end gap-2"><Btn onClick={() => setStructureModal(null)}>Cancelar</Btn><Btn variant="primary" loading={busy} onClick={saveStructure}>Guardar</Btn></div>
        </div>}
      </Modal>

      {/* MODAL: ELEGIR APU MAESTRO */}
      <ApuPickerModal
        open={!!pickingApuFor}
        onClose={() => setPickingApuFor(null)}
        onPick={handlePickMasterApu}
        targetUnit={pickingApuFor?.unit}
        activityName={pickingApuFor?.activityName}
        activityCode={pickingApuFor?.activityCode}
        projectId={projectId}
        projectRegion={projectRegion}
        onCreateNew={() => {
          const target = pickingApuFor;
          setPickingApuFor(null);
          if (target) setEditingApuFor(target);
        }}
      />

      {/* MODAL: EDITAR APU PERSONALIZADO */}
      <ApuEditorModal
        open={!!editingApuFor}
        onClose={() => setEditingApuFor(null)}
        initialApu={editingApuFor?.customApu || null}
        onSaved={handleSaveCustomApu}
        activityInfo={
          editingApuFor
            ? {
                code: editingApuFor.activityCode,
                name: editingApuFor.activityName,
                unit: editingApuFor.unit,
                referenceUnitPrice: editingApuFor.referenceUnitPrice,
              }
            : undefined
        }
        projectRegion={projectRegion}
        projectPriceDate={projectPriceDate}
      />

      {/* MODAL: AJUSTAR CANTIDAD EN BUDGET (CON JUSTIFICACIÓN) */}
      <Modal open={!!overrideModalFor} onClose={() => setOverrideModalFor(null)} title="Ajuste de cantidad en Presupuesto">
        {overrideModalFor && (
          <div className="space-y-4">
            <Alert tone="info">
              La cantidad original validada en <strong>BC Quantity</strong> es{" "}
              <strong className="font-mono text-emerald-400">{fmt(overrideModalFor.quantityBcq, 2)} {overrideModalFor.unit}</strong>.
              Si como presupuestador decide ajustarla, la variación quedará documentada con su justificación.
            </Alert>

            <Field label="Nueva cantidad para presupuesto">
              <Input
                value={overrideValue}
                onChange={(e) => setOverrideValue(e.target.value)}
                placeholder={String(overrideModalFor.quantityBcq)}
                className="font-mono text-sm"
                autoFocus
              />
            </Field>

            <Field label="Motivo del ajuste (Justificación profesional) *">
              <Textarea
                value={overrideReason}
                onChange={(e) => setOverrideReason(e.target.value)}
                placeholder="Ej. Se adiciona 5% por traslapes o condición particular de sitio..."
              />
            </Field>

            <div className="flex justify-between items-center pt-2">
              <button
                type="button"
                onClick={() => {
                  setOverrideValue("");
                  setOverrideReason("");
                }}
                className="text-xs text-fog hover:text-amber-300"
              >
                Restablecer a cantidad original .bcq
              </button>
              <div className="flex gap-2">
                <Btn onClick={() => setOverrideModalFor(null)}>Cancelar</Btn>
                <Btn variant="primary" loading={busy} onClick={handleSaveOverride}>
                  Guardar ajuste
                </Btn>
              </div>
            </div>
          </div>
        )}
      </Modal>

      {/* DRAWER: TRAZABILIDAD BC QUANTITY */}
      <Drawer
        open={!!traceabilityFor}
        onClose={() => setTraceabilityFor(null)}
        title={
          <span className="flex items-center gap-2">
            <FileBox size={16} className="text-emerald-400" /> Trazabilidad BC Quantity
          </span>
        }
      >
        {traceabilityFor && (
          <div className="space-y-4">
            <div className="rounded-xl border border-emerald-400/40 bg-emerald-400/10 p-4">
              <p className="font-mono text-xs font-bold text-emerald-400">{traceabilityFor.activityCode}</p>
              <h4 className="mt-0.5 text-sm font-bold text-white">{traceabilityFor.activityName}</h4>
              <p className="mt-2 font-mono text-xl font-extrabold text-white">
                {fmt(traceabilityFor.finalQuantity, 2)} {traceabilityFor.unit}
              </p>
            </div>

            <div className="space-y-2 rounded-xl border border-line bg-ink-800/50 p-4 text-xs">
              <p className="font-bold text-slate-200">Origen y Evidencia BIM:</p>
              <p><span className="text-fog">Fuentes:</span> {traceabilityFor.sourceMeta?.sources?.join(", ") || "IFC"}</p>
              <p><span className="text-fog">Elementos BIM:</span> {traceabilityFor.sourceMeta?.elementCount || 0} elementos</p>
              <p><span className="text-fog">Método de medición:</span> {traceabilityFor.sourceMeta?.method || "SUPERFICIE_GEOMETRICA"}</p>
              <p><span className="text-fog">Regla aplicada:</span> {traceabilityFor.sourceMeta?.rule || "Área de cara neta"}</p>
              <p><span className="text-fog">Validado por:</span> {traceabilityFor.sourceMeta?.validatedBy || "Profesional"}</p>
              {traceabilityFor.sourceMeta?.derivedFrom && (
                <Alert tone="info">
                  Actividad derivada de <strong>{traceabilityFor.sourceMeta.derivedFrom.activityCode}</strong>
                </Alert>
              )}
            </div>

            {traceabilityFor.overrideReason && (
              <Alert tone="warn">
                <p className="font-bold">Ajuste realizado en Budget:</p>
                <p className="mt-1">Cantidad .bcq: {fmt(traceabilityFor.quantityBcq, 2)} → Presupuesto: {fmt(traceabilityFor.finalQuantity, 2)}</p>
                <p className="mt-1 italic">«{traceabilityFor.overrideReason}»</p>
              </Alert>
            )}

            <Btn className="w-full" onClick={() => setTraceabilityFor(null)}>Cerrar</Btn>
          </div>
        )}
      </Drawer>
    </div>
  );
}
