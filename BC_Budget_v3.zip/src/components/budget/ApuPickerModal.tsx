"use client";

import { useEffect, useState, useMemo } from "react";
import { Search, Calculator, Check, Plus, Coins, ArrowRight } from "lucide-react";
import { Chip, Input, Spinner, Btn, Modal, Alert, cx } from "@/components/ui";
import { api, fmt } from "@/lib/client";

export interface MasterApuSummary {
  id: string;
  code: string;
  name: string;
  unit: string;
  category: string;
  description: string | null;
  unitCost: number;
  itemsCount: number;
  familyCode?: string; versionLabel?: string; region?: string; effectiveDate?: string;
  source?: string; priceStatus?: string; suggestionScore?: number; suggestionReasons?: string[];
}

export function ApuPickerModal({
  open,
  onClose,
  onPick,
  targetUnit,
  activityName,
  onCreateNew,
  activityCode,
  projectId,
  projectRegion,
}: {
  open: boolean;
  onClose: () => void;
  onPick: (apu: MasterApuSummary) => void;
  targetUnit?: string;
  activityName?: string;
  activityCode?: string;
  projectId?: string;
  projectRegion?: string;
  onCreateNew?: () => void;
}) {
  const [apus, setApus] = useState<MasterApuSummary[] | null>(null);
  const [q, setQ] = useState("");

  useEffect(() => {
    if (open) {
      const params = new URLSearchParams();
      if (activityName) params.set("activityName", activityName);
      if (activityCode) params.set("activityCode", activityCode);
      if (targetUnit) params.set("unit", targetUnit);
      if (projectRegion) params.set("region", projectRegion);
      api<{ apus: MasterApuSummary[] }>(`/api/budget/apus?${params}`).then((d) => setApus(d.apus));
    }
  }, [open, activityName, activityCode, targetUnit, projectRegion]);

  const filtered = useMemo(() => {
    if (!apus) return [];
    const needle = q.trim().toLowerCase();
    return apus
      .filter((a) => {
        if (!needle) return true;
        return `${a.code} ${a.name} ${a.category} ${a.description || ""}`.toLowerCase().includes(needle);
      })
      .sort((a, b) => {
        // Priorizar si la unidad coincide exactamente
        if (targetUnit) {
          const aMatch = a.unit.toUpperCase() === targetUnit.toUpperCase();
          const bMatch = b.unit.toUpperCase() === targetUnit.toUpperCase();
          if (aMatch && !bMatch) return -1;
          if (!aMatch && bMatch) return 1;
        }
        return a.code.localeCompare(b.code, "es", { numeric: true });
      });
  }, [apus, q, targetUnit]);

  return (
    <Modal open={open} onClose={onClose} title="Asignar Análisis de Precio Unitario (APU)" wide>
      <div className="space-y-4">
        {targetUnit && (
          <div className="flex items-center justify-between rounded-lg border border-emerald-400/30 bg-emerald-400/5 px-3 py-2 text-xs">
            <span className="text-slate-300">
              Unidad de la actividad: <strong className="font-mono text-emerald-400">{targetUnit}</strong>
            </span>
            <span className="text-[11px] text-fog">Se priorizan APUs compatibles con esta unidad</span>
          </div>
        )}

        <div className="flex items-center gap-2">
          <div className="relative flex-1">
            <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-fog" />
            <Input
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder="Buscar APU por código, nombre o capítulo…"
              className="pl-8 text-xs"
              autoFocus
            />
          </div>
          {onCreateNew && (
            <Btn size="sm" icon={Plus} onClick={onCreateNew}>
              Crear nuevo APU
            </Btn>
          )}
        </div>

        {apus === null ? (
          <Spinner label="Cargando catálogo de APUs…" />
        ) : (
          <div className="max-h-80 overflow-y-auto rounded-xl border border-line">
            {filtered.length === 0 ? (
              <div className="p-8 text-center">
                <p className="text-xs text-mist">No se encontraron APUs para «{q}».</p>
                {onCreateNew && (
                  <Btn className="mt-3" size="sm" variant="primary" icon={Plus} onClick={onCreateNew}>
                    Crear este APU en el catálogo
                  </Btn>
                )}
              </div>
            ) : (
              filtered.map((a) => {
                const sameUnit = targetUnit && a.unit.toUpperCase() === targetUnit.toUpperCase();
                return (
                  <button
                    key={a.id}
                    onClick={() => {
                      onPick(a);
                      onClose();
                    }}
                    className="group flex w-full items-center justify-between gap-3 border-b border-line/40 px-3.5 py-2.5 text-left transition-colors last:border-0 hover:bg-ink-750"
                  >
                    <div className="min-w-0">
                      <div className="flex items-center gap-2">
                        <span className="font-mono text-xs font-bold text-emerald-400">{a.code}</span>
                        <span className="truncate text-xs font-bold text-slate-100 group-hover:text-emerald-300">
                          {a.name}
                        </span>
                      </div>
                      <p className="mt-0.5 text-[10.5px] text-fog">
                        {a.category} · {a.itemsCount} insumos componentes
                      </p>
                    </div>

                    <div className="flex shrink-0 items-center gap-2.5">
                      <Chip className={cx("font-mono font-bold", sameUnit ? "border-emerald-400/40 bg-emerald-400/10 text-emerald-300" : "border-line bg-ink-800 text-mist")}>
                        {a.unit}
                      </Chip>
                      <span className="font-mono text-xs font-black text-slate-100">
                        $ {fmt(a.unitCost, 0)}
                      </span>
                      <Check size={14} className="text-emerald-400 opacity-0 transition-opacity group-hover:opacity-100" />
                    </div>
                  </button>
                );
              })
            )}
          </div>
        )}

        <div className="flex items-center justify-between text-[11px] text-fog pt-1">
          <span>{filtered.length} APUs disponibles</span>
          <Btn size="sm" onClick={onClose}>Cancelar</Btn>
        </div>
      </div>
    </Modal>
  );
}
