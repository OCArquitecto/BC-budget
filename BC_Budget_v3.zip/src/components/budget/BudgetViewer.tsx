"use client";

import { useEffect, useState } from "react";
import { Box, Info, Link2, RefreshCw } from "lucide-react";
import { Viewer3D, type ViewerElement } from "@/components/workspace/Viewer3D";
import { Alert, Card, Chip, Spinner, Btn } from "@/components/ui";
import { api, fmt } from "@/lib/client";

export function BudgetViewer({ projectId }: { projectId: string }) {
  const [elements, setElements] = useState<ViewerElement[] | null>(null);
  const [revision, setRevision] = useState<string | null>(null);
  const [packageId, setPackageId] = useState<string | null>(null);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const load = () => {
    setLoading(true);
    setError(null);
    api<{ elements: ViewerElement[]; revision: string | null; packageId: string | null }>(
      `/api/budget/projects/${projectId}/viewer`
    )
      .then((d) => {
        setElements(d.elements);
        setRevision(d.revision);
        setPackageId(d.packageId);
      })
      .catch((e) => setError((e as Error).message))
      .finally(() => setLoading(false));
  };

  useEffect(() => { load(); }, [projectId]);

  if (loading) return <Spinner label="Cargando geometría del paquete .bcq…" />;

  if (error) return (
    <Alert tone="error">
      Error cargando el visor: {error}
    </Alert>
  );

  if (!elements || elements.length === 0) return (
    <div className="space-y-4">
      <Alert tone="warn">
        <span className="flex items-start gap-2">
          <Info size={13} className="mt-0.5 shrink-0" />
          <span>
            Este proyecto no tiene geometría BIM disponible aún.{" "}
            El visor requiere que el archivo <strong>.bcq importado</strong> incluya{" "}
            <code className="rounded bg-ink-700 px-1 text-[10px]">elements.ndjson</code> con{" "}
            la caja orientada de cada elemento (<code className="rounded bg-ink-700 px-1 text-[10px]">cajaOrientada</code>).{" "}
            Esto lo genera BC Quantity automáticamente cuando se activa la opción{" "}
            <strong>"Incluir elementos y trazabilidad"</strong> al exportar.
          </span>
        </span>
      </Alert>
      <Card className="p-6 text-center">
        <Box size={40} className="mx-auto mb-3 text-fog" />
        <p className="text-sm font-semibold text-mist">Sin geometría disponible</p>
        <p className="mt-1 text-[11px] text-fog">
          Reimporta el .bcq de BC Quantity con elementos incluidos para activar el visor 3D.
        </p>
      </Card>
    </div>
  );

  const selected = elements.find((e) => e.id === selectedId) ?? null;

  return (
    <div className="space-y-4">
      {/* Barra de contexto */}
      <div className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-line bg-ink-800/60 px-4 py-2.5">
        <div className="flex items-center gap-2 text-[11px] text-mist">
          <Info size={13} className="text-emerald-400" />
          <span>
            Visor de contexto presupuestal ·{" "}
            <span className="font-semibold text-slate-200">{revision ?? "última revisión"}</span>
            {packageId && (
              <span className="ml-2 font-mono text-[9.5px] text-fog opacity-70">
                pkg: {packageId.slice(0, 8)}…
              </span>
            )}
          </span>
          <span className="text-fog">·</span>
          <span className="text-fog">{elements.length} elementos</span>
        </div>
        <Btn size="sm" icon={RefreshCw} onClick={load}>Recargar</Btn>
      </div>

      {/* Visor 3D completo — mismo motor que BC Quantity */}
      <Viewer3D
        elements={elements}
        height={640}
        selectedId={selectedId}
        onSelect={setSelectedId}
        title={`Contexto BIM · ${revision ?? "última revisión"}`}
      />

      {/* Panel de detalle del elemento seleccionado */}
      {selected && (
        <Card className="p-4">
          <div className="flex flex-wrap items-start justify-between gap-3">
            <div>
              <p className="font-mono text-[11px] font-bold text-emerald-400">{selected.ifcClass}</p>
              <h3 className="text-sm font-bold text-white">{selected.name ?? "Elemento BIM"}</h3>
              <p className="text-[11px] text-mist">
                {selected.typeName ?? "—"} · {selected.material ?? "sin material"} · {selected.level ?? "sin nivel"}
              </p>
            </div>
            <div className="flex flex-wrap gap-1">
              {(selected.activities ?? []).length === 0 ? (
                <Chip className="border-rose-400/30 bg-rose-400/10 text-[10.5px] text-rose-300">
                  Sin partida presupuestal asignada
                </Chip>
              ) : (selected.activities ?? []).map((a) => (
                <Chip key={a.id} className="border-emerald-400/30 bg-emerald-400/10 text-emerald-300">
                  <Link2 size={10} className="mr-0.5 inline" /> {a.code} · {a.name}
                </Chip>
              ))}
            </div>
          </div>

          {selected.dimensions && (
            <div className="mt-3 flex flex-wrap gap-2">
              {Object.entries(selected.dimensions)
                .filter(([, v]) => v !== null && v !== undefined)
                .slice(0, 12)
                .map(([k, v]) => (
                  <Chip key={k} className="border-line bg-ink-800 font-mono text-mist">
                    {k}: {fmt(v as number, 3)}
                  </Chip>
                ))}
            </div>
          )}
        </Card>
      )}
    </div>
  );
}
