"use client";

import { useEffect, useState, useMemo } from "react";
import { Plus, Trash2, Calculator, Coins, Save, ArrowRight, Search, MapPin, CalendarDays } from "lucide-react";
import { Btn, Modal, Input, Select, Field, Alert, Chip, Textarea, cx } from "@/components/ui";
import { api, fmt } from "@/lib/client";
import type { InsumoCategory } from "@/db/schema";
import { InsumoPickerModal } from "./InsumoPickerModal";

export interface ApuComponentItem {
  id?: string;
  insumoId?: string | null;
  category: InsumoCategory;
  description: string;
  unit: string;
  quantity: number;
  wastePercentage: number;
  unitPrice: number;
  subtotal: number;
}

const CATEGORIES: { v: InsumoCategory; l: string }[] = [
  { v: "MATERIAL", l: "Material" },
  { v: "MANO_DE_OBRA", l: "Mano de Obra" },
  { v: "EQUIPO", l: "Equipo / Herramienta" },
  { v: "TRANSPORTE", l: "Transporte" },
  { v: "SUBCONTRATO", l: "Subcontrato" },
];

export function ApuEditorModal({
  open,
  onClose,
  initialApu,
  onSaved,
  activityInfo,
  projectRegion,
  projectPriceDate,
}: {
  open: boolean;
  onClose: () => void;
  initialApu?: {
    id?: string;
    code: string;
    name: string;
    unit: string;
    category?: string;
    description?: string;
    familyCode?: string; activityCode?: string; versionLabel?: string; region?: string;
    effectiveDate?: string | Date; source?: string; priceStatus?: string;
    components?: ApuComponentItem[];
  } | null;
  onSaved: (apuData: any) => void;
  activityInfo?: { code: string; name: string; unit: string; referenceUnitPrice?: number };
  projectRegion?: string;
  projectPriceDate?: string;
}) {
  const [code, setCode] = useState("");
  const [name, setName] = useState("");
  const [unit, setUnit] = useState("M2");
  const [category, setCategory] = useState("01 MAMPOSTERÍA");
  const [description, setDescription] = useState("");
  const [components, setComponents] = useState<ApuComponentItem[]>([]);
  const [insumoCatalog, setInsumoCatalog] = useState<any[]>([]);
  const [pickingFor, setPickingFor] = useState<number | null>(null);
  const [region, setRegion] = useState(projectRegion || "COLOMBIA");
  const [effectiveDate, setEffectiveDate] = useState(projectPriceDate?.slice(0, 10) || new Date().toISOString().slice(0, 10));
  const [versionLabel, setVersionLabel] = useState("V1");
  const [source, setSource] = useState("BANCO_EMPRESA");
  const [saveToMaster, setSaveToMaster] = useState(true);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (open) {
      api<{ insumos: any[] }>("/api/budget/insumos").then((d) => setInsumoCatalog(d.insumos));

      if (initialApu) {
        setCode(initialApu.code);
        setName(initialApu.name);
        setUnit(initialApu.unit);
        setCategory(initialApu.category || "GENERAL");
        setDescription(initialApu.description || "");
        setComponents(initialApu.components || []);
        setRegion(initialApu.region || projectRegion || "COLOMBIA");
        setEffectiveDate(initialApu.effectiveDate ? new Date(initialApu.effectiveDate).toISOString().slice(0, 10) : (projectPriceDate?.slice(0, 10) || new Date().toISOString().slice(0, 10)));
        setVersionLabel(initialApu.versionLabel || "V1");
        setSource(initialApu.source || "BANCO_EMPRESA");
      } else if (activityInfo) {
        setCode(`APU-${activityInfo.code}`);
        setName(activityInfo.name);
        setUnit(activityInfo.unit);
        setDescription(`APU para ${activityInfo.code} ${activityInfo.name}. Precio de referencia Quantity: $ ${fmt(activityInfo.referenceUnitPrice || 0, 0)}/${activityInfo.unit}.`);
        setRegion(projectRegion || "COLOMBIA");
        setEffectiveDate(projectPriceDate?.slice(0, 10) || new Date().toISOString().slice(0, 10));
        setComponents([
          { category: "MATERIAL", description: "Insumo principal", unit: "UND", quantity: 1, wastePercentage: 5, unitPrice: 0, subtotal: 0 },
          { category: "MANO_DE_OBRA", description: "Cuadrilla de obra", unit: "JOR", quantity: 0.05, wastePercentage: 0, unitPrice: 195000, subtotal: 9750 },
        ]);
      } else {
        setCode(`APU-${Date.now().toString().slice(-4)}`);
        setName("");
        setUnit("M2");
        setComponents([]);
      }
    }
  }, [open, initialApu, activityInfo, projectRegion, projectPriceDate]);

  const addComponent = () => {
    setComponents((c) => [
      ...c,
      {
        category: "MATERIAL",
        description: "",
        unit: "UND",
        quantity: 1,
        wastePercentage: 0,
        unitPrice: 0,
        subtotal: 0,
      },
    ]);
  };

  const updateComponent = (index: number, patch: Partial<ApuComponentItem>) => {
    setComponents((c) => {
      const next = [...c];
      const cur = { ...next[index], ...patch };
      const qty = Number(cur.quantity) || 0;
      const waste = Number(cur.wastePercentage) || 0;
      const price = Number(cur.unitPrice) || 0;
      cur.subtotal = Math.round(qty * (1 + waste / 100) * price * 100) / 100;
      next[index] = cur;
      return next;
    });
  };

  const removeComponent = (index: number) => {
    setComponents((c) => c.filter((_, i) => i !== index));
  };

  const onSelectInsumo = (index: number, insumoId: string) => {
    const ins = insumoCatalog.find((i) => i.id === insumoId);
    if (!ins) return;
    updateComponent(index, {
      insumoId: ins.id,
      description: ins.name,
      unit: ins.unit,
      category: ins.category,
      unitPrice: ins.unitPrice,
    });
  };

  const unitCostTotal = useMemo(() => {
    return Math.round(components.reduce((acc, it) => acc + (it.subtotal || 0), 0) * 100) / 100;
  }, [components]);

  const byCategory = useMemo(() => {
    const map: Record<string, number> = {};
    for (const it of components) {
      map[it.category] = Math.round(((map[it.category] || 0) + (it.subtotal || 0)) * 100) / 100;
    }
    return map;
  }, [components]);

  const save = async () => {
    if (!code.trim() || !name.trim()) {
      setError("Código y nombre del APU son obligatorios.");
      return;
    }
    setBusy(true);
    setError(null);
    try {
      const payload = {
        code: code.trim().toUpperCase(),
        name: name.trim(),
        unit: unit.trim().toUpperCase(),
        category,
        description,
        familyCode: initialApu?.familyCode || `APU-${activityInfo?.code || code}`,
        activityCode: activityInfo?.code || initialApu?.activityCode || null,
        versionLabel,
        region,
        effectiveDate,
        source,
        priceStatus: "VIGENTE",
        saveToMaster,
        unitCost: unitCostTotal,
        items: components,
        components,
      };

      onSaved(payload);
      onClose();
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setBusy(false);
    }
  };

  return (
    <Modal open={open} onClose={onClose} title="Editor de Análisis de Precio Unitario (APU)" wide>
      <div className="space-y-4">
        {error && <Alert tone="error">{error}</Alert>}

        {/* ENCABEZADO DEL APU */}
        <div className="grid gap-3 rounded-xl border border-line bg-ink-800/60 p-4 sm:grid-cols-4">
          <Field label="Código APU *">
            <Input value={code} onChange={(e) => setCode(e.target.value)} className="font-mono uppercase font-bold" />
          </Field>
          <div className="sm:col-span-2">
            <Field label="Nombre del APU *">
              <Input value={name} onChange={(e) => setName(e.target.value)} placeholder="Ej. Muro en bloque 12cm..." />
            </Field>
          </div>
          <Field label="Unidad *">
            <Input value={unit} onChange={(e) => setUnit(e.target.value)} className="font-mono uppercase" />
          </Field>
        </div>

        {activityInfo?.referenceUnitPrice !== undefined && activityInfo.referenceUnitPrice > 0 && (
          <Alert tone="info">
            Quantity entregó <strong className="font-mono">$ {fmt(activityInfo.referenceUnitPrice, 0)} / {activityInfo.unit}</strong> como precio unitario de referencia.
            El APU actual calcula <strong className="font-mono">$ {fmt(unitCostTotal, 0)} / {unit}</strong>. Guarde la validación para alimentar la base confiable de la empresa.
          </Alert>
        )}

        <div className="grid gap-3 rounded-xl border border-line bg-ink-800/40 p-3 sm:grid-cols-4">
          <Field label="Región / zona"><Input value={region} onChange={(e) => setRegion(e.target.value)} placeholder="ANTIOQUIA" /></Field>
          <Field label="Fecha de precios"><Input type="date" value={effectiveDate} onChange={(e) => setEffectiveDate(e.target.value)} /></Field>
          <Field label="Versión"><Input value={versionLabel} onChange={(e) => setVersionLabel(e.target.value)} className="font-mono" placeholder="V1" /></Field>
          <Field label="Fuente"><Input value={source} onChange={(e) => setSource(e.target.value)} placeholder="Cotizaciones / Banco empresa" /></Field>
        </div>

        {/* RESUMEN DE COSTO DIRECTO UNITARIO */}
        <div className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-emerald-400/40 bg-emerald-400/10 p-4">
          <div>
            <p className="text-[10px] font-bold uppercase tracking-wider text-emerald-300">Costo Directo Unitario (CDU)</p>
            <p className="font-mono text-2xl font-black text-white">$ {fmt(unitCostTotal, 2)} <span className="text-xs font-normal text-emerald-300">/ {unit}</span></p>
          </div>
          <div className="flex flex-wrap gap-2">
            {CATEGORIES.map((cat) => {
              const val = byCategory[cat.v] || 0;
              if (val <= 0) return null;
              return (
                <Chip key={cat.v} className="border-line bg-ink-900/90 font-mono text-[11px] text-slate-200">
                  <span className="text-fog">{cat.l.slice(0, 3)}:</span> $ {fmt(val, 0)}
                </Chip>
              );
            })}
          </div>
        </div>

        {/* TABLA DE COMPONENTES */}
        <div>
          <div className="mb-2 flex items-center justify-between">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-200">
              Desglose de Recursos / Insumos ({components.length})
            </h4>
            <Btn size="sm" icon={Plus} onClick={addComponent}>
              Añadir insumo
            </Btn>
          </div>

          <div className="max-h-72 overflow-y-auto rounded-xl border border-line">
            <table className="w-full text-left text-xs">
              <thead className="sticky top-0 bg-ink-800 text-[10px] uppercase text-fog">
                <tr>
                  <th className="w-28 px-3 py-2">Categoría</th>
                  <th className="px-3 py-2">Insumo / Descripción</th>
                  <th className="w-16 px-2 py-2 text-center">Unidad</th>
                  <th className="w-20 px-2 py-2 text-right">Rendimiento</th>
                  <th className="w-16 px-2 py-2 text-right">Desp %</th>
                  <th className="w-24 px-2 py-2 text-right">Precio Unit.</th>
                  <th className="w-24 px-2 py-2 text-right">Subtotal</th>
                  <th className="w-8 px-2 py-2" />
                </tr>
              </thead>
              <tbody>
                {components.map((c, i) => (
                  <tr key={i} className="border-t border-line/40">
                    <td className="px-2 py-1.5">
                      <Select
                        value={c.category}
                        onChange={(e) => updateComponent(i, { category: e.target.value as InsumoCategory })}
                        className="h-7 py-0 text-[11px]"
                      >
                        {CATEGORIES.map((cat) => (
                          <option key={cat.v} value={cat.v}>{cat.l}</option>
                        ))}
                      </Select>
                    </td>
                    <td className="px-2 py-1.5">
                      <div className="space-y-1">
                        <Input
                          value={c.description}
                          onChange={(e) => updateComponent(i, { description: e.target.value })}
                          placeholder="Descripción del insumo..."
                          className="h-7 py-0 text-[11px]"
                        />
                        <button type="button" onClick={() => setPickingFor(i)}
                          className="flex w-full items-center justify-between rounded-md border border-line bg-ink-850 px-2 py-1 text-left text-[10px] text-mist hover:border-emerald-400/50 hover:text-emerald-300">
                          <span className="flex min-w-0 items-center gap-1.5"><Search size={10} /><span className="truncate">{c.insumoId ? "Cambiar insumo del catálogo" : "Buscar en el catálogo de insumos"}</span></span>
                          <span className="shrink-0 font-mono">{c.insumoId ? `$ ${fmt(c.unitPrice, 0)}/${c.unit}` : ""}</span>
                        </button>
                      </div>
                    </td>
                    <td className="px-1 py-1.5">
                      <Input
                        value={c.unit}
                        onChange={(e) => updateComponent(i, { unit: e.target.value.toUpperCase() })}
                        className="h-7 py-0 text-center font-mono text-[11px]"
                      />
                    </td>
                    <td className="px-1 py-1.5">
                      <Input
                        type="number"
                        step="0.0001"
                        value={c.quantity}
                        onChange={(e) => updateComponent(i, { quantity: Number(e.target.value) })}
                        className="h-7 py-0 text-right font-mono text-[11px]"
                      />
                    </td>
                    <td className="px-1 py-1.5">
                      <Input
                        type="number"
                        value={c.wastePercentage}
                        onChange={(e) => updateComponent(i, { wastePercentage: Number(e.target.value) })}
                        className="h-7 py-0 text-right font-mono text-[11px]"
                      />
                    </td>
                    <td className="px-1 py-1.5">
                      <Input
                        type="number"
                        value={c.unitPrice}
                        onChange={(e) => updateComponent(i, { unitPrice: Number(e.target.value) })}
                        className="h-7 py-0 text-right font-mono text-[11px]"
                      />
                    </td>
                    <td className="px-2 py-1.5 text-right font-mono font-bold text-white">
                      $ {fmt(c.subtotal, 0)}
                    </td>
                    <td className="px-1 py-1.5 text-center">
                      <button
                        onClick={() => removeComponent(i)}
                        className="rounded p-1 text-fog hover:bg-rose-500/15 hover:text-rose-400"
                        title="Eliminar insumo"
                      >
                        <Trash2 size={13} />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        <div className="flex flex-wrap items-center justify-between gap-3 border-t border-line pt-3">
          <label className="flex cursor-pointer items-center gap-2 text-[11px] text-mist">
            <input type="checkbox" checked={saveToMaster} onChange={(e) => setSaveToMaster(e.target.checked)} className="accent-emerald-400" />
            Guardar esta versión en el banco consolidado de APUs de la empresa
          </label>
          <Btn onClick={onClose}>Cancelar</Btn>
          <Btn variant="primary" icon={Save} loading={busy} onClick={save}>
            Guardar APU
          </Btn>
        </div>
      </div>
      <InsumoPickerModal
        open={pickingFor !== null}
        onClose={() => setPickingFor(null)}
        insumos={insumoCatalog}
        initialCategory={pickingFor !== null ? components[pickingFor]?.category : undefined}
        onPick={(ins) => {
          if (pickingFor === null) return;
          updateComponent(pickingFor, {
            insumoId: ins.id, description: ins.name, unit: ins.unit,
            category: ins.category, unitPrice: ins.unitPrice,
          });
        }}
      />
    </Modal>
  );
}
