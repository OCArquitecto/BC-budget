/* ================================================================== */
/*  Inferencia para el catálogo maestro                                */
/*  Al importar un listado de precios se deduce: unidad normalizada,   */
/*  método de medición, palabras clave y clases IFC compatibles.       */
/*  Todo es EDITABLE después: son sugerencias, no decisiones.          */
/* ================================================================== */

import type { MeasurementMethod } from "@/db/schema";

export function normalizeUnit(raw: string): string {
  const u = (raw ?? "").toString().trim().toLowerCase()
    .normalize("NFD").replace(/[\u0300-\u036f]/g, "");
  if (!u) return "UND";
  if (/^(m2|m²|mt2|metro cuadrado|metros cuadrados)$/.test(u)) return "M2";
  if (/^(m3|m³|mt3|metro cubico|metros cubicos)$/.test(u)) return "M3";
  if (/^(m|ml|mt|metro|metros|metro lineal)$/.test(u)) return "M";
  if (/^(und|un|unidad|unidades|u|c\/u|cu|pza|pieza)$/.test(u)) return "UND";
  if (/^(kg|kilo|kilos|kilogramo|kilogramos)$/.test(u)) return "KG";
  if (/^(ton|tonelada|toneladas)$/.test(u)) return "TON";
  if (/^(gl|glb|global|gbl)$/.test(u)) return "GLB";
  if (/^(dia|dias|jornal|jornales)$/.test(u)) return "DIA";
  if (/^(hr|hora|horas|h)$/.test(u)) return "HORA";
  if (/^(mes|meses)$/.test(u)) return "MES";
  if (/^(lt|litro|litros|l)$/.test(u)) return "LT";
  if (/^(pulg|pulgada|pulgadas|in)$/.test(u)) return "PULG";
  return raw.toString().trim().toUpperCase().slice(0, 8);
}

/** Método de medición coherente con la unidad. */
export function methodForUnit(unit: string): MeasurementMethod {
  switch (unit) {
    case "M2": return "SUPERFICIE_GEOMETRICA";
    case "M3": return "VOLUMEN_GEOMETRICO";
    case "M": return "DIMENSION";
    case "UND": return "COUNT";
    default: return "MANUAL";
  }
}

const STOP = new Set([
  "de", "del", "la", "el", "los", "las", "en", "con", "para", "por", "y", "o", "a",
  "un", "una", "al", "se", "su", "tipo", "segun", "incluye", "obra", "mano", "ml",
  "und", "unidad", "suministro", "instalacion", "instalado", "suministrado",
]);

export function keywordsFromName(name: string): string[] {
  const clean = (name ?? "")
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/["“”]/g, " ")
    .split(/[^a-z0-9]+/)
    .filter((t) => t.length >= 3 && !STOP.has(t) && !/^\d+$/.test(t));
  const out: string[] = [];
  for (const t of clean) if (!out.includes(t)) out.push(t);
  return out.slice(0, 12);
}

/* ------------------------------------------------------------------ */
/* Clases IFC según el vocabulario de construcción                     */
/* ------------------------------------------------------------------ */
interface Rule { test: RegExp; classes: string[]; boost?: string[] }

const RULES: Rule[] = [
  { test: /\b(muro|muros|mamposteria|mamposter|tabique|fachada|bloque|ladrillo|panel divisorio|murete)\b/, classes: ["IFCWALL", "IFCWALLSTANDARDCASE"] },
  { test: /\b(pintura|vinilo|esmalte|estuco|graniplast|revoque|repello|pañete|panete|friso)\b/, classes: ["IFCWALL", "IFCWALLSTANDARDCASE", "IFCSLAB", "IFCCOVERING"] },
  { test: /\b(enchape|revestimiento|ceramica|porcelanato|baldosin|azulejo|guarda ?escoba|zocalo)\b/, classes: ["IFCWALL", "IFCSLAB", "IFCCOVERING"] },
  { test: /\b(losa|placa|entrepiso|forjado|aligerada|maciza|contrapiso|placa de piso)\b/, classes: ["IFCSLAB", "IFCSLABSTANDARDCASE"] },
  { test: /\b(piso|pisos|acabado de piso|alfombra|laminado|madera de piso|tableta)\b/, classes: ["IFCSLAB", "IFCCOVERING", "IFCSPACE"] },
  { test: /\b(cielo|cielorraso|cielo raso|drywall techo|falso techo|plafon)\b/, classes: ["IFCCOVERING", "IFCSLAB"] },
  { test: /\b(viga|vigas|dintel|dinteles|viga aerea|vigueta)\b/, classes: ["IFCBEAM", "IFCBEAMSTANDARDCASE"] },
  { test: /\b(columna|columnas|pilar|pilares|pedestal)\b/, classes: ["IFCCOLUMN", "IFCCOLUMNSTANDARDCASE"] },
  { test: /\b(zapata|zapatas|cimentacion|cimiento|cimientos|dado|pilote|pilotes|viga de amarre)\b/, classes: ["IFCFOOTING", "IFCPILE"] },
  { test: /\b(puerta|puertas|marco de puerta|hoja de puerta)\b/, classes: ["IFCDOOR", "IFCDOORSTANDARDCASE"] },
  { test: /\b(ventana|ventanas|ventaneria|vitral|vidrio fijo)\b/, classes: ["IFCWINDOW", "IFCWINDOWSTANDARDCASE"] },
  { test: /\b(cubierta|teja|tejas|techo|impermeabiliza|manto)\b/, classes: ["IFCROOF", "IFCSLAB"] },
  { test: /\b(escalera|escaleras|peldano|rampa)\b/, classes: ["IFCSTAIR", "IFCSTAIRFLIGHT", "IFCRAMP"] },
  { test: /\b(baranda|barandas|pasamanos|antepecho metalico)\b/, classes: ["IFCRAILING"] },
  { test: /\b(tuberia|tuberias|tubo|pvc|cpvc|sanitaria|desague|desagues|aguas negras|aguas lluvias|presion|acueducto)\b/, classes: ["IFCPIPESEGMENT", "IFCFLOWSEGMENT"] },
  { test: /\b(accesorio|codo|tee|yee|union|sifon|reduccion|registro|valvula)\b/, classes: ["IFCPIPEFITTING", "IFCVALVE", "IFCFLOWFITTING"] },
  { test: /\b(aparato sanitario|inodoro|sanitario|lavamanos|lavaplatos|ducha|orinal|lavadero|griferia)\b/, classes: ["IFCSANITARYTERMINAL", "IFCFLOWTERMINAL"] },
  { test: /\b(cable|cableado|conductor|thhn|thw|acometida|canalizacion|conduit|emt|bandeja)\b/, classes: ["IFCCABLESEGMENT", "IFCCABLECARRIERSEGMENT"] },
  { test: /\b(toma|tomacorriente|salida electrica|interruptor|apagador|conmutador)\b/, classes: ["IFCOUTLET", "IFCSWITCHINGDEVICE"] },
  { test: /\b(luminaria|lampara|bombillo|iluminacion|reflector|led)\b/, classes: ["IFCLAMP", "IFCLIGHTFIXTURE"] },
  { test: /\b(tablero|breaker|totalizador|medidor electrico)\b/, classes: ["IFCELECTRICDISTRIBUTIONBOARD", "IFCJUNCTIONBOX"] },
  { test: /\b(ducto|ductos|rejilla|difusor|aire acondicionado|ventilacion)\b/, classes: ["IFCDUCTSEGMENT", "IFCDUCTFITTING"] },
  { test: /\b(acero|refuerzo|varilla|malla electrosoldada|figurado|fleje)\b/, classes: ["IFCREINFORCINGBAR", "IFCREINFORCINGMESH"] },
  { test: /\b(mueble|mobiliario|closet|cocina integral|mesón|meson)\b/, classes: ["IFCFURNISHINGELEMENT", "IFCFURNITURE"] },
];

/** Devuelve las clases IFC compatibles con el nombre de la actividad. */
export function ifcClassesFromName(name: string, unit?: string): string[] {
  const n = (name ?? "").toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "");
  const out = new Set<string>();
  for (const r of RULES) if (r.test.test(n)) for (const c of r.classes) out.add(c);

  // Refinamiento por unidad: una actividad en M no puede ser una losa
  if (unit === "M") {
    for (const c of [...out]) if (/SLAB|ROOF|COVERING/.test(c)) out.delete(c);
  }
  if (unit === "UND") {
    for (const c of [...out]) if (/SEGMENT$/.test(c)) out.delete(c);
  }
  return [...out];
}

export interface PriceRow {
  code: string;
  name: string;
  unit: string;
  price: number;
  chapterCode?: string;
  chapterName?: string;
  sectionCode?: string;
  sectionName?: string;
}

/** Deriva capítulo y sección a partir del código jerárquico (17.01.003). */
export function splitCode(code: string): { chapter: string; section: string } {
  const parts = String(code).trim().split(/[.\-_/]/).filter(Boolean);
  if (parts.length >= 3) return { chapter: parts[0], section: `${parts[0]}.${parts[1]}` };
  if (parts.length === 2) return { chapter: parts[0], section: `${parts[0]}.${parts[1]}` };
  return { chapter: parts[0] ?? "00", section: `${parts[0] ?? "00"}.01` };
}

export function parsePrice(raw: unknown): number {
  if (typeof raw === "number") return isFinite(raw) ? raw : 0;
  const s = String(raw ?? "").replace(/[^\d,.-]/g, "").trim();
  if (!s) return 0;

  // Separador de miles puro: 185.000 · 1.234.567 · 1,234,567  →  185000 / 1234567
  if (/^-?\d{1,3}(\.\d{3})+$/.test(s)) return Number(s.replace(/\./g, ""));
  if (/^-?\d{1,3}(,\d{3})+$/.test(s)) return Number(s.replace(/,/g, ""));

  // Mixtos: 1.234.567,89 (es) · 1,234,567.89 (en)
  const lastComma = s.lastIndexOf(",");
  const lastDot = s.lastIndexOf(".");
  let normalized = s;
  if (lastComma > lastDot) normalized = s.replace(/\./g, "").replace(",", ".");
  else if (lastDot > lastComma) normalized = s.replace(/,/g, "");
  else normalized = s.replace(/[.,]/g, "");
  const n = Number(normalized);
  return isFinite(n) ? n : 0;
}
