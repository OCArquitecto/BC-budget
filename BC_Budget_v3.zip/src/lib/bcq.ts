/* ================================================================== */
/*  BIMCost Quantity Package (.bcq) v1.0 — Parser & Generator          */
/*  Contrato nativo del ecosistema BIMCost                             */
/*                                                                      */
/*  NOTA IMPORTANTE:                                                    */
/*  BIMCost Quantity exporta el manifest con nombres de campo en        */
/*  español (formato, paqueteId, proyecto, exportadoEnUtc, etc.).       */
/*  BC Budget usa internamente nombres en inglés (format, packageId,   */
/*  exportedAt, etc.). Esta librería actúa como ADAPTADOR:             */
/*    parseBcqPackage  → lee el formato real (español) y lo normaliza   */
/*    createBcqPackage → genera paquetes en el formato real (español)   */
/*  El importer.ts y sample-bcq.ts nunca se tocan; solo trabajan con   */
/*  los tipos internos de este archivo.                                 */
/* ================================================================== */

import JSZip from "jszip";
import { createHash } from "node:crypto";

/* ------------------------------------------------------------------ */
/* Tipos INTERNOS de BC Budget (inglés) — no cambiar: importer.ts      */
/* los usa directamente.                                                */
/* ------------------------------------------------------------------ */
export interface BcqManifest {
  format: "BCQ";
  version: "1.0";
  packageId: string;
  projectId: string;
  projectCode: string;
  projectName: string;
  revision: string;
  exportedAt: string;
  producer: {
    name: string;
    version: string;
    build: string;
  };
  exportMode: "VALIDATED_ONLY" | "FULL_AUDIT";
  stats: {
    sources: number;
    activities: number;
    quantities: number;
    elements: number;
    decisions: number;
  };
  checksums: Record<string, string>;
}

export interface BcqProject {
  id: string;
  code: string;
  name: string;
  client?: string | null;
  location?: string | null;
  description?: string | null;
  units: string;
  company?: {
    name?: string;
    nit?: string;
    address?: string;
    phone?: string;
    email?: string;
    responsible?: string;
    role?: string;
    license?: string;
    logo?: string;
  } | null;
  settings?: {
    administracion?: number;
    imprevistos?: number;
    utilidad?: number;
    iva?: number;
    ivaBases?: string[];
    currency?: string;
    notes?: string;
  } | null;
}

export interface BcqSource {
  id: string;
  kind: "IFC" | "EXCEL" | "MANUAL" | "TEMPLATE";
  name: string;
  discipline?: string | null;
  fileName?: string | null;
  ifcSchema?: string | null;
  contentHash?: string | null;
  modelHash?: string | null;
  unit?: string | null;
  factorScale?: number | null;
  elementCount?: number;
  warnings?: string[];
}

export interface BcqActivity {
  id: string;
  code: string;
  chapterCode: string;
  chapterName: string;
  sectionCode: string;
  sectionName: string;
  name: string;
  unit: string;
  method: string;
  ifcClasses?: string[];
  keywords?: string[];
  referencePrice?: number;
}

export interface BcqStructureNode {
  id: string;
  parentId?: string | null;
  kind: "CAPITULO" | "SECCION" | "ACTIVIDAD";
  code: string;
  name: string;
  activityId?: string | null;
  unit?: string | null;
  sortOrder?: number;
  activities?: BcqStructureNode[];
  sections?: BcqStructureNode[];
}

export interface BcqQuantity {
  id: string;
  activityId: string;
  activityCode: string;
  activityName: string;
  value: number | null;
  unit: string;
  status: "VALIDADA" | "PROPUESTA" | "PENDIENTE" | "RECHAZADA";
  method: string;
  rule?: string | null;
  measureConfig?: Record<string, unknown> | null;
  sourceKind: string;
  sourceName?: string | null;
  elementCount: number;
  elementGlobalIds: string[];
  derivedFromId?: string | null;
  derivedParentCode?: string | null;
  label?: string | null;
  validatedBy?: string | null;
  validatedAt?: string | null;
  note?: string | null;
  warnings?: string[];
}

export interface BcqElement {
  id: string;
  globalId: string | null;
  sourceId: string;
  ifcClass: string;
  name: string | null;
  typeName: string | null;
  semanticType?: string | null;
  material: string | null;
  level: string | null;
  dimensions?: Record<string, number | null> | null;
  dimensionSources?: Record<string, string> | null;
  geometry?: {
    kind?: string;
    size?: [number, number, number];
    center?: [number, number, number];
    yaw?: number;
    oriented?: {
      size: [number, number, number];
      center?: [number, number, number];
      axes?: [[number, number, number], [number, number, number], [number, number, number]];
    };
  } | null;
}

export interface BcqDecision {
  id: string;
  entityType: string;
  entityId?: string | null;
  action: string;
  detail?: Record<string, unknown> | null;
  actor?: string | null;
  createdAt: string;
}

export interface BcqPackage {
  manifest: BcqManifest;
  project: BcqProject;
  sources: BcqSource[];
  catalog: BcqActivity[];
  structure: BcqStructureNode[];
  quantities: BcqQuantity[];
  elements: BcqElement[];
  decisions: BcqDecision[];
  validatedQuantities: BcqQuantity[];
}

/* ------------------------------------------------------------------ */
/* Utilidades internas                                                  */
/* ------------------------------------------------------------------ */
function sha256(data: string | Buffer): string {
  return createHash("sha256").update(data).digest("hex");
}

function parseNdjson<T>(text: string): T[] {
  if (!text || !text.trim()) return [];
  const out: T[] = [];
  for (const line of text.split(/\r?\n/)) {
    const t = line.trim();
    if (t) {
      try { out.push(JSON.parse(t) as T); }
      catch (e) { console.warn("Error parsing NDJSON line:", t, e); }
    }
  }
  return out;
}

function toNdjson(items: unknown[]): string {
  return items.map((i) => JSON.stringify(i)).join("\n") + "\n";
}

/* ------------------------------------------------------------------ */
/* Tipos crudos del .bcq real (campos en español)                       */
/* Sólo se usan dentro de este archivo para la traducción.             */
/* ------------------------------------------------------------------ */
interface RawManifest {
  // Formato real exportado por BIMCost Quantity
  formato?: string;
  version?: string;
  paqueteId?: string;
  proyecto?: { id?: string; revision?: number };
  proyectoCodigo?: string;
  proyectoNombre?: string;
  exportadoEnUtc?: string;
  aplicacionProductora?: string;
  productorVersion?: string;
  productorBuild?: string;
  modoExportacion?: string;
  conteos?: { fuentes?: number; actividades?: number; lineasCantidad?: number; elementos?: number; decisiones?: number };
  archivos?: { ruta: string; sha256: string; bytes: number }[];
  // Formato antiguo en inglés (generado por createBcqPackage de esta misma librería)
  format?: string;
  packageId?: string;
  projectId?: string;
  projectCode?: string;
  projectName?: string;
  revision?: string;
  exportedAt?: string;
  producer?: { name?: string; version?: string; build?: string };
  exportMode?: string;
  stats?: { sources?: number; activities?: number; quantities?: number; elements?: number; decisions?: number };
  checksums?: Record<string, string>;
}

interface RawSource {
  // Español (BIMCost Quantity)
  tipo?: string;
  nombre?: string;
  disciplina?: string | null;
  archivoOriginal?: string | null;
  esquemaIfc?: string | null;
  sha256Archivo?: string | null;
  sha256Modelo?: string | null;
  unidadDetectada?: string | null;
  factorEscala?: number | null;
  advertenciasImportacion?: string[];
  // Inglés (BC Budget)
  kind?: string;
  name?: string;
  discipline?: string | null;
  fileName?: string | null;
  ifcSchema?: string | null;
  contentHash?: string | null;
  modelHash?: string | null;
  unit?: string | null;
  factorScale?: number | null;
  warnings?: string[];
  // Comunes
  id: string;
  elementCount?: number | null;
}

interface RawCatalogActivity {
  // Español (BIMCost Quantity)
  idMaestro?: string;
  codigo?: string;
  capituloCodigo?: string;
  capituloNombre?: string;
  subcapituloCodigo?: string;
  subcapituloNombre?: string;
  nombre?: string;
  unidad?: string;
  metodoMedicion?: string;
  clasesIfcCompatibles?: string[];
  palabrasClave?: string[];
  precioReferencial?: { valor?: number; autoritativo?: boolean } | null;
  // Inglés (BC Budget)
  id?: string;
  code?: string;
  chapterCode?: string;
  chapterName?: string;
  sectionCode?: string;
  sectionName?: string;
  name?: string;
  unit?: string;
  method?: string;
  ifcClasses?: string[];
  keywords?: string[];
  referencePrice?: number;
}

interface RawStructureChapter {
  // Español (BIMCost Quantity) — árbol plano: capitulos[].subcapitulos[].actividades[]
  codigo?: string;
  nombre?: string;
  subcapitulos?: RawStructureSection[];
  // Inglés (BC Budget) — árbol: chapters[].sections[].activities[] (o BcqStructureNode[])
  code?: string;
  name?: string;
  sections?: RawStructureSection[];
  activities?: RawStructureActivity[];
  // Forma plana (BcqStructureNode del formato inglés antiguo)
  kind?: string;
  id?: string;
  parentId?: string | null;
  activityId?: string | null;
  unit?: string | null;
  sortOrder?: number;
}
interface RawStructureSection {
  codigo?: string; nombre?: string; actividades?: RawStructureActivity[];
  code?: string; name?: string; activities?: RawStructureActivity[];
  sortOrder?: number;
}
interface RawStructureActivity {
  codigo?: string; nombre?: string; idMaestro?: string | null; unidad?: string | null; metodoMedicion?: string | null; totalConsolidadoValidado?: number; lineasCantidad?: number;
  code?: string; name?: string; activityId?: string | null; id?: string | null; unit?: string | null; method?: string | null;
  sortOrder?: number;
}

interface RawQuantity {
  // Español (BIMCost Quantity)
  actividadId?: string;
  valor?: number | null;
  unidad?: string;
  estado?: string;
  esCantidadEconomica?: boolean;
  metodo?: string;
  regla?: string | null;
  configuracionMedicion?: Record<string, unknown> | null;
  fuente?: { id?: string | null; tipo?: string; nombre?: string | null };
  elementosInternos?: string[];
  elementosGlobalId?: string[];
  cantidadElementos?: number;
  fechaCalculoUtc?: string;
  profesionalValido?: string | null;
  fechaValidacionUtc?: string | null;
  observaciones?: string | null;
  advertencias?: string[];
  cantidadPadreId?: string | null;
  // Inglés (BC Budget)
  activityId?: string;
  activityCode?: string;
  activityName?: string;
  value?: number | null;
  unit?: string;
  status?: string;
  method?: string;
  rule?: string | null;
  measureConfig?: Record<string, unknown> | null;
  sourceKind?: string;
  sourceName?: string | null;
  elementCount?: number;
  elementGlobalIds?: string[];
  derivedFromId?: string | null;
  derivedParentCode?: string | null;
  validatedBy?: string | null;
  validatedAt?: string | null;
  note?: string | null;
  warnings?: string[];
  // Común
  id: string;
}

interface RawElement {
  // Español
  fuenteId?: string;
  claseIfc?: string;
  tipo?: string | null;
  tipoSemantico?: string | null;
  nombre?: string | null;
  material?: string | null;
  nivel?: string | null;
  dimensiones?: Record<string, number | null> | null;
  origenDimensiones?: Record<string, string> | null;
  cajaOrientada?: unknown;
  recortado?: boolean;
  // Inglés
  sourceId?: string;
  ifcClass?: string;
  typeName?: string | null;
  semanticType?: string | null;
  name?: string | null;
  level?: string | null;
  dimensions?: Record<string, number | null> | null;
  dimensionSources?: Record<string, string> | null;
  geometry?: unknown;
  // Comunes
  id: string;
  globalId?: string | null;
}

interface RawDecision {
  // Español
  entidadTipo?: string;
  entidadId?: string | null;
  decision?: string;
  fechaUtc?: string;
  observacion?: string | null;
  detalle?: Record<string, unknown> | null;
  // Inglés
  entityType?: string;
  entityId?: string | null;
  action?: string;
  createdAt?: string;
  detail?: Record<string, unknown> | null;
  // Comunes
  id: string;
  actor?: string | null;
}

/* ------------------------------------------------------------------ */
/* Helpers de traducción campo por campo                                */
/* ------------------------------------------------------------------ */
function adaptManifest(raw: RawManifest): BcqManifest {
  // Detectar si viene en español o en inglés
  const isEspanol = "formato" in raw;

  if (isEspanol) {
    const conteos = raw.conteos ?? {};
    // Construir checksums desde archivos[] si existen
    const checksums: Record<string, string> = {};
    for (const f of raw.archivos ?? []) {
      checksums[f.ruta] = f.sha256;
    }
    return {
      format: "BCQ",
      version: (raw.version ?? "1.0") as "1.0",
      packageId: raw.paqueteId ?? "",
      projectId: raw.proyecto?.id ?? "",
      projectCode: raw.proyectoCodigo ?? "",
      projectName: raw.proyectoNombre ?? "",
      revision: `REV-${String(raw.proyecto?.revision ?? 1).padStart(2, "0")}`,
      exportedAt: raw.exportadoEnUtc ?? new Date().toISOString(),
      producer: {
        name: raw.aplicacionProductora ?? "BIMCost Quantity",
        version: raw.productorVersion ?? "1.0",
        build: raw.productorBuild ?? "",
      },
      exportMode: raw.modoExportacion === "CON_AUDITORIA" ? "FULL_AUDIT" : "VALIDATED_ONLY",
      stats: {
        sources: conteos.fuentes ?? 0,
        activities: conteos.actividades ?? 0,
        quantities: conteos.lineasCantidad ?? 0,
        elements: conteos.elementos ?? 0,
        decisions: conteos.decisiones ?? 0,
      },
      checksums,
    };
  }

  // Ya viene en inglés (generado por createBcqPackage de esta librería)
  return {
    format: "BCQ",
    version: (raw.version ?? "1.0") as "1.0",
    packageId: raw.packageId ?? "",
    projectId: raw.projectId ?? "",
    projectCode: raw.projectCode ?? "",
    projectName: raw.projectName ?? "",
    revision: raw.revision ?? "REV-01",
    exportedAt: raw.exportedAt ?? new Date().toISOString(),
    producer: {
      name: raw.producer?.name ?? "BIMCost Quantity",
      version: raw.producer?.version ?? "1.0",
      build: raw.producer?.build ?? "",
    },
    exportMode: (raw.exportMode as "VALIDATED_ONLY" | "FULL_AUDIT") ?? "VALIDATED_ONLY",
    stats: {
      sources: raw.stats?.sources ?? 0,
      activities: raw.stats?.activities ?? 0,
      quantities: raw.stats?.quantities ?? 0,
      elements: raw.stats?.elements ?? 0,
      decisions: raw.stats?.decisions ?? 0,
    },
    checksums: raw.checksums ?? {},
  };
}

function adaptProject(raw: Record<string, unknown>): BcqProject {
  // BcqProject fields are the same in both dialects; the real differences are in
  // empresa (Quantity stores the full company object under company with English keys).
  return {
    id: (raw.id as string) ?? "",
    code: ((raw.code ?? raw.codigo) as string) ?? "",
    name: ((raw.name ?? raw.nombre) as string) ?? "",
    client: (raw.client ?? raw.cliente ?? null) as string | null,
    location: (raw.location ?? raw.ubicacion ?? null) as string | null,
    description: (raw.description ?? raw.descripcion ?? null) as string | null,
    units: ((raw.units ?? raw.unidades ?? "SI") as string),
    company: (raw.company ?? raw.empresaConstructora ?? null) as BcqProject["company"],
    settings: (raw.settings ?? null) as BcqProject["settings"],
  };
}

function adaptSource(raw: RawSource): BcqSource {
  return {
    id: raw.id,
    kind: ((raw.tipo ?? raw.kind ?? "MANUAL") as BcqSource["kind"]),
    name: (raw.nombre ?? raw.name ?? ""),
    discipline: raw.disciplina ?? raw.discipline ?? null,
    fileName: raw.archivoOriginal ?? raw.fileName ?? null,
    ifcSchema: raw.esquemaIfc ?? raw.ifcSchema ?? null,
    contentHash: raw.sha256Archivo ?? raw.contentHash ?? null,
    modelHash: raw.sha256Modelo ?? raw.modelHash ?? null,
    unit: raw.unidadDetectada ?? raw.unit ?? null,
    factorScale: raw.factorEscala ?? raw.factorScale ?? null,
    elementCount: raw.elementCount ?? undefined,
    warnings: raw.advertenciasImportacion ?? raw.warnings ?? [],
  };
}

function adaptCatalogActivity(raw: RawCatalogActivity, index: number): BcqActivity {
  const refPrice = raw.precioReferencial?.valor ?? raw.referencePrice ?? 0;
  return {
    id: raw.idMaestro ?? raw.id ?? String(index),
    code: raw.codigo ?? raw.code ?? "",
    chapterCode: raw.capituloCodigo ?? raw.chapterCode ?? "",
    chapterName: raw.capituloNombre ?? raw.chapterName ?? "",
    sectionCode: raw.subcapituloCodigo ?? raw.sectionCode ?? "",
    sectionName: raw.subcapituloNombre ?? raw.sectionName ?? "",
    name: raw.nombre ?? raw.name ?? "",
    unit: raw.unidad ?? raw.unit ?? "",
    method: raw.metodoMedicion ?? raw.method ?? "",
    ifcClasses: raw.clasesIfcCompatibles ?? raw.ifcClasses ?? [],
    keywords: raw.palabrasClave ?? raw.keywords ?? [],
    referencePrice: refPrice,
  };
}

/** Construye el árbol BcqStructureNode[] que espera importer.ts, manejando
 *  tanto el árbol plano en español (capitulos[].subcapitulos[].actividades[])
 *  como el árbol en inglés de BcqStructureNode[] que ya usa este formato. */
function adaptStructure(raw: unknown): BcqStructureNode[] {
  if (!raw) return [];

  // Formato español: { capitulos: [...] }
  if (typeof raw === "object" && !Array.isArray(raw) && "capitulos" in (raw as object)) {
    const root = raw as { capitulos: RawStructureChapter[] };
    return (root.capitulos ?? []).map((ch, ci) => ({
      id: `ch-${ch.codigo ?? ci}`,
      kind: "CAPITULO" as const,
      code: ch.codigo ?? ch.code ?? "",
      name: ch.nombre ?? ch.name ?? "",
      sortOrder: ci,
      sections: (ch.subcapitulos ?? ch.sections ?? []).map((sec, si) => ({
        id: `sec-${sec.codigo ?? sec.code ?? si}`,
        kind: "SECCION" as const,
        code: sec.codigo ?? sec.code ?? "",
        name: sec.nombre ?? sec.name ?? "",
        sortOrder: sec.sortOrder ?? si,
        activities: (sec.actividades ?? sec.activities ?? []).map((act, ai) => ({
          id: `act-${act.codigo ?? act.code ?? ai}`,
          kind: "ACTIVIDAD" as const,
          code: act.codigo ?? act.code ?? "",
          name: act.nombre ?? act.name ?? "",
          activityId: act.idMaestro ?? act.activityId ?? act.id ?? null,
          unit: act.unidad ?? act.unit ?? null,
          sortOrder: act.sortOrder ?? ai,
        })),
      })),
    }));
  }

  // Formato inglés: BcqStructureNode[] (ya tiene la forma correcta)
  if (Array.isArray(raw)) {
    return raw as BcqStructureNode[];
  }

  return [];
}

/** Construye un mapa código→{nombre,unidad} a partir del árbol de estructura
 *  para enriquecer las líneas de cantidad del formato español (que no traen
 *  activityCode/activityName directamente). */
function buildActivityCodeMap(nodes: BcqStructureNode[]): Map<string, { code: string; name: string; unit: string }> {
  const map = new Map<string, { code: string; name: string; unit: string }>();
  function walk(ns: BcqStructureNode[]) {
    for (const n of ns) {
      if (n.kind === "ACTIVIDAD") map.set(n.activityId ?? n.id, { code: n.code, name: n.name, unit: n.unit ?? "" });
      if (n.sections) walk(n.sections);
      if (n.activities) walk(n.activities);
    }
  }
  walk(nodes);
  return map;
}

/** Igual que buildActivityCodeMap pero partiendo del árbol raw en español,
 *  antes de que se convierta a BcqStructureNode[], para poder usar idMaestro. */
function buildActivityMapFromRaw(raw: unknown): Map<string, { code: string; name: string; unit: string }> {
  const map = new Map<string, { code: string; name: string; unit: string }>();
  if (!raw || typeof raw !== "object" || !("capitulos" in (raw as object))) return map;
  const root = raw as { capitulos: RawStructureChapter[] };
  for (const ch of root.capitulos ?? []) {
    for (const sec of ch.subcapitulos ?? ch.sections ?? []) {
      for (const act of sec.actividades ?? sec.activities ?? []) {
        const id = act.idMaestro ?? act.activityId ?? act.id ?? act.codigo ?? act.code ?? "";
        const code = act.codigo ?? act.code ?? "";
        const name = act.nombre ?? act.name ?? "";
        const unit = act.unidad ?? act.unit ?? "";
        if (id) map.set(id, { code, name, unit });
      }
    }
  }
  return map;
}

function adaptQuantity(
  raw: RawQuantity,
  activityMap: Map<string, { code: string; name: string; unit: string }>
): BcqQuantity {
  // ¿Viene en español?
  const isEspanol = "actividadId" in raw || "estado" in raw || "valor" in raw;

  if (isEspanol) {
    const actId = raw.actividadId ?? raw.activityId ?? "";
    const actInfo = activityMap.get(actId) ?? { code: actId, name: "", unit: raw.unidad ?? raw.unit ?? "" };
    const estado = raw.estado ?? raw.status ?? "PROPUESTA";
    return {
      id: raw.id,
      activityId: actId,
      activityCode: actInfo.code,
      activityName: actInfo.name,
      value: raw.valor ?? raw.value ?? null,
      unit: raw.unidad ?? raw.unit ?? actInfo.unit ?? "",
      status: estado as BcqQuantity["status"],
      method: raw.metodo ?? raw.method ?? "",
      rule: raw.regla ?? raw.rule ?? null,
      measureConfig: raw.configuracionMedicion ?? raw.measureConfig ?? null,
      sourceKind: raw.fuente?.tipo ?? raw.sourceKind ?? "MANUAL",
      sourceName: raw.fuente?.nombre ?? raw.sourceName ?? null,
      elementCount: raw.cantidadElementos ?? raw.elementCount ?? 0,
      elementGlobalIds: raw.elementosGlobalId ?? raw.elementGlobalIds ?? [],
      derivedFromId: raw.cantidadPadreId ?? raw.derivedFromId ?? null,
      validatedBy: raw.profesionalValido ?? raw.validatedBy ?? null,
      validatedAt: raw.fechaValidacionUtc ?? raw.validatedAt ?? null,
      note: raw.observaciones ?? raw.note ?? null,
      warnings: raw.advertencias ?? raw.warnings ?? [],
    };
  }

  // Ya viene en inglés
  return {
    id: raw.id,
    activityId: raw.activityId ?? "",
    activityCode: raw.activityCode ?? "",
    activityName: raw.activityName ?? "",
    value: raw.value ?? null,
    unit: raw.unit ?? "",
    status: (raw.status as BcqQuantity["status"]) ?? "PROPUESTA",
    method: raw.method ?? "",
    rule: raw.rule ?? null,
    measureConfig: raw.measureConfig ?? null,
    sourceKind: raw.sourceKind ?? "MANUAL",
    sourceName: raw.sourceName ?? null,
    elementCount: raw.elementCount ?? 0,
    elementGlobalIds: raw.elementGlobalIds ?? [],
    derivedFromId: raw.derivedFromId ?? null,
    derivedParentCode: raw.derivedParentCode ?? null,
    validatedBy: raw.validatedBy ?? null,
    validatedAt: raw.validatedAt ?? null,
    note: raw.note ?? null,
    warnings: raw.warnings ?? [],
  };
}

function adaptElement(raw: RawElement): BcqElement {
  // La geometría puede venir en dos formas:
  //   · Español (Quantity): campo raíz "cajaOrientada" con {tamano, centro, ejes}
  //   · Inglés (Budget interno): campo "geometry" con {kind, size, center, yaw, oriented:{size,center,axes}}
  // Normalizamos ambas a la estructura interna inglesa para que el viewer funcione.
  const rawCaja = (raw as Record<string, unknown>).cajaOrientada as
    | { tamano?: [number, number, number]; centro?: [number, number, number]; ejes?: [[number,number,number],[number,number,number],[number,number,number]] }
    | null | undefined;

  let geometry: BcqElement["geometry"] = (raw.geometry ?? null) as BcqElement["geometry"];

  if (!geometry && rawCaja) {
    const size   = rawCaja.tamano  ?? [1, 1, 1];
    const center = rawCaja.centro  ?? [0, 0, 0];
    const axes   = rawCaja.ejes    ?? [[1,0,0],[0,1,0],[0,0,1]];
    geometry = {
      kind: "BCQ",
      size:   size   as [number,number,number],
      center: center as [number,number,number],
      yaw: Math.atan2(axes[0][1], axes[0][0]),
      oriented: {
        size:   size   as [number,number,number],
        center: center as [number,number,number],
        axes:   axes   as [[number,number,number],[number,number,number],[number,number,number]],
      },
    };
  }

  return {
    id: raw.id,
    globalId: raw.globalId ?? null,
    sourceId: raw.fuenteId ?? raw.sourceId ?? "",
    ifcClass: raw.claseIfc ?? raw.ifcClass ?? "",
    name: raw.nombre ?? raw.name ?? null,
    typeName: raw.tipo ?? raw.typeName ?? null,
    semanticType: raw.tipoSemantico ?? raw.semanticType ?? null,
    material: raw.material ?? null,
    level: raw.nivel ?? raw.level ?? null,
    dimensions: raw.dimensiones ?? raw.dimensions ?? null,
    dimensionSources: raw.origenDimensiones ?? raw.dimensionSources ?? null,
    geometry,
  };
}

function adaptDecision(raw: RawDecision): BcqDecision {
  return {
    id: raw.id,
    entityType: raw.entidadTipo ?? raw.entityType ?? "",
    entityId: raw.entidadId ?? raw.entityId ?? null,
    action: raw.decision ?? raw.action ?? "",
    detail: raw.detalle ?? raw.detail ?? null,
    actor: raw.actor ?? null,
    createdAt: raw.fechaUtc ?? raw.createdAt ?? new Date().toISOString(),
  };
}

/* ------------------------------------------------------------------ */
/* parseBcqPackage — punto de entrada principal                         */
/* ------------------------------------------------------------------ */
export async function parseBcqPackage(data: ArrayBuffer | Buffer): Promise<BcqPackage> {
  const zip = await JSZip.loadAsync(data);

  // 1. Validar mimetype
  const mimeFile = zip.file("mimetype");
  if (mimeFile) {
    const mime = (await mimeFile.async("text")).trim();
    if (!mime.includes("bimcost")) {
      console.warn("Mimetype no estándar en .bcq:", mime);
    }
  }

  // 2. Leer manifest y detectar dialecto
  const manifestFile = zip.file("manifest.json");
  if (!manifestFile) throw new Error("El archivo .bcq no contiene 'manifest.json' válido.");
  const rawManifest = JSON.parse(await manifestFile.async("text")) as RawManifest;

  // Validar que es un paquete BCQ (acepta ambos dialectos)
  const formatoDetectado = rawManifest.formato ?? rawManifest.format;
  if (formatoDetectado !== "BCQ") {
    throw new Error(`Formato no reconocido: ${formatoDetectado}. Se esperaba 'BCQ'.`);
  }

  const manifest = adaptManifest(rawManifest);

  // 3. Leer y adaptar cada archivo
  const projectRaw = JSON.parse(
    (await zip.file("project.json")?.async("text")) ?? "{}"
  ) as Record<string, unknown>;
  const project = adaptProject(projectRaw);

  const sourcesRaw = JSON.parse(
    (await zip.file("sources.json")?.async("text")) ?? "[]"
  ) as RawSource[];
  const sources = sourcesRaw.map(adaptSource);

  const catalogRaw = JSON.parse(
    (await zip.file("catalog-snapshot.json")?.async("text")) ?? "[]"
  ) as RawCatalogActivity[];
  const catalog = catalogRaw.map(adaptCatalogActivity);

  const structureText = (await zip.file("structure.json")?.async("text")) ?? "[]";
  const structureRaw = JSON.parse(structureText);

  // Construir mapa actividadId → {code, name, unit} ANTES de adaptar estructura
  // (lo necesitamos para enriquecer las líneas de cantidad en español)
  const activityMapFromRaw = buildActivityMapFromRaw(structureRaw);
  const structure = adaptStructure(structureRaw);
  // También construir desde el árbol ya adaptado por si acaso
  const activityMapFromAdapted = buildActivityCodeMap(structure);
  const activityMap = new Map([...activityMapFromAdapted, ...activityMapFromRaw]);

  const quantitiesFile = zip.file("quantities.ndjson") ?? zip.file("quantities.json");
  let quantities: BcqQuantity[] = [];
  if (quantitiesFile) {
    const qText = await quantitiesFile.async("text");
    const rawLines = qText.trim().startsWith("[")
      ? (JSON.parse(qText) as RawQuantity[])
      : parseNdjson<RawQuantity>(qText);
    quantities = rawLines.map((q) => adaptQuantity(q, activityMap));
  }

  const elementsFile = zip.file("elements.ndjson") ?? zip.file("elements.json");
  let elements: BcqElement[] = [];
  if (elementsFile) {
    const eText = await elementsFile.async("text");
    const rawEls = eText.trim().startsWith("[")
      ? (JSON.parse(eText) as RawElement[])
      : parseNdjson<RawElement>(eText);
    elements = rawEls.map(adaptElement);
  }

  const decisionsFile =
    zip.file("traceability/decisions.ndjson") ?? zip.file("decisions.ndjson");
  let decisions: BcqDecision[] = [];
  if (decisionsFile) {
    const dText = await decisionsFile.async("text");
    const rawDs = dText.trim().startsWith("[")
      ? (JSON.parse(dText) as RawDecision[])
      : parseNdjson<RawDecision>(dText);
    decisions = rawDs.map(adaptDecision);
  }

  const validatedQuantities = quantities.filter(
    (q) => q.status === "VALIDADA"
  );

  return { manifest, project, sources, catalog, structure, quantities, elements, decisions, validatedQuantities };
}

/* ------------------------------------------------------------------ */
/* createBcqPackage — genera paquetes en formato inglés (uso interno)   */
/* ------------------------------------------------------------------ */
function toNdjsonCreate(items: unknown[]): string {
  return items.map((it) => JSON.stringify(it)).join("\n") + "\n";
}

export async function createBcqPackage(pkg: {
  project: BcqProject;
  sources: BcqSource[];
  catalog: BcqActivity[];
  structure: BcqStructureNode[];
  quantities: BcqQuantity[];
  elements?: BcqElement[];
  decisions?: BcqDecision[];
  producerVersion?: string;
  revision?: string;
  exportMode?: "VALIDATED_ONLY" | "FULL_AUDIT";
}): Promise<Buffer> {
  const zip = new JSZip();
  zip.file("mimetype", "application/vnd.bimcost.quantity+zip", { compression: "STORE" });

  const exportMode = pkg.exportMode || "VALIDATED_ONLY";
  const qList =
    exportMode === "VALIDATED_ONLY"
      ? pkg.quantities.filter((q) => q.status === "VALIDADA")
      : pkg.quantities;

  const projectText = JSON.stringify(pkg.project, null, 2);
  const sourcesText = JSON.stringify(pkg.sources, null, 2);
  const catalogText = JSON.stringify(pkg.catalog, null, 2);
  const structureText = JSON.stringify(pkg.structure, null, 2);
  const quantitiesText = toNdjsonCreate(qList);
  const elementsText = toNdjsonCreate(pkg.elements || []);
  const decisionsText = toNdjsonCreate(pkg.decisions || []);

  const checksums: Record<string, string> = {
    "project.json": sha256(projectText),
    "sources.json": sha256(sourcesText),
    "catalog-snapshot.json": sha256(catalogText),
    "structure.json": sha256(structureText),
    "quantities.ndjson": sha256(quantitiesText),
    "elements.ndjson": sha256(elementsText),
    "traceability/decisions.ndjson": sha256(decisionsText),
  };

  const manifest: BcqManifest = {
    format: "BCQ",
    version: "1.0",
    packageId: `bcq-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`,
    projectId: pkg.project.id,
    projectCode: pkg.project.code,
    projectName: pkg.project.name,
    revision: pkg.revision || "REV-01",
    exportedAt: new Date().toISOString(),
    producer: {
      name: "BIMCost Quantity",
      version: pkg.producerVersion || "0.6.1",
      build: "2026-release",
    },
    exportMode,
    stats: {
      sources: pkg.sources.length,
      activities: pkg.catalog.length,
      quantities: qList.length,
      elements: (pkg.elements || []).length,
      decisions: (pkg.decisions || []).length,
    },
    checksums,
  };

  zip.file("manifest.json", JSON.stringify(manifest, null, 2));
  zip.file("project.json", projectText);
  zip.file("sources.json", sourcesText);
  zip.file("catalog-snapshot.json", catalogText);
  zip.file("structure.json", structureText);
  zip.file("quantities.ndjson", quantitiesText);
  zip.file("elements.ndjson", elementsText);
  zip.file("traceability/decisions.ndjson", decisionsText);
  zip.file(
    "schemas/bcq-1.0.schema.json",
    JSON.stringify({
      $schema: "http://json-schema.org/draft-07/schema#",
      title: "BIMCost Quantity Package Schema v1.0",
      type: "object",
      required: ["manifest", "project", "sources", "catalog", "structure", "quantities"],
    }, null, 2)
  );

  return zip.generateAsync({
    type: "nodebuffer",
    compression: "DEFLATE",
    compressionOptions: { level: 6 },
  });
}
