/* ================================================================== */
/*  Motor geométrico IFC                                               */
/*  Calcula dimensiones reales cuando el modelo NO trae BaseQuantities:*/
/*  perfiles extruidos, bounding boxes, mallas, polilíneas y sólidos   */
/*  de barrido, con transformaciones de colocación (placement).        */
/* ================================================================== */

export interface Vec3 { x: number; y: number; z: number }

/** Transformación rígida: origen + ejes (base ortonormal). */
export interface Transform {
  o: Vec3;
  x: Vec3;
  y: Vec3;
  z: Vec3;
}

export const IDENTITY: Transform = {
  o: { x: 0, y: 0, z: 0 },
  x: { x: 1, y: 0, z: 0 },
  y: { x: 0, y: 1, z: 0 },
  z: { x: 0, y: 0, z: 1 },
};

export function norm(v: Vec3): Vec3 {
  const l = Math.hypot(v.x, v.y, v.z);
  return l > 1e-12 ? { x: v.x / l, y: v.y / l, z: v.z / l } : { x: 0, y: 0, z: 1 };
}
export function cross(a: Vec3, b: Vec3): Vec3 {
  return { x: a.y * b.z - a.z * b.y, y: a.z * b.x - a.x * b.z, z: a.x * b.y - a.y * b.x };
}
export function dot(a: Vec3, b: Vec3): number {
  return a.x * b.x + a.y * b.y + a.z * b.z;
}
export function sub(a: Vec3, b: Vec3): Vec3 {
  return { x: a.x - b.x, y: a.y - b.y, z: a.z - b.z };
}

/** Construye una base ortonormal a partir del eje Z y una referencia X. */
export function axisPlacement(loc: Vec3, axisZ?: Vec3 | null, refX?: Vec3 | null): Transform {
  const z = norm(axisZ ?? { x: 0, y: 0, z: 1 });
  let x = refX ?? { x: 1, y: 0, z: 0 };
  // Ortogonalizar X respecto de Z
  const d = dot(x, z);
  x = norm({ x: x.x - d * z.x, y: x.y - d * z.y, z: x.z - d * z.z });
  if (!isFinite(x.x) || Math.hypot(x.x, x.y, x.z) < 1e-9) {
    x = Math.abs(z.z) < 0.9 ? norm(cross({ x: 0, y: 0, z: 1 }, z)) : { x: 1, y: 0, z: 0 };
  }
  const y = cross(z, x);
  return { o: loc, x, y, z };
}

/** Compone padre ∘ hijo. */
export function compose(p: Transform, c: Transform): Transform {
  const tp = (v: Vec3): Vec3 => ({
    x: p.x.x * v.x + p.y.x * v.y + p.z.x * v.z,
    y: p.x.y * v.x + p.y.y * v.y + p.z.y * v.z,
    z: p.x.z * v.x + p.y.z * v.y + p.z.z * v.z,
  });
  const ro = tp(c.o);
  return {
    o: { x: p.o.x + ro.x, y: p.o.y + ro.y, z: p.o.z + ro.z },
    x: tp(c.x),
    y: tp(c.y),
    z: tp(c.z),
  };
}

export function applyPoint(t: Transform, v: Vec3): Vec3 {
  return {
    x: t.o.x + t.x.x * v.x + t.y.x * v.y + t.z.x * v.z,
    y: t.o.y + t.x.y * v.x + t.y.y * v.y + t.z.y * v.z,
    z: t.o.z + t.x.z * v.x + t.y.z * v.y + t.z.z * v.z,
  };
}

/* ------------------------------------------------------------------ */
/* Caja envolvente local                                               */
/* ------------------------------------------------------------------ */
export interface OrientedBox {
  center: Vec3;
  /** Dimensiones en sus ejes propios, ordenadas mayor → menor. */
  size: [number, number, number];
  /** Ejes unitarios correspondientes a size. */
  axes: [Vec3, Vec3, Vec3];
}

/**
 * Caja orientada por análisis de componentes principales (PCA).
 * Fundamental para vigas inclinadas: la caja global confunde el desnivel
 * de cubierta con el canto de la sección.
 */
export function orientedBox(points: Vec3[]): OrientedBox | null {
  if (points.length < 4) return null;
  const mean = points.reduce((a, p) => ({ x: a.x + p.x, y: a.y + p.y, z: a.z + p.z }), { x: 0, y: 0, z: 0 });
  mean.x /= points.length; mean.y /= points.length; mean.z /= points.length;

  const C = [[0, 0, 0], [0, 0, 0], [0, 0, 0]];
  for (const p of points) {
    const d = [p.x - mean.x, p.y - mean.y, p.z - mean.z];
    for (let i = 0; i < 3; i++) for (let j = 0; j < 3; j++) C[i][j] += d[i] * d[j];
  }
  for (let i = 0; i < 3; i++) for (let j = 0; j < 3; j++) C[i][j] /= points.length;

  const mul = (M: number[][], v: number[]) => [
    M[0][0] * v[0] + M[0][1] * v[1] + M[0][2] * v[2],
    M[1][0] * v[0] + M[1][1] * v[1] + M[1][2] * v[2],
    M[2][0] * v[0] + M[2][1] * v[1] + M[2][2] * v[2],
  ];
  const unit = (v: number[]) => {
    const l = Math.hypot(...v) || 1;
    return v.map((x) => x / l);
  };
  const power = (M: number[][], seed: number[]) => {
    let v = unit(seed);
    for (let k = 0; k < 40; k++) v = unit(mul(M, v));
    const mv = mul(M, v);
    const lambda = v[0] * mv[0] + v[1] * mv[1] + v[2] * mv[2];
    return { v, lambda };
  };

  const a = power(C, [1, 0.7, 0.3]);
  const D = C.map((row, i) => row.map((x, j) => x - a.lambda * a.v[i] * a.v[j]));
  let b = power(D, [0.2, 1, 0.6]);
  // Gram-Schmidt para garantizar ortogonalidad
  const dab = a.v[0] * b.v[0] + a.v[1] * b.v[1] + a.v[2] * b.v[2];
  b.v = unit(b.v.map((x, i) => x - dab * a.v[i]));
  const va: Vec3 = { x: a.v[0], y: a.v[1], z: a.v[2] };
  const vb: Vec3 = { x: b.v[0], y: b.v[1], z: b.v[2] };
  let vc = norm(cross(va, vb));
  if (Math.hypot(vc.x, vc.y, vc.z) < 0.5) vc = { x: 0, y: 0, z: 1 };

  let axes: Vec3[] = [va, vb, vc];
  let spans = axes.map((axis) => {
    let min = Infinity, max = -Infinity;
    for (const p of points) {
      const q = dot(p, axis);
      if (q < min) min = q;
      if (q > max) max = q;
    }
    return { min, max, size: max - min, axis };
  });
  spans.sort((x, y) => y.size - x.size);
  axes = spans.map((s) => s.axis);

  // Centro a partir de los intervalos proyectados
  const center: Vec3 = { x: 0, y: 0, z: 0 };
  for (const s of spans) {
    const m = (s.min + s.max) / 2;
    center.x += s.axis.x * m;
    center.y += s.axis.y * m;
    center.z += s.axis.z * m;
  }
  return {
    center,
    size: [spans[0].size, spans[1].size, spans[2].size],
    axes: [axes[0], axes[1], axes[2]],
  };
}

export class Box {
  min: Vec3 = { x: Infinity, y: Infinity, z: Infinity };
  max: Vec3 = { x: -Infinity, y: -Infinity, z: -Infinity };
  empty = true;

  add(p: Vec3) {
    this.empty = false;
    if (p.x < this.min.x) this.min.x = p.x;
    if (p.y < this.min.y) this.min.y = p.y;
    if (p.z < this.min.z) this.min.z = p.z;
    if (p.x > this.max.x) this.max.x = p.x;
    if (p.y > this.max.y) this.max.y = p.y;
    if (p.z > this.max.z) this.max.z = p.z;
  }
  size(): Vec3 {
    if (this.empty) return { x: 0, y: 0, z: 0 };
    return { x: this.max.x - this.min.x, y: this.max.y - this.min.y, z: this.max.z - this.min.z };
  }
  center(): Vec3 {
    if (this.empty) return { x: 0, y: 0, z: 0 };
    return {
      x: (this.min.x + this.max.x) / 2,
      y: (this.min.y + this.max.y) / 2,
      z: (this.min.z + this.max.z) / 2,
    };
  }
}

/* ------------------------------------------------------------------ */
/* Resultado del análisis geométrico de un elemento                    */
/* ------------------------------------------------------------------ */
export interface GeometryResult {
  /** Origen del cálculo, para mostrarlo como evidencia. */
  kind: string;
  /** Tamaño de la caja envolvente local (m). */
  size: Vec3;
  /** Centro en coordenadas de mundo (m). */
  center: Vec3;
  /** Giro alrededor de Z (radianes) para dibujar la caja orientada. */
  yaw: number;
  /** Área del perfil extruido (m²) si aplica. */
  profileArea: number | null;
  /** Perímetro del perfil (m) si aplica. */
  profilePerimeter: number | null;
  /** Longitud de extrusión o de directriz (m). */
  sweepLength: number | null;
  /** Volumen calculado (m³). */
  volume: number | null;
  /** Área de superficie total de la malla (m²), si se pudo calcular. */
  meshArea: number | null;
  /** Longitud de la curva de eje (m), para muros y tuberías. */
  axisLength: number | null;
  /** Cara principal real del elemento (ya recortada), para medir y dibujar. */
  face?: {
    outline: [number, number][];
    holes: [number, number][][];
    thickness: number;
    origin: [number, number, number];
    uAxis: [number, number, number];
    vAxis: [number, number, number];
    nAxis: [number, number, number];
    clipped: boolean;
    /** Área real tras restar sólidos de corte. */
    exactArea?: number;
  };
  /** ¿El sólido fue recortado por un plano (cubierta inclinada, etc.)? */
  clipped?: boolean;
  /** Caja orientada a los ejes propios del elemento (mayor → menor). */
  oriented?: OrientedBox;
}

export function emptyGeometry(): GeometryResult {
  return {
    kind: "sin-geometria",
    size: { x: 0, y: 0, z: 0 },
    center: { x: 0, y: 0, z: 0 },
    yaw: 0,
    profileArea: null,
    profilePerimeter: null,
    sweepLength: null,
    volume: null,
    meshArea: null,
    axisLength: null,
  };
}

/* ------------------------------------------------------------------ */
/* Utilidades de polígonos                                             */
/* ------------------------------------------------------------------ */
export function polygonArea2D(pts: { x: number; y: number }[]): number {
  let a = 0;
  for (let i = 0; i < pts.length; i++) {
    const p = pts[i];
    const q = pts[(i + 1) % pts.length];
    a += p.x * q.y - q.x * p.y;
  }
  return Math.abs(a) / 2;
}

export function polylineLength2D(pts: { x: number; y: number }[], closed = false): number {
  let l = 0;
  for (let i = 0; i < pts.length - 1; i++) {
    l += Math.hypot(pts[i + 1].x - pts[i].x, pts[i + 1].y - pts[i].y);
  }
  if (closed && pts.length > 2) {
    l += Math.hypot(pts[0].x - pts[pts.length - 1].x, pts[0].y - pts[pts.length - 1].y);
  }
  return l;
}

export function polylineLength3D(pts: Vec3[]): number {
  let l = 0;
  for (let i = 0; i < pts.length - 1; i++) {
    l += Math.hypot(pts[i + 1].x - pts[i].x, pts[i + 1].y - pts[i].y, pts[i + 1].z - pts[i].z);
  }
  return l;
}

/** Área de un polígono 3D mediante la fórmula de Newell. */
export function polygonArea3D(pts: Vec3[]): number {
  if (pts.length < 3) return 0;
  let nx = 0, ny = 0, nz = 0;
  for (let i = 0; i < pts.length; i++) {
    const a = pts[i];
    const b = pts[(i + 1) % pts.length];
    nx += (a.y - b.y) * (a.z + b.z);
    ny += (a.z - b.z) * (a.x + b.x);
    nz += (a.x - b.x) * (a.y + b.y);
  }
  return Math.hypot(nx, ny, nz) / 2;
}

/** Volumen firmado de una malla cerrada (teorema de la divergencia). */
export function meshVolume(triangles: [Vec3, Vec3, Vec3][]): number {
  let v = 0;
  for (const [a, b, c] of triangles) {
    v += (a.x * (b.y * c.z - c.y * b.z) - a.y * (b.x * c.z - c.x * b.z) + a.z * (b.x * c.y - c.x * b.y)) / 6;
  }
  return Math.abs(v);
}

/** Descompone un polígono convexo/simple en triángulos (abanico). */
export function fanTriangles(pts: Vec3[]): [Vec3, Vec3, Vec3][] {
  const out: [Vec3, Vec3, Vec3][] = [];
  for (let i = 1; i < pts.length - 1; i++) out.push([pts[0], pts[i], pts[i + 1]]);
  return out;
}

/* ------------------------------------------------------------------ */
/* Recorte de polígonos por semiespacios (muros cortados por cubierta)  */
/* ------------------------------------------------------------------ */
export interface Plane {
  /** Punto del plano (mundo). */
  p: Vec3;
  /** Normal del plano (mundo). El material CONSERVADO es el lado -normal. */
  n: Vec3;
}

/**
 * Recorta un polígono 3D con un plano (algoritmo de Sutherland–Hodgman).
 * Conserva la parte situada del lado negativo de la normal, que es la
 * convención de IfcHalfSpaceSolid con AgreementFlag = TRUE.
 */
export function clipPolygonByPlane(poly: Vec3[], plane: Plane, keepPositive = false): Vec3[] {
  if (poly.length < 3) return [];
  const sign = keepPositive ? -1 : 1;
  const dist = (v: Vec3) => sign * dot(sub(v, plane.p), plane.n);
  const out: Vec3[] = [];
  const EPS = 1e-9;

  for (let i = 0; i < poly.length; i++) {
    const a = poly[i];
    const b = poly[(i + 1) % poly.length];
    const da = dist(a);
    const db = dist(b);
    const aIn = da <= EPS;
    const bIn = db <= EPS;
    if (aIn) out.push(a);
    if (aIn !== bIn) {
      const t = da / (da - db);
      out.push({
        x: a.x + (b.x - a.x) * t,
        y: a.y + (b.y - a.y) * t,
        z: a.z + (b.z - a.z) * t,
      });
    }
  }
  // Eliminar vértices duplicados consecutivos
  const clean: Vec3[] = [];
  for (const p of out) {
    const last = clean[clean.length - 1];
    if (!last || Math.hypot(p.x - last.x, p.y - last.y, p.z - last.z) > 1e-7) clean.push(p);
  }
  if (clean.length > 2) {
    const first = clean[0];
    const last = clean[clean.length - 1];
    if (Math.hypot(first.x - last.x, first.y - last.y, first.z - last.z) < 1e-7) clean.pop();
  }
  return clean.length >= 3 ? clean : [];
}

/**
 * Herramienta sólida de recorte (Archicad exporta los cortes de cubierta
 * como un B-Rep restado, no como un plano). Se modela como la intersección
 * de semiespacios: un punto está DENTRO si queda del lado interior de todas
 * las caras.
 */
export interface SolidTool {
  planes: Plane[];
}

/** Construye la herramienta a partir de las caras del sólido restado. */
export function solidToolFromFaces(faces: Vec3[][]): SolidTool | null {
  if (faces.length < 4) return null;
  // Centroide del sólido: sirve para orientar las normales hacia afuera.
  const all = faces.flat();
  if (all.length < 4) return null;
  const c: Vec3 = {
    x: all.reduce((s, p) => s + p.x, 0) / all.length,
    y: all.reduce((s, p) => s + p.y, 0) / all.length,
    z: all.reduce((s, p) => s + p.z, 0) / all.length,
  };
  const planes: Plane[] = [];
  for (const f of faces) {
    if (f.length < 3) continue;
    let n = norm(cross(sub(f[1], f[0]), sub(f[2], f[0])));
    if (!isFinite(n.x) || Math.hypot(n.x, n.y, n.z) < 0.5) continue;
    // Normal hacia afuera del centroide
    if (dot(sub(c, f[0]), n) > 0) n = { x: -n.x, y: -n.y, z: -n.z };
    // Descartar planos duplicados
    if (planes.some((p) => dot(p.n, n) > 0.999 && Math.abs(dot(sub(p.p, f[0]), n)) < 1e-6)) continue;
    planes.push({ p: f[0], n });
  }
  return planes.length >= 4 ? { planes } : null;
}

/** Parte del polígono que queda DENTRO de la herramienta (convexa). */
export function polygonInsideTool(poly: Vec3[], tool: SolidTool): Vec3[] {
  let current = poly;
  for (const plane of tool.planes) {
    // Conservar el lado interior: dot(p - plane.p, n) <= 0
    current = clipPolygonByPlane(current, plane);
    if (current.length < 3) return [];
  }
  return current;
}

/**
 * Resta una herramienta sólida a un polígono plano.
 * Devuelve el área restante exacta y, cuando el corte lo permite (caso
 * típico de muro bajo cubierta), también el contorno resultante.
 */
export function subtractToolFromPolygon(
  poly: Vec3[],
  tool: SolidTool
): { area: number; polygon: Vec3[]; cut: boolean } {
  const full = polygonArea3D(poly);
  const inside = polygonInsideTool(poly, tool);
  const removed = inside.length >= 3 ? polygonArea3D(inside) : 0;
  if (removed <= 1e-9) return { area: full, polygon: poly, cut: false };

  const remaining = Math.max(0, full - removed);

  // Buscar un único plano que reproduzca el recorte (muro a un agua o
  // a dos aguas): permite conservar la forma real para dibujar y medir.
  let best: { poly: Vec3[]; diff: number } | null = null;
  for (const plane of tool.planes) {
    const outside = clipPolygonByPlane(poly, plane, true);
    if (outside.length < 3) continue;
    const a = polygonArea3D(outside);
    const diff = Math.abs(a - remaining);
    if (!best || diff < best.diff) best = { poly: outside, diff };
  }
  if (best && best.diff <= Math.max(full * 0.02, 1e-6)) {
    return { area: polygonArea3D(best.poly), polygon: best.poly, cut: true };
  }
  // Forma compleja: se conserva el área exacta aunque el contorno no sea simple.
  return { area: remaining, polygon: poly, cut: true };
}

/** Sistema de coordenadas de una cara plana: origen + ejes u, v y normal. */
export interface FaceFrame {
  origin: Vec3;
  u: Vec3;
  v: Vec3;
  n: Vec3;
}

/** Proyecta un punto del mundo a las coordenadas (u, v) de la cara. */
export function toFaceUV(f: FaceFrame, p: Vec3): { u: number; v: number } {
  const d = sub(p, f.origin);
  return { u: dot(d, f.u), v: dot(d, f.v) };
}

/** Convierte coordenadas (u, v) de la cara a un punto del mundo. */
export function fromFaceUV(f: FaceFrame, u: number, v: number): Vec3 {
  return {
    x: f.origin.x + f.u.x * u + f.v.x * v,
    y: f.origin.y + f.u.y * u + f.v.y * v,
    z: f.origin.z + f.u.z * u + f.v.z * v,
  };
}

/** Área de un polígono expresado en coordenadas (u, v). */
export function polygonAreaUV(pts: { u: number; v: number }[]): number {
  let a = 0;
  for (let i = 0; i < pts.length; i++) {
    const p = pts[i];
    const q = pts[(i + 1) % pts.length];
    a += p.u * q.v - q.u * p.v;
  }
  return Math.abs(a) / 2;
}
