/* ================================================================== */
/*  Helpers de servidor compartidos                                    */
/* ================================================================== */
import { and, eq, inArray, ne } from "drizzle-orm";
import { db } from "@/db";
import {
  decisions, elements, quantities, sources, structureNodes,
  catalogActivities, catalogGroups,
} from "@/db/schema";
import type { ElementDimensions, ElementGeometry } from "@/db/schema";
import type { ParsedModel } from "@/lib/ifc/parser";
import type { WorkElement } from "@/lib/engine";

/* ---------- Registro de decisiones profesionales ------------------- */
export async function addDecision(
  projectId: string,
  entityType: string,
  entityId: string | null,
  action: string,
  detail: Record<string, unknown>,
  actor?: string | null
) {
  await db.insert(decisions).values({
    projectId, entityType, entityId, action, detail, actor: actor || null,
  });
}

/* ---------- Elementos de trabajo ------------------------------------ */
export function toWorkElement(row: typeof elements.$inferSelect): WorkElement {
  return {
    id: row.id,
    sourceId: row.sourceId,
    globalId: row.globalId,
    ifcClass: row.ifcClass,
    name: row.name,
    objectType: row.objectType,
    description: row.description,
    typeName: row.typeName,
    semanticType: row.semanticType,
    material: row.material,
    level: row.level,
    layer: row.layer,
    excluded: row.excluded,
    properties: row.properties ?? null,
    quantities: row.quantities ?? null,
    dimensions: (row.dimensions as ElementDimensions | null) ?? null,
  };
}

/* ---------- Importar elementos IFC ---------------------------------- */
export async function importParsedElements(
  projectId: string,
  sourceId: string,
  model: ParsedModel
) {
  const BATCH = 40;
  for (let i = 0; i < model.elements.length; i += BATCH) {
    const slice = model.elements.slice(i, i + BATCH);
    await db.insert(elements).values(
      slice.map((el) => ({
        projectId,
        sourceId,
        globalId: el.globalId,
        ifcClass: el.ifcClass,
        name: el.name,
        objectType: el.objectType,
        description: el.description,
        tag: el.tag,
        typeName: el.typeName,
        semanticType: el.semanticType,
        material: el.material,
        level: el.level,
        layer: el.layer,
        properties: el.properties,
        quantities: el.quantities,
        dimensions: el.dimensions as ElementDimensions,
        dimensionSources: el.dimensionSources,
        geometry: (el.geometry as ElementGeometry | null) ?? null,
        excluded: false,
      }))
    );
  }
  return model.elements.length;
}

/* ---------- Detección de modelos IFC duplicados --------------------- */
import { createHash } from "node:crypto";

export function sha256(text: string): string {
  return createHash("sha256").update(text).digest("hex");
}

/**
 * Huella del CONTENIDO del modelo: se calcula sobre los GlobalId ordenados.
 * Detecta el mismo modelo aunque se haya reexportado con otro nombre de
 * archivo o con una fecha distinta en la cabecera.
 */
export function modelFingerprint(globalIds: (string | null)[]): string {
  const ids = globalIds.filter((g): g is string => !!g).sort();
  return sha256(ids.join("|"));
}

export interface DuplicateSource {
  id: string;
  name: string;
  fileName: string | null;
  createdAt: Date;
  elementos: number;
  motivo: "ARCHIVO_IDENTICO" | "MISMO_MODELO" | "MISMO_NOMBRE";
}

/** Busca si el proyecto ya tiene una fuente equivalente a la que se importa. */
export async function findDuplicateSource(
  projectId: string,
  opts: { contentHash: string; modelHash: string; fileName: string }
): Promise<DuplicateSource | null> {
  const existing = await db
    .select()
    .from(sources)
    .where(and(eq(sources.projectId, projectId), eq(sources.kind, "IFC")));

  const count = async (sourceId: string) => {
    const rows = await db
      .select({ id: elements.id })
      .from(elements)
      .where(eq(elements.sourceId, sourceId));
    return rows.length;
  };

  for (const s of existing) {
    if (s.contentHash && s.contentHash === opts.contentHash) {
      return { id: s.id, name: s.name, fileName: s.fileName, createdAt: s.createdAt, elementos: await count(s.id), motivo: "ARCHIVO_IDENTICO" };
    }
  }
  for (const s of existing) {
    if (s.modelHash && s.modelHash === opts.modelHash) {
      return { id: s.id, name: s.name, fileName: s.fileName, createdAt: s.createdAt, elementos: await count(s.id), motivo: "MISMO_MODELO" };
    }
  }
  for (const s of existing) {
    if (s.fileName && opts.fileName && s.fileName.toLowerCase() === opts.fileName.toLowerCase()) {
      return { id: s.id, name: s.name, fileName: s.fileName, createdAt: s.createdAt, elementos: await count(s.id), motivo: "MISMO_NOMBRE" };
    }
  }
  return null;
}

/* ---------- Detección de duplicados por GlobalId -------------------- */
export interface DuplicateReport {
  duplicated: { globalId: string; quantityId: string; activityCode: string | null; label: string | null }[];
  total: number;
}

/**
 * Busca si los GlobalId indicados ya fueron medidos para la MISMA actividad.
 * Sirve para no duplicar cantidades automáticamente; el profesional puede
 * autorizar la duplicación de forma explícita (p. ej. acabados sobre muros).
 */
export async function findDuplicateMeasurements(
  projectId: string,
  activityId: string,
  globalIds: string[],
  ignoreQuantityId?: string
): Promise<DuplicateReport> {
  if (!globalIds.length) return { duplicated: [], total: 0 };
  const rows = await db
    .select()
    .from(quantities)
    .where(
      and(
        eq(quantities.projectId, projectId),
        eq(quantities.activityId, activityId),
        ignoreQuantityId ? ne(quantities.id, ignoreQuantityId) : undefined,
        inArray(quantities.status, ["PENDIENTE", "PROPUESTA", "VALIDADA"])
      )
    );
  const target = new Set(globalIds);
  const duplicated: DuplicateReport["duplicated"] = [];
  const acts = await db.select().from(catalogActivities).where(eq(catalogActivities.id, activityId));
  const code = acts[0]?.code ?? null;

  for (const q of rows) {
    for (const gid of q.elementGlobalIds ?? []) {
      if (target.has(gid)) {
        duplicated.push({ globalId: gid, quantityId: q.id, activityCode: code, label: q.label });
      }
    }
  }
  return { duplicated, total: duplicated.length };
}

/* ---------- Importar filas de Excel --------------------------------- */
export interface ExcelRow {
  codigo: string;
  actividad: string;
  unidad: string;
  cantidad: number | null;
  nota?: string;
}

export async function importExcelRows(projectId: string, sourceId: string, rows: ExcelRow[]) {
  const acts = await db.select().from(catalogActivities);
  const byCode = new Map(acts.map((a) => [a.code, a]));
  const result = { importadas: 0, sinCodigoCatalogo: 0 };

  for (const r of rows) {
    const act = byCode.get(r.codigo.trim());
    if (!act) result.sinCodigoCatalogo++;
    await db.insert(quantities).values({
      projectId,
      sourceId,
      sourceKind: "EXCEL",
      activityId: act?.id ?? null,
      value: r.cantidad,
      unit: (r.unidad || act?.unit || "").toUpperCase(),
      method: act?.method ?? "MANUAL",
      rule: act
        ? "Cantidad importada desde Excel. Requiere validación profesional antes de entrar a la estructura del proyecto."
        : "Código no encontrado en el catálogo maestro. Asigne la actividad correcta antes de validar.",
      evidence: {
        origen: "Excel",
        fila: r,
        nota: "Cantidad declarada en hoja de cálculo; no proviene de geometría BIM.",
      },
      elementIds: [],
      elementGlobalIds: [],
      elementCount: 0,
      status: "PENDIENTE",
      note: act ? r.nota ?? null : `Actividad declarada: ${r.actividad}`,
    });
    result.importadas++;
    if (act) await ensureStructureNodes(projectId, act.id);
  }
  return result;
}

/* ---------- Estructura del proyecto (WBS) --------------------------- */
export async function ensureStructureNodes(projectId: string, activityId: string) {
  const [act] = await db.select().from(catalogActivities).where(eq(catalogActivities.id, activityId)).limit(1);
  if (!act) return null;

  const nodes = await db.select().from(structureNodes).where(eq(structureNodes.projectId, projectId));

  const chapter = nodes.find((n) => n.kind === "CAPITULO" && n.code === act.chapterCode);
  let chapterId = chapter?.id;
  if (!chapterId) {
    const [created] = await db
      .insert(structureNodes)
      .values({
        projectId, parentId: null, kind: "CAPITULO",
        code: act.chapterCode, name: act.chapterName,
        sortOrder: parseInt(act.chapterCode, 10) || 0,
      })
      .returning();
    chapterId = created.id;
  }

  const section = nodes.find((n) => n.kind === "SECCION" && n.code === act.sectionCode && n.parentId === chapterId);
  let sectionId = section?.id;
  if (!sectionId) {
    const [created] = await db
      .insert(structureNodes)
      .values({
        projectId, parentId: chapterId, kind: "SECCION",
        code: act.sectionCode, name: act.sectionName,
        sortOrder: parseInt(act.sectionCode.split(".")[1] ?? "0", 10) || 0,
      })
      .returning();
    sectionId = created.id;
  }

  const exists = nodes.some((n) => n.kind === "ACTIVIDAD" && n.parentId === sectionId && n.activityId === activityId);
  if (!exists) {
    await db.insert(structureNodes).values({
      projectId, parentId: sectionId, kind: "ACTIVIDAD",
      code: act.code, name: act.name, activityId, sortOrder: 0,
    });
  }
  return { chapterId, sectionId };
}

/* ---------- Limpieza de la estructura del proyecto ------------------ */
/**
 * Elimina de la estructura las actividades que ya no tienen ninguna cantidad
 * asociada, y los capítulos/secciones que quedan vacíos. Evita que aparezcan
 * líneas en cero en el presupuesto y en la exportación.
 *
 * Devuelve cuántos nodos se retiraron.
 */
export async function pruneEmptyStructure(projectId: string): Promise<number> {
  const nodes = await db.select().from(structureNodes).where(eq(structureNodes.projectId, projectId));
  const qtys = await db.select().from(quantities).where(eq(quantities.projectId, projectId));
  const withQuantities = new Set(qtys.map((q) => q.activityId).filter(Boolean) as string[]);

  const removable = nodes.filter(
    (n) => n.kind === "ACTIVIDAD" && (!n.activityId || !withQuantities.has(n.activityId))
  );
  const removeIds = new Set(removable.map((n) => n.id));

  // Secciones sin actividades vivas
  for (const sec of nodes.filter((n) => n.kind === "SECCION")) {
    const children = nodes.filter((n) => n.parentId === sec.id);
    if (children.length && children.every((c) => removeIds.has(c.id))) removeIds.add(sec.id);
    if (!children.length) removeIds.add(sec.id);
  }
  // Capítulos sin secciones vivas
  for (const ch of nodes.filter((n) => n.kind === "CAPITULO")) {
    const children = nodes.filter((n) => n.parentId === ch.id);
    if (children.length && children.every((c) => removeIds.has(c.id))) removeIds.add(ch.id);
    if (!children.length) removeIds.add(ch.id);
  }

  if (removeIds.size) {
    await db.delete(structureNodes).where(inArray(structureNodes.id, [...removeIds]));
  }
  return removeIds.size;
}

/* ---------- Capítulos / secciones del catálogo ---------------------- */
export async function ensureCatalogGroup(
  kind: "CAPITULO" | "SECCION",
  code: string,
  name: string,
  parentCode?: string | null
) {
  const existing = await db
    .select()
    .from(catalogGroups)
    .where(and(eq(catalogGroups.kind, kind), eq(catalogGroups.code, code)))
    .limit(1);
  if (existing.length) return existing[0];
  const [created] = await db
    .insert(catalogGroups)
    .values({
      kind, code, name, parentCode: parentCode ?? null,
      sortOrder: parseInt(code.replace(/\D/g, "").slice(0, 4) || "0", 10) || 0,
      active: true,
    })
    .returning();
  return created;
}

/** Devuelve los códigos de capítulos y secciones desactivados. */
export async function inactiveCatalogScopes() {
  const rows = await db.select().from(catalogGroups).where(eq(catalogGroups.active, false));
  return {
    chapters: new Set(rows.filter((r) => r.kind === "CAPITULO").map((r) => r.code)),
    sections: new Set(rows.filter((r) => r.kind === "SECCION").map((r) => r.code)),
  };
}

/* ---------- Fuente manual del proyecto ------------------------------ */
export async function ensureManualSource(projectId: string) {
  const existing = await db
    .select()
    .from(sources)
    .where(and(eq(sources.projectId, projectId), eq(sources.kind, "MANUAL")))
    .limit(1);
  if (existing.length) return existing[0];
  const [created] = await db
    .insert(sources)
    .values({
      projectId, kind: "MANUAL", name: "Cantidades manuales",
      discipline: "OBRA", status: "ACTIVA",
      stats: { nota: "Mediciones introducidas directamente por el profesional" },
    })
    .returning();
  return created;
}

/* ---------- Limpieza de corridas anteriores ------------------------- */
export async function clearRunArtifacts(runId: string) {
  const { matches, groups } = await import("@/db/schema");
  await db.delete(matches).where(eq(matches.runId, runId));
  await db.delete(groups).where(eq(groups.runId, runId));
}
