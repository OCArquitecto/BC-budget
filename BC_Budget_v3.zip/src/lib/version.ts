export const BIMCOST_VERSION = "0.2.0-beta.1";
export const BIMCOST_BUILD = "2026.09-budget-price-versions-viewer";
export const BIMCOST_PRODUCT = "BIMCost Budget";
