/* ================================================================== */
/*  Datos iniciales para BIMCost Budget: Insumos & APUs Maestros       */
/*  Permite presupuestar de inmediato y probar el cálculo económico    */
/* ================================================================== */

import { db } from "@/db";
import { masterInsumos, masterApus, apuItems, type InsumoCategory } from "@/db/schema";
import { eq, sql } from "drizzle-orm";

export interface SeedInsumo {
  code: string;
  name: string;
  unit: string;
  category: InsumoCategory;
  unitPrice: number;
  supplier?: string;
  source?: string;
}

export interface SeedApu {
  code: string;
  name: string;
  unit: string;
  category: string;
  description: string;
  items: {
    insumoCode: string;
    description: string;
    unit: string;
    category: InsumoCategory;
    quantity: number;
    wastePercentage: number;
    unitPrice: number;
  }[];
}

export const SEED_INSUMOS: SeedInsumo[] = [
  // MATERIALES
  { code: "MAT-001", name: "Cemento Gris Tipo UG (Saco 50kg)", unit: "SC", category: "MATERIAL", unitPrice: 32500, supplier: "Argos / Holcim", source: "Catálogo Regional" },
  { code: "MAT-002", name: "Arena de revoque / pañete", unit: "M3", category: "MATERIAL", unitPrice: 65000, supplier: "Cantera Central", source: "Catálogo Regional" },
  { code: "MAT-003", name: "Arena de concreto", unit: "M3", category: "MATERIAL", unitPrice: 72000, supplier: "Cantera Central", source: "Catálogo Regional" },
  { code: "MAT-004", name: "Grava triturada 1/2 pulgada", unit: "M3", category: "MATERIAL", unitPrice: 85000, supplier: "Cantera Central", source: "Catálogo Regional" },
  { code: "MAT-005", name: "Bloque de concreto estructural 15x20x40", unit: "UND", category: "MATERIAL", unitPrice: 3800, supplier: "Prefanorte", source: "Cotización Proveedor" },
  { code: "MAT-006", name: "Bloque de concreto interior 12x20x40", unit: "UND", category: "MATERIAL", unitPrice: 3200, supplier: "Prefanorte", source: "Cotización Proveedor" },
  { code: "MAT-007", name: "Ladrillo tolete común", unit: "UND", category: "MATERIAL", unitPrice: 1100, supplier: "Chircal Santa Fe", source: "Catálogo Regional" },
  { code: "MAT-008", name: "Acero de refuerzo figurado 60.000 PSI", unit: "KG", category: "MATERIAL", unitPrice: 4800, supplier: "Diaco / Gerdau", source: "Lista Siderúrgica" },
  { code: "MAT-009", name: "Alambre negro calibre 18", unit: "KG", category: "MATERIAL", unitPrice: 6500, supplier: "Ferretería Central", source: "Catálogo Regional" },
  { code: "MAT-010", name: "Pintura vinilo tipo 1 lavable (Galón)", unit: "GLN", category: "MATERIAL", unitPrice: 62000, supplier: "Pintuco / Corona", source: "Catálogo Distribuidor" },
  { code: "MAT-011", name: "Estuco acrílico interior (Cuñete 30kg)", unit: "UND", category: "MATERIAL", unitPrice: 48000, supplier: "Pintuco", source: "Catálogo Distribuidor" },
  { code: "MAT-012", name: "Madera estructural abarco/chanul para viga", unit: "M", category: "MATERIAL", unitPrice: 42000, supplier: "Maderera Andina", source: "Cotización Proveedor" },
  { code: "MAT-013", name: "Madera pino pátula inmunizada para pares", unit: "M", category: "MATERIAL", unitPrice: 24000, supplier: "Maderas del Bosque", source: "Cotización Proveedor" },
  { code: "MAT-014", name: "Teja termoacústica UPVC / Teja barro", unit: "M2", category: "MATERIAL", unitPrice: 54000, supplier: "Ajustes Cubiertas", source: "Catálogo Fabricante" },
  { code: "MAT-015", name: "Tubería PVC sanitaria 2 pulgadas (Tramo 6m)", unit: "TR", category: "MATERIAL", unitPrice: 46000, supplier: "Pavco / Gerfor", source: "Lista Distribuidor" },
  { code: "MAT-016", name: "Tubería PVC presión 1/2 pulgada RDE 9", unit: "TR", category: "MATERIAL", unitPrice: 22000, supplier: "Pavco", source: "Lista Distribuidor" },
  { code: "MAT-017", name: "Combo sanitario acuacer + lavamanos", unit: "JGO", category: "MATERIAL", unitPrice: 295000, supplier: "Corona", source: "Catálogo Comercial" },
  { code: "MAT-018", name: "Cable de cobre THHN No. 12 AWG", unit: "M", category: "MATERIAL", unitPrice: 2400, supplier: "Centelsa / Procables", source: "Catálogo Eléctrico" },
  { code: "MAT-019", name: "Tomacorriente doble 15A con polo a tierra", unit: "UND", category: "MATERIAL", unitPrice: 14500, supplier: "Legrand / Luminex", source: "Catálogo Eléctrico" },
  { code: "MAT-020", name: "Puerta entamborada en madera 0.90x2.10 con marco y cerradura", unit: "UND", category: "MATERIAL", unitPrice: 380000, supplier: "Carpintería Especial", source: "Cotización Taller" },

  // MANO DE OBRA (Costos / Jornal incluyendo factor prestacional ~1.65)
  { code: "MO-001", name: "Cuadrilla 1: Oficial (1) + Ayudante (1) de obra civil", unit: "JOR", category: "MANO_DE_OBRA", unitPrice: 195000, supplier: "Personal Directo", source: "Convención / Salario Mínimo + Cargas" },
  { code: "MO-002", name: "Cuadrilla 2: Oficial (1) + Ayudante (2) estructura", unit: "JOR", category: "MANO_DE_OBRA", unitPrice: 275000, supplier: "Personal Directo", source: "Convención / Salario Mínimo + Cargas" },
  { code: "MO-003", name: "Cuadrilla Pintor especialista (1) + Ayudante (1)", unit: "JOR", category: "MANO_DE_OBRA", unitPrice: 185000, supplier: "Personal Directo", source: "Convención / Salario Mínimo + Cargas" },
  { code: "MO-004", name: "Cuadrilla Electricista calificado (1) + Ayudante (1)", unit: "JOR", category: "MANO_DE_OBRA", unitPrice: 210000, supplier: "Personal Directo", source: "Convención / Salario Mínimo + Cargas" },
  { code: "MO-005", name: "Cuadrilla Plomero / Hidrosanitario (1) + Ayudante (1)", unit: "JOR", category: "MANO_DE_OBRA", unitPrice: 205000, supplier: "Personal Directo", source: "Convención / Salario Mínimo + Cargas" },
  { code: "MO-006", name: "Cuadrilla Carpintero armador de madera (1) + Ayudante (1)", unit: "JOR", category: "MANO_DE_OBRA", unitPrice: 200000, supplier: "Personal Directo", source: "Convención / Salario Mínimo + Cargas" },

  // EQUIPOS & HERRAMIENTAS
  { code: "EQ-001", name: "Mezcladora de concreto 1 bulto (Día)", unit: "DIA", category: "EQUIPO", unitPrice: 65000, supplier: "Alquiler Equipos", source: "Tarifa Alquiler" },
  { code: "EQ-002", name: "Vibrador de concreto a gasolina (Día)", unit: "DIA", category: "EQUIPO", unitPrice: 45000, supplier: "Alquiler Equipos", source: "Tarifa Alquiler" },
  { code: "EQ-003", name: "Formaleta metálica / puntales para losa (M2/mes)", unit: "M2", category: "EQUIPO", unitPrice: 18000, supplier: "Formaletas Andina", source: "Tarifa Alquiler" },
  { code: "EQ-004", name: "Andamio tubular certificado (Cuerpo/mes)", unit: "UND", category: "EQUIPO", unitPrice: 35000, supplier: "Andamios Certificados", source: "Tarifa Alquiler" },
  { code: "EQ-005", name: "Herramienta menor (% de Mano de Obra)", unit: "GLB", category: "EQUIPO", unitPrice: 1, supplier: "Herramienta de Cuadrilla", source: "Porcentaje Estándar 5%" },

  // TRANSPORTE
  { code: "TRA-001", name: "Acarreo y descargue interno de materiales en obra", unit: "GLB", category: "TRANSPORTE", unitPrice: 15000, supplier: "Transporte Local", source: "Tarifa de Sitio" },
];

export const SEED_APUS: SeedApu[] = [
  {
    code: "APU-01.01",
    name: "Muro en bloque de concreto e=12 cm pegado con mortero 1:4",
    unit: "M2",
    category: "01 MAMPOSTERÍA",
    description: "Suministro e instalación de muro interior en bloque de concreto 12x20x40 pegado con mortero de arena y cemento.",
    items: [
      { insumoCode: "MAT-006", description: "Bloque concreto 12x20x40 (12.5 und/m2)", unit: "UND", category: "MATERIAL", quantity: 12.5, wastePercentage: 5, unitPrice: 3200 },
      { insumoCode: "MAT-001", description: "Cemento Gris UG", unit: "SC", category: "MATERIAL", quantity: 0.18, wastePercentage: 5, unitPrice: 32500 },
      { insumoCode: "MAT-002", description: "Arena de pega", unit: "M3", category: "MATERIAL", quantity: 0.024, wastePercentage: 8, unitPrice: 65000 },
      { insumoCode: "MO-001", description: "Cuadrilla 1 (Rendimiento 14 m2/jor)", unit: "JOR", category: "MANO_DE_OBRA", quantity: 0.0714, wastePercentage: 0, unitPrice: 195000 },
      { insumoCode: "EQ-005", description: "Herramienta menor 5% MO", unit: "GLB", category: "EQUIPO", quantity: 696, wastePercentage: 0, unitPrice: 1 },
    ],
  },
  {
    code: "APU-01.02",
    name: "Muro exterior en bloque de concreto e=15 cm",
    unit: "M2",
    category: "01 MAMPOSTERÍA",
    description: "Muro exterior en bloque de concreto 15x20x40 pegado con mortero 1:4 con refuerzo horizontal.",
    items: [
      { insumoCode: "MAT-005", description: "Bloque concreto 15x20x40", unit: "UND", category: "MATERIAL", quantity: 12.5, wastePercentage: 5, unitPrice: 3800 },
      { insumoCode: "MAT-001", description: "Cemento Gris UG", unit: "SC", category: "MATERIAL", quantity: 0.22, wastePercentage: 5, unitPrice: 32500 },
      { insumoCode: "MAT-002", description: "Arena de pega", unit: "M3", category: "MATERIAL", quantity: 0.03, wastePercentage: 8, unitPrice: 65000 },
      { insumoCode: "MO-001", description: "Cuadrilla 1 (Rendimiento 12 m2/jor)", unit: "JOR", category: "MANO_DE_OBRA", quantity: 0.0833, wastePercentage: 0, unitPrice: 195000 },
      { insumoCode: "EQ-005", description: "Herramienta menor 5% MO", unit: "GLB", category: "EQUIPO", quantity: 812, wastePercentage: 0, unitPrice: 1 },
    ],
  },
  {
    code: "APU-02.01",
    name: "Concreto f'c=21 MPa (3000 PSI) para columnas",
    unit: "M3",
    category: "02 ESTRUCTURA",
    description: "Fabricación, vaciado y vibrado de concreto reforzado para columnas (mezcla en obra 1:2:2).",
    items: [
      { insumoCode: "MAT-001", description: "Cemento Gris (7.5 sacos/m3)", unit: "SC", category: "MATERIAL", quantity: 7.5, wastePercentage: 5, unitPrice: 32500 },
      { insumoCode: "MAT-003", description: "Arena de concreto", unit: "M3", category: "MATERIAL", quantity: 0.55, wastePercentage: 7, unitPrice: 72000 },
      { insumoCode: "MAT-004", description: "Grava triturada", unit: "M3", category: "MATERIAL", quantity: 0.75, wastePercentage: 7, unitPrice: 85000 },
      { insumoCode: "MO-002", description: "Cuadrilla 2 estructura (Rendimiento 3.5 m3/jor)", unit: "JOR", category: "MANO_DE_OBRA", quantity: 0.285, wastePercentage: 0, unitPrice: 275000 },
      { insumoCode: "EQ-001", description: "Mezcladora de concreto", unit: "DIA", category: "EQUIPO", quantity: 0.285, wastePercentage: 0, unitPrice: 65000 },
      { insumoCode: "EQ-002", description: "Vibrador de concreto", unit: "DIA", category: "EQUIPO", quantity: 0.285, wastePercentage: 0, unitPrice: 45000 },
    ],
  },
  {
    code: "APU-02.02",
    name: "Concreto f'c=21 MPa para vigas de amarre y aéreas",
    unit: "M3",
    category: "02 ESTRUCTURA",
    description: "Concreto estructural para vigas aéreas y de cimentación, incluye vaciado y curado.",
    items: [
      { insumoCode: "MAT-001", description: "Cemento Gris", unit: "SC", category: "MATERIAL", quantity: 7.5, wastePercentage: 5, unitPrice: 32500 },
      { insumoCode: "MAT-003", description: "Arena de concreto", unit: "M3", category: "MATERIAL", quantity: 0.55, wastePercentage: 7, unitPrice: 72000 },
      { insumoCode: "MAT-004", description: "Grava triturada", unit: "M3", category: "MATERIAL", quantity: 0.75, wastePercentage: 7, unitPrice: 85000 },
      { insumoCode: "MO-002", description: "Cuadrilla estructura (Rendimiento 3.0 m3/jor)", unit: "JOR", category: "MANO_DE_OBRA", quantity: 0.333, wastePercentage: 0, unitPrice: 275000 },
      { insumoCode: "EQ-001", description: "Mezcladora", unit: "DIA", category: "EQUIPO", quantity: 0.333, wastePercentage: 0, unitPrice: 65000 },
      { insumoCode: "EQ-002", description: "Vibrador", unit: "DIA", category: "EQUIPO", quantity: 0.333, wastePercentage: 0, unitPrice: 45000 },
    ],
  },
  {
    code: "APU-03.01",
    name: "Viga de madera estructural cepillada (0.08x0.15 m)",
    unit: "M",
    category: "03 CUBIERTAS Y MADERAS",
    description: "Suministro e instalación de viga en madera estructural aserrada y cepillada, incluye fijaciones y tratamiento preservativo.",
    items: [
      { insumoCode: "MAT-012", description: "Madera estructural abarco/chanul", unit: "M", category: "MATERIAL", quantity: 1.05, wastePercentage: 5, unitPrice: 42000 },
      { insumoCode: "MO-006", description: "Cuadrilla carpintero armador (Rendimiento 18 m/jor)", unit: "JOR", category: "MANO_DE_OBRA", quantity: 0.0555, wastePercentage: 0, unitPrice: 200000 },
      { insumoCode: "EQ-005", description: "Herramienta menor 5% MO", unit: "GLB", category: "EQUIPO", quantity: 555, wastePercentage: 0, unitPrice: 1 },
    ],
  },
  {
    code: "APU-03.02",
    name: "Estructura de madera para cubierta: Pares y Cabios (RoofMaker)",
    unit: "M",
    category: "03 CUBIERTAS Y MADERAS",
    description: "Suministro, cortes diagonales, ensamble y fijación de pares y cabios de madera inmunizada para cubierta.",
    items: [
      { insumoCode: "MAT-013", description: "Madera pino pátula inmunizada sección 6x12cm", unit: "M", category: "MATERIAL", quantity: 1.05, wastePercentage: 5, unitPrice: 24000 },
      { insumoCode: "MO-006", description: "Cuadrilla carpintero (Rendimiento 22 m/jor)", unit: "JOR", category: "MANO_DE_OBRA", quantity: 0.0454, wastePercentage: 0, unitPrice: 200000 },
      { insumoCode: "EQ-005", description: "Herramienta menor 5% MO", unit: "GLB", category: "EQUIPO", quantity: 454, wastePercentage: 0, unitPrice: 1 },
    ],
  },
  {
    code: "APU-04.01",
    name: "Friso / Pañete liso sobre muros (1:4) e=1.5 cm",
    unit: "M2",
    category: "04 ACABADOS",
    description: "Revoque / pañete liso sobre mampostería con mortero arena lavada y cemento 1:4.",
    items: [
      { insumoCode: "MAT-001", description: "Cemento Gris UG", unit: "SC", category: "MATERIAL", quantity: 0.12, wastePercentage: 5, unitPrice: 32500 },
      { insumoCode: "MAT-002", description: "Arena de revoque", unit: "M3", category: "MATERIAL", quantity: 0.022, wastePercentage: 8, unitPrice: 65000 },
      { insumoCode: "MO-001", description: "Cuadrilla 1 revoque (Rendimiento 18 m2/jor)", unit: "JOR", category: "MANO_DE_OBRA", quantity: 0.0555, wastePercentage: 0, unitPrice: 195000 },
      { insumoCode: "EQ-004", description: "Andamios tubulares", unit: "UND", category: "EQUIPO", quantity: 0.05, wastePercentage: 0, unitPrice: 35000 },
    ],
  },
  {
    code: "APU-04.02",
    name: "Pintura vinilo tipo 1 interior (2 manos sobre estuco)",
    unit: "M2",
    category: "04 ACABADOS",
    description: "Aplicación de dos manos de pintura vinilo lavable sobre superficie previamente estucada.",
    items: [
      { insumoCode: "MAT-010", description: "Pintura vinilo tipo 1 (0.07 gln/m2)", unit: "GLN", category: "MATERIAL", quantity: 0.07, wastePercentage: 5, unitPrice: 62000 },
      { insumoCode: "MO-003", description: "Cuadrilla pintor (Rendimiento 35 m2/jor)", unit: "JOR", category: "MANO_DE_OBRA", quantity: 0.0285, wastePercentage: 0, unitPrice: 185000 },
      { insumoCode: "EQ-005", description: "Herramienta menor y brochas", unit: "GLB", category: "EQUIPO", quantity: 263, wastePercentage: 0, unitPrice: 1 },
    ],
  },
  {
    code: "APU-05.01",
    name: "Punto hidráulico agua potable PVC 1/2 pulgada",
    unit: "UND",
    category: "05 HIDROSANITARIA",
    description: "Suministro e instalación de punto de agua potable en PVC presión 1/2 con accesorios y prueba hidrostática.",
    items: [
      { insumoCode: "MAT-016", description: "Tubería PVC presión 1/2 (2 metros)", unit: "TR", category: "MATERIAL", quantity: 0.33, wastePercentage: 5, unitPrice: 22000 },
      { insumoCode: "MO-005", description: "Cuadrilla plomero (Rendimiento 6 puntos/jor)", unit: "JOR", category: "MANO_DE_OBRA", quantity: 0.166, wastePercentage: 0, unitPrice: 205000 },
      { insumoCode: "EQ-005", description: "Herramienta menor", unit: "GLB", category: "EQUIPO", quantity: 1700, wastePercentage: 0, unitPrice: 1 },
    ],
  },
  {
    code: "APU-06.01",
    name: "Salida eléctrica tomacorriente doble con polo a tierra",
    unit: "UND",
    category: "06 ELÉCTRICO",
    description: "Salida eléctrica completa: tubería conduit, cableado THHN 12, caja 5800 y tomacorriente doble.",
    items: [
      { insumoCode: "MAT-018", description: "Cable THHN No. 12 (12 metros)", unit: "M", category: "MATERIAL", quantity: 12, wastePercentage: 7, unitPrice: 2400 },
      { insumoCode: "MAT-019", description: "Tomacorriente doble 15A", unit: "UND", category: "MATERIAL", quantity: 1, wastePercentage: 0, unitPrice: 14500 },
      { insumoCode: "MO-004", description: "Cuadrilla electricista (Rendimiento 7 salidas/jor)", unit: "JOR", category: "MANO_DE_OBRA", quantity: 0.142, wastePercentage: 0, unitPrice: 210000 },
      { insumoCode: "EQ-005", description: "Herramienta menor", unit: "GLB", category: "EQUIPO", quantity: 1490, wastePercentage: 0, unitPrice: 1 },
    ],
  },
];

/* ------------------------------------------------------------------ */
/* Banco de 50 APUs frecuentes en Colombia                             */
/* Los 10 anteriores tienen desglose detallado. Los siguientes son     */
/* plantillas de referencia PENDIENTES DE ACTUALIZAR por región/fecha. */
/* ------------------------------------------------------------------ */
const COMMON_APU_SPECS: [string, string, string, string, number][] = [
  ["APU-00.01", "Localización y replanteo de obra", "M2", "00 PRELIMINARES", 8500],
  ["APU-00.02", "Cerramiento provisional en polisombra h=2.10 m", "M", "00 PRELIMINARES", 52000],
  ["APU-00.03", "Campamento e instalaciones provisionales", "GLB", "00 PRELIMINARES", 4800000],
  ["APU-00.04", "Demolición manual de muro de mampostería", "M2", "00 PRELIMINARES", 28000],
  ["APU-00.05", "Retiro de escombros en volqueta", "M3", "00 PRELIMINARES", 95000],
  ["APU-01.10", "Excavación manual en material común", "M3", "01 MOVIMIENTO DE TIERRAS", 52000],
  ["APU-01.11", "Excavación mecánica en material común", "M3", "01 MOVIMIENTO DE TIERRAS", 24000],
  ["APU-01.12", "Relleno compactado con material seleccionado", "M3", "01 MOVIMIENTO DE TIERRAS", 128000],
  ["APU-01.13", "Subbase granular compactada", "M3", "01 MOVIMIENTO DE TIERRAS", 185000],
  ["APU-02.10", "Concreto pobre de limpieza 14 MPa", "M3", "02 ESTRUCTURA", 520000],
  ["APU-02.11", "Concreto 21 MPa para zapatas", "M3", "02 ESTRUCTURA", 790000],
  ["APU-02.12", "Concreto 21 MPa para losa maciza", "M3", "02 ESTRUCTURA", 860000],
  ["APU-02.13", "Concreto 21 MPa para escaleras", "M3", "02 ESTRUCTURA", 920000],
  ["APU-02.14", "Acero de refuerzo figurado 60.000 PSI", "KG", "02 ESTRUCTURA", 8200],
  ["APU-02.15", "Malla electrosoldada instalada", "KG", "02 ESTRUCTURA", 7600],
  ["APU-02.16", "Formaleta para columnas", "M2", "02 ESTRUCTURA", 98000],
  ["APU-02.17", "Formaleta para vigas", "M2", "02 ESTRUCTURA", 105000],
  ["APU-02.18", "Formaleta para losas", "M2", "02 ESTRUCTURA", 86000],
  ["APU-01.03", "Muro en ladrillo tolete común e=12 cm", "M2", "01 MAMPOSTERÍA", 112000],
  ["APU-01.04", "Muro en bloque estructural e=15 cm", "M2", "01 MAMPOSTERÍA", 126000],
  ["APU-04.03", "Estuco plástico sobre muro", "M2", "04 ACABADOS", 18500],
  ["APU-04.04", "Pintura exterior acrílica dos manos", "M2", "04 ACABADOS", 24500],
  ["APU-04.05", "Enchape cerámico en muro", "M2", "04 ACABADOS", 118000],
  ["APU-04.06", "Piso en porcelanato 60x60", "M2", "04 ACABADOS", 145000],
  ["APU-04.07", "Piso cerámico tráfico residencial", "M2", "04 ACABADOS", 98000],
  ["APU-04.08", "Guardaescoba en porcelanato", "M", "04 ACABADOS", 32000],
  ["APU-04.09", "Cielo raso en placa de yeso", "M2", "04 ACABADOS", 76000],
  ["APU-04.10", "Impermeabilización con manto asfáltico", "M2", "04 ACABADOS", 68000],
  ["APU-03.03", "Estructura metálica para cubierta", "KG", "03 CUBIERTAS Y MADERAS", 14500],
  ["APU-03.04", "Canal metálica galvanizada", "M", "03 CUBIERTAS Y MADERAS", 59000],
  ["APU-07.01", "Puerta metálica con marco y pintura", "UND", "07 CARPINTERÍA", 980000],
  ["APU-07.02", "Ventana de aluminio y vidrio 4 mm", "M2", "07 CARPINTERÍA", 620000],
  ["APU-07.03", "Baranda metálica h=1.00 m", "M", "07 CARPINTERÍA", 420000],
  ["APU-05.02", "Tubería PVC sanitaria 2 pulgadas instalada", "M", "05 HIDROSANITARIA", 52000],
  ["APU-05.03", "Tubería PVC sanitaria 4 pulgadas instalada", "M", "05 HIDROSANITARIA", 94000],
  ["APU-05.04", "Punto sanitario 4 pulgadas", "UND", "05 HIDROSANITARIA", 185000],
  ["APU-05.05", "Suministro e instalación de sanitario", "UND", "05 HIDROSANITARIA", 520000],
  ["APU-05.06", "Suministro e instalación de lavamanos", "UND", "05 HIDROSANITARIA", 430000],
  ["APU-06.02", "Salida de iluminación con interruptor", "UND", "06 ELÉCTRICO", 165000],
  ["APU-06.03", "Tablero eléctrico 12 circuitos", "UND", "06 ELÉCTRICO", 1450000],
];

const COMMON_APU_BANK: SeedApu[] = COMMON_APU_SPECS.map(([code, name, unit, category, cost]) => ({
  code,
  name,
  unit,
  category,
  description: "Plantilla del banco colombiano de APUs frecuentes. Debe validarse y actualizarse para la región y fecha del proyecto.",
  items: [{
    insumoCode: "",
    description: "Costo directo de referencia pendiente de desglosar/actualizar",
    unit,
    category: "SUBCONTRATO",
    quantity: 1,
    wastePercentage: 0,
    unitPrice: cost,
  }],
}));

const ALL_APUS: SeedApu[] = [...SEED_APUS, ...COMMON_APU_BANK];

export async function ensureBudgetMasterSeeded(): Promise<void> {
  /* Inserción idempotente: al ampliar el banco se agregan solo los faltantes. */
  const existingInsumoRows = await db.select().from(masterInsumos);
  const existingInsumoCodes = new Set(existingInsumoRows.map((i) => i.code));
  const missingInsumos = SEED_INSUMOS.filter((i) => !existingInsumoCodes.has(i.code));
  if (missingInsumos.length) {
    await db.insert(masterInsumos).values(
      missingInsumos.map((i) => ({
        code: i.code, name: i.name, unit: i.unit, category: i.category,
        unitPrice: i.unitPrice, currency: "COP", region: "COLOMBIA",
        supplier: i.supplier, source: i.source, active: true,
      }))
    );
  }

  const insumoRows = await db.select().from(masterInsumos);
  const insumoByCode = new Map(insumoRows.map((i) => [i.code, i]));
  const existingApuRows = await db.select().from(masterApus);
  const existingApuCodes = new Set(existingApuRows.map((a) => a.code));

  for (const apu of ALL_APUS) {
    if (existingApuCodes.has(apu.code)) continue;
    let unitCost = 0;
    const itemsToInsert: {
      insumoId: string | null; category: InsumoCategory; description: string;
      unit: string; quantity: number; wastePercentage: number;
      unitPrice: number; subtotal: number; sortOrder: number;
    }[] = [];

    for (let idx = 0; idx < apu.items.length; idx++) {
      const item = apu.items[idx];
      const insumo = insumoByCode.get(item.insumoCode);
      const price = item.unitPrice || insumo?.unitPrice || 0;
      const subtotal = Math.round(item.quantity * (1 + item.wastePercentage / 100) * price * 100) / 100;
      unitCost += subtotal;
      itemsToInsert.push({
        insumoId: insumo?.id ?? null, category: item.category,
        description: item.description, unit: item.unit, quantity: item.quantity,
        wastePercentage: item.wastePercentage, unitPrice: price, subtotal, sortOrder: idx,
      });
    }

    const [createdApu] = await db.insert(masterApus).values({
      code: apu.code,
      familyCode: apu.code,
      name: apu.name,
      unit: apu.unit,
      category: apu.category,
      description: apu.description,
      unitCost: Math.round(unitCost * 100) / 100,
      rendimientoJornal: 1,
      versionLabel: "BANCO-CO-2026",
      region: "COLOMBIA",
      currency: "COP",
      source: "BANCO_50_APU_COLOMBIA",
      priceStatus: "PENDIENTE_ACTUALIZAR",
      isPreferred: false,
      active: true,
    }).returning();

    if (itemsToInsert.length) {
      await db.insert(apuItems).values(itemsToInsert.map((it) => ({ apuId: createdApu.id, ...it })));
    }
  }
}
