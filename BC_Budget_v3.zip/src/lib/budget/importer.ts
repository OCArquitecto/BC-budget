/* ================================================================== */
/*  Importador & Motor de Revisiones .bcq para BIMCost Budget         */
/* ================================================================== */

import { db } from "@/db";
import {
  budgetProjects, budgetNodes, budgetItems, budgetRevisions, budgetDecisions,
  masterApus, type BudgetItemStatus, type QuantitySourceMeta, type CompanyInfo, type ProjectSettings,
} from "@/db/schema";
import { parseBcqPackage, type BcqPackage, type BcqStructureNode, type BcqQuantity } from "@/lib/bcq";
import { eq, and, inArray } from "drizzle-orm";
import { ensureBudgetMasterSeeded } from "./sample-data";

export interface ImportResult {
  projectId: string;
  projectCode: string;
  projectName: string;
  revision: string;
  packageId: string;
  isNewProject: boolean;
  isNewRevision: boolean;
  totalActivities: number;
  totalDirectCost: number;
  diff?: {
    activitiesAdded: { code: string; name: string; unit: string; quantity: number }[];
    activitiesModified: { code: string; name: string; unit: string; oldQuantity: number; newQuantity: number; diff: number }[];
    activitiesRemoved: { code: string; name: string }[];
    costDifference: number;
  };
}

export async function importBcqIntoBudget(
  fileBuffer: ArrayBuffer | Buffer,
  actor?: string | null
): Promise<ImportResult> {
  await ensureBudgetMasterSeeded();
  const pkg: BcqPackage = await parseBcqPackage(fileBuffer);
  const { manifest, project, structure, catalog, quantities, elements, sources } = pkg;

  // 1. Buscar si ya existe un proyecto presupuestal para este ID o Código
  const existingProjects = await db
    .select()
    .from(budgetProjects)
    .where(eq(budgetProjects.code, project.code))
    .limit(1);

  let targetProjectId: string;
  let isNewProject = false;
  let isNewRevision = false;
  let revisionNumber = 1;

  if (existingProjects.length > 0) {
    targetProjectId = existingProjects[0].id;
    // Actualizar metadata del proyecto
    await db
      .update(budgetProjects)
      .set({
        name: project.name,
        client: project.client || existingProjects[0].client,
        location: project.location || existingProjects[0].location,
        description: project.description || existingProjects[0].description,
        company: (project.company || existingProjects[0].company) as CompanyInfo,
        settings: (project.settings || existingProjects[0].settings) as ProjectSettings,
        sourceBcq: {
          packageId: manifest.packageId,
          projectId: project.id,
          projectCode: project.code,
          projectName: project.name,
          revision: manifest.revision,
          exportedAt: manifest.exportedAt,
          producerVersion: manifest.producer.version,
          totalQuantities: pkg.validatedQuantities.length,
          totalElements: elements.length,
          totalDecisions: pkg.decisions.length,
        },
        updatedAt: new Date(),
      })
      .where(eq(budgetProjects.id, targetProjectId));

    const pastRevs = await db
      .select()
      .from(budgetRevisions)
      .where(eq(budgetRevisions.projectId, targetProjectId));
    const alreadyImported = pastRevs.find((r) => r.packageId === manifest.packageId);
    if (alreadyImported) {
      const current = await db.select().from(budgetItems).where(eq(budgetItems.projectId, targetProjectId));
      const direct = Math.round(current.reduce((n, i) => n + (i.directCost || 0), 0) * 100) / 100;
      return {
        projectId: targetProjectId,
        projectCode: project.code,
        projectName: project.name,
        revision: alreadyImported.revisionName,
        packageId: manifest.packageId,
        isNewProject: false,
        isNewRevision: false,
        totalActivities: current.length,
        totalDirectCost: direct,
      };
    }
    revisionNumber = pastRevs.length + 1;
    const lastRev = pastRevs.sort((a, b) => b.revisionNumber - a.revisionNumber)[0];
    if (lastRev && lastRev.packageId !== manifest.packageId) isNewRevision = true;
  } else {
    isNewProject = true;
    isNewRevision = true;
    const [createdProject] = await db
      .insert(budgetProjects)
      .values({
        code: project.code,
        name: project.name,
        client: project.client ?? null,
        location: project.location ?? null,
        region: project.location ?? "COLOMBIA",
        priceDate: manifest.exportedAt ? new Date(manifest.exportedAt) : new Date(),
        description: project.description ?? null,
        currency: project.settings?.currency || "COP",
        status: "ACTIVO",
        sourceBcq: {
          packageId: manifest.packageId,
          projectId: project.id,
          projectCode: project.code,
          projectName: project.name,
          revision: manifest.revision,
          exportedAt: manifest.exportedAt,
          producerVersion: manifest.producer.version,
          totalQuantities: pkg.validatedQuantities.length,
          totalElements: elements.length,
          totalDecisions: pkg.decisions.length,
        },
        company: project.company ?? null,
        settings: (project.settings as ProjectSettings) ?? {
          administracion: 18,
          imprevistos: 3,
          utilidad: 5,
          iva: 19,
          ivaBases: ["UTILIDAD"],
          currency: "COP",
        },
      })
      .returning();
    targetProjectId = createdProject.id;
  }

  // 2. Consolidar cantidades validadas de BC Quantity por código de actividad
  // (Si hay múltiples cantidades o derivadas, se consolidan respetando el desglose)
  interface ConsolidatedAct {
    code: string;
    name: string;
    unit: string;
    totalQuantity: number;
    sources: string[];
    elementCount: number;
    elementGlobalIds: string[];
    lines: BcqQuantity[];
  }
  const consolidatedByCode = new Map<string, ConsolidatedAct>();

  for (const q of pkg.validatedQuantities) {
    const code = q.activityCode.trim();
    const cur = consolidatedByCode.get(code) ?? {
      code,
      name: q.activityName,
      unit: q.unit,
      totalQuantity: 0,
      sources: [],
      elementCount: 0,
      elementGlobalIds: [],
      lines: [],
    };
    cur.totalQuantity += q.value ?? 0;
    cur.elementCount += q.elementCount || 0;
    for (const gid of q.elementGlobalIds || []) {
      if (!cur.elementGlobalIds.includes(gid)) cur.elementGlobalIds.push(gid);
    }
    const srcName = q.sourceName || (q.sourceKind === "MANUAL" ? "Medición manual" : "IFC");
    if (!cur.sources.includes(srcName)) cur.sources.push(srcName);
    cur.lines.push(q);
    consolidatedByCode.set(code, cur);
  }

  // 3. Obtener APUs maestros para auto-sugerir a actividades nuevas
  const apuList = await db.select().from(masterApus);

  // Buscar coincidencia semántica en APUs (ej. por nombre o código)
  function findMatchingApu(actCode: string, actName: string, actUnit: string) {
    // Coincidencia exacta de código
    for (const a of apuList) {
      if (a.code.includes(actCode) || actCode.includes(a.code.replace("APU-", ""))) return a;
    }
    // Coincidencia por unidad y palabras clave
    const nName = actName.toLowerCase();
    for (const a of apuList) {
      if (a.unit.toUpperCase() === actUnit.toUpperCase()) {
        const aName = a.name.toLowerCase();
        if (
          (nName.includes("muro") && aName.includes("muro")) ||
          (nName.includes("columna") && aName.includes("columna")) ||
          (nName.includes("viga") && aName.includes("viga")) ||
          (nName.includes("pintura") && aName.includes("pintura")) ||
          (nName.includes("friso") && aName.includes("friso")) ||
          (nName.includes("tuberia") && aName.includes("tuberia"))
        ) {
          return a;
        }
      }
    }
    return null;
  }

  // 4. Procesar estructura jerárquica (WBS) de forma idempotente
  const existingNodes = await db
    .select()
    .from(budgetNodes)
    .where(eq(budgetNodes.projectId, targetProjectId));
  const nodeByCode = new Map(existingNodes.map((n) => [`${n.kind}:${n.code}`, n]));

  const existingItems = await db
    .select()
    .from(budgetItems)
    .where(eq(budgetItems.projectId, targetProjectId));
  const itemByActCode = new Map(existingItems.map((it) => [it.activityCode, it]));

  const diffSummary = {
    activitiesAdded: [] as { code: string; name: string; unit: string; quantity: number }[],
    activitiesModified: [] as { code: string; name: string; unit: string; oldQuantity: number; newQuantity: number; diff: number }[],
    activitiesRemoved: [] as { code: string; name: string }[],
    costDifference: 0,
  };

  // Crear o actualizar capítulos, subcapítulos y actividades
  for (const ch of structure) {
    let chapterNode = nodeByCode.get(`CAPITULO:${ch.code}`);
    if (!chapterNode) {
      const [created] = await db
        .insert(budgetNodes)
        .values({
          projectId: targetProjectId,
          parentId: null,
          kind: "CAPITULO",
          code: ch.code,
          name: ch.name,
          sortOrder: ch.sortOrder || 0,
        })
        .returning();
      chapterNode = created;
      nodeByCode.set(`CAPITULO:${ch.code}`, created);
    }

    for (const sec of ch.sections || []) {
      let secNode = nodeByCode.get(`SECCION:${sec.code}`);
      if (!secNode) {
        const [created] = await db
          .insert(budgetNodes)
          .values({
            projectId: targetProjectId,
            parentId: chapterNode.id,
            kind: "SECCION",
            code: sec.code,
            name: sec.name,
            sortOrder: sec.sortOrder || 0,
          })
          .returning();
        secNode = created;
        nodeByCode.set(`SECCION:${sec.code}`, created);
      }

      for (const act of sec.activities || []) {
        let actNode = nodeByCode.get(`ACTIVIDAD:${act.code}`);
        if (!actNode) {
          const [created] = await db
            .insert(budgetNodes)
            .values({
              projectId: targetProjectId,
              parentId: secNode.id,
              kind: "ACTIVIDAD",
              code: act.code,
              name: act.name,
              activityId: act.activityId || act.id,
              unit: act.unit,
              sortOrder: act.sortOrder || 0,
            })
            .returning();
          actNode = created;
          nodeByCode.set(`ACTIVIDAD:${act.code}`, created);
        }

        const cons = consolidatedByCode.get(act.code.trim());
        const newQty = cons ? Math.round(cons.totalQuantity * 1000) / 1000 : 0;
        const existingItem = itemByActCode.get(act.code.trim());

        const sourceMeta: QuantitySourceMeta = {
          sources: cons?.sources ?? [],
          elementCount: cons?.elementCount ?? 0,
          elementGlobalIds: cons?.elementGlobalIds ?? [],
          method: cons?.lines[0]?.method,
          rule: cons?.lines[0]?.rule ?? undefined,
          validatedBy: cons?.lines[0]?.validatedBy ?? undefined,
          validatedAt: cons?.lines[0]?.validatedAt ?? undefined,
          derivedFrom: cons?.lines[0]?.derivedFromId
            ? {
                activityCode: cons.lines[0].derivedParentCode ?? undefined,
                ruleApplied: cons.lines[0].rule ?? undefined,
              }
            : undefined,
        };

        if (existingItem) {
          // Ya existía: PRESERVAR su APU asignado y sus precios!
          const oldQty = existingItem.quantityBcq;
          const qtyChanged = Math.abs(oldQty - newQty) > 0.0001;

          if (qtyChanged) {
            diffSummary.activitiesModified.push({
              code: act.code,
              name: act.name,
              unit: act.unit || existingItem.unit,
              oldQuantity: oldQty,
              newQuantity: newQty,
              diff: Math.round((newQty - oldQty) * 1000) / 1000,
            });
          }

          const finalQuantity = existingItem.quantityOverride !== null ? existingItem.quantityOverride : newQty;
          const directCost = Math.round(finalQuantity * existingItem.unitCost * 100) / 100;
          const catalogActivity = catalog.find((c) => c.code === act.code);
          const referencePrice = catalogActivity?.referencePrice ?? existingItem.referenceUnitPrice ?? 0;
          const status: BudgetItemStatus = existingItem.apuId || existingItem.customApu
            ? (qtyChanged && isNewRevision ? "REVISION_PENDIENTE" : existingItem.quantityOverride !== null ? "CANTIDAD_MODIFICADA" : "APU_ASIGNADO")
            : referencePrice > 0 ? "PRECIO_IMPORTADO" : "SIN_APU";
          // Si todavía no hay APU, el costo visible parte del precio de catálogo
          // de Quantity, claramente marcado como referencia pendiente de validar.
          const effectiveUnitCost = existingItem.apuId || existingItem.customApu
            ? existingItem.unitCost
            : referencePrice;
          const updatedDirectCost = Math.round(finalQuantity * effectiveUnitCost * 100) / 100;

          await db
            .update(budgetItems)
            .set({
              activityName: act.name,
              unit: act.unit || existingItem.unit,
              quantityBcq: newQty,
              finalQuantity,
              referenceUnitPrice: referencePrice,
              referencePriceSource: referencePrice > 0 ? "CATALOGO_QUANTITY" : existingItem.referencePriceSource,
              priceReviewRequired: !(existingItem.apuId || existingItem.customApu),
              unitCost: effectiveUnitCost,
              directCost: updatedDirectCost,
              sourceMeta,
              status,
              updatedAt: new Date(),
            })
            .where(eq(budgetItems.id, existingItem.id));
        } else {
          // Actividad nueva
          diffSummary.activitiesAdded.push({
            code: act.code,
            name: act.name,
            unit: act.unit || "",
            quantity: newQty,
          });

          // El precio de Quantity se conserva como REFERENCIA. Budget no
          // asigna un APU por similitud sin decisión profesional.
          const catalogActivity = catalog.find((c) => c.code === act.code);
          const referencePrice = catalogActivity?.referencePrice || 0;
          const unitCost = referencePrice;
          const directCost = Math.round(newQty * unitCost * 100) / 100;

          await db.insert(budgetItems).values({
            projectId: targetProjectId,
            nodeId: actNode.id,
            activityCode: act.code,
            activityName: act.name,
            unit: act.unit || "UND",
            quantityBcq: newQty,
            finalQuantity: newQty,
            referenceUnitPrice: referencePrice,
            referencePriceSource: referencePrice > 0 ? "CATALOGO_QUANTITY" : null,
            priceReviewRequired: true,
            apuId: null,
            unitCost,
            directCost,
            sourceMeta,
            status: referencePrice > 0 ? "PRECIO_IMPORTADO" : "SIN_APU",
          });
        }
      }
    }
  }

  // 5. Detectar actividades que existían antes y ya no están en esta revisión
  const allCurrentCodes = new Set(structure.flatMap((ch) => ch.sections?.flatMap((s) => s.activities?.map((a) => a.code) || []) || []));
  for (const [code, item] of itemByActCode) {
    if (!allCurrentCodes.has(code)) {
      diffSummary.activitiesRemoved.push({ code, name: item.activityName });
    }
  }

  // 6. Recalcular total de costo directo del proyecto
  const currentItems = await db
    .select()
    .from(budgetItems)
    .where(eq(budgetItems.projectId, targetProjectId));
  const totalDirectCost = Math.round(currentItems.reduce((acc, it) => acc + (it.directCost || 0), 0) * 100) / 100;

  // 7. Guardar registro de la revisión
  await db.insert(budgetRevisions).values({
    projectId: targetProjectId,
    revisionNumber,
    revisionName: manifest.revision || `REV-${String(revisionNumber).padStart(2, "0")}`,
    packageId: manifest.packageId,
    summary: {
      packageId: manifest.packageId,
      revisionName: manifest.revision || `REV-${revisionNumber}`,
      totalActivities: currentItems.length,
      totalDirectCost,
      diffSummary: isNewRevision ? diffSummary : undefined,
    },
    snapshotData: {
      manifest, project, sources, catalog, structure,
      quantities, elements, decisions: pkg.decisions,
    },
    importedBy: actor || manifest.producer.name,
  });

  // 8. Registrar decisión de auditoría
  await db.insert(budgetDecisions).values({
    projectId: targetProjectId,
    entityType: "REVISION",
    entityId: manifest.packageId,
    action: isNewProject ? "CREO_PRESUPUESTO_DESDE_BCQ" : "IMPORTO_REVISION_BCQ",
    detail: {
      paqueteId: manifest.packageId,
      revision: manifest.revision,
      productor: manifest.producer,
      actividadesTotales: currentItems.length,
      costoDirecto: totalDirectCost,
      actividadesNuevas: diffSummary.activitiesAdded.length,
      actividadesModificadas: diffSummary.activitiesModified.length,
      actividadesRetiradas: diffSummary.activitiesRemoved.length,
    },
    actor: actor || manifest.producer.name,
  });

  return {
    projectId: targetProjectId,
    projectCode: project.code,
    projectName: project.name,
    revision: manifest.revision || "REV-01",
    packageId: manifest.packageId,
    isNewProject,
    isNewRevision,
    totalActivities: currentItems.length,
    totalDirectCost,
    diff: isNewRevision ? diffSummary : undefined,
  };
}
