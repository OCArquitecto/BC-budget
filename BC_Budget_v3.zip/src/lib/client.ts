/* ================================================================== */
/*  Helpers compartidos (cliente)                                      */
/* ================================================================== */

export function fmt(n: number | null | undefined, digits = 2): string {
  if (n === null || n === undefined || !isFinite(n)) return "—";
  return n.toLocaleString("es-ES", { minimumFractionDigits: 0, maximumFractionDigits: digits });
}

export const STATUS_META: Record<string, { label: string; cls: string; dot: string }> = {
  PENDIENTE: { label: "Pendiente", cls: "border-amber-400/40 bg-amber-400/10 text-amber-300", dot: "bg-amber-400" },
  PROPUESTA: { label: "Propuesta", cls: "border-sky-400/40 bg-sky-400/10 text-sky-300", dot: "bg-sky-400" },
  VALIDADA: { label: "Validada", cls: "border-emerald-400/40 bg-emerald-400/10 text-emerald-300", dot: "bg-emerald-400" },
  RECHAZADA: { label: "Rechazada", cls: "border-rose-400/40 bg-rose-400/10 text-rose-300", dot: "bg-rose-400" },
};

export const METHOD_META: Record<string, { label: string; short: string }> = {
  SUPERFICIE_GEOMETRICA: { label: "Superficie geométrica", short: "Área" },
  VOLUMEN_GEOMETRICO: { label: "Volumen geométrico", short: "Vol" },
  DIMENSION: { label: "Dimensión (longitud)", short: "Long" },
  COUNT: { label: "Conteo", short: "Conteo" },
  CANTIDAD_IFC: { label: "Cantidad IFC", short: "IFC" },
  COMPONENTES: { label: "Componentes", short: "Comp" },
  MANUAL: { label: "Medición manual", short: "Manual" },
};

export const KIND_META: Record<string, { label: string; cls: string }> = {
  IFC: { label: "IFC", cls: "border-cyan-400/40 bg-cyan-400/10 text-cyan-300" },
  EXCEL: { label: "Excel", cls: "border-emerald-400/40 bg-emerald-400/10 text-emerald-300" },
  MANUAL: { label: "Manual", cls: "border-violet-400/40 bg-violet-400/10 text-violet-300" },
  TEMPLATE: { label: "Plantilla", cls: "border-slate-400/40 bg-slate-400/10 text-slate-300" },
};

export async function api<T = unknown>(url: string, init?: RequestInit): Promise<T> {
  const res = await fetch(url, init);
  const data = (await res.json().catch(() => ({}))) as T & { error?: string };
  if (!res.ok) throw new Error(data.error || `Error ${res.status}`);
  return data;
}

export function nuevaFecha(iso: string | Date | null | undefined): string {
  if (!iso) return "—";
  const d = new Date(iso);
  return d.toLocaleString("es-ES", { day: "2-digit", month: "short", year: "numeric", hour: "2-digit", minute: "2-digit" });
}
