"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import {
  Plus, BookMarked, Power, PowerOff, Copy, Search, ChevronDown,
  ChevronRight, CircleDollarSign, Pencil, FileSpreadsheet, Layers,
} from "lucide-react";
import { Nav } from "@/components/Nav";
import {
  Alert, Btn, Card, Chip, Field, Input, Modal, SectionTitle, Select, Spinner, cx,
} from "@/components/ui";
import { api, METHOD_META, fmt } from "@/lib/client";
import { ActivityForm, type CatalogActivityFull } from "@/components/workspace/ActivityForm";
import { CatalogImport } from "@/components/workspace/CatalogImport";

interface Activity extends CatalogActivityFull {
  priceSource: string | null;
  origin: string;
  scopeActive: boolean;
}
interface Section { code: string; name: string; active: boolean; total: number; activities: Activity[] }
interface Chapter { code: string; name: string; active: boolean; total: number; sections: Section[] }
interface GroupRow { id: string; kind: string; code: string; name: string; parentCode: string | null; active: boolean; actividades: number }

export default function CatalogoPage() {
  const [tree, setTree] = useState<Chapter[] | null>(null);
  const [total, setTotal] = useState(0);
  const [shown, setShown] = useState(0);
  const [capitulos, setCapitulos] = useState<GroupRow[]>([]);
  const [q, setQ] = useState("");
  const [chapterFilter, setChapterFilter] = useState("");
  const [open, setOpen] = useState<Record<string, boolean>>({});
  const [showAdd, setShowAdd] = useState(false);
  const [duplicate, setDuplicate] = useState<Activity | null>(null);
  const [showImport, setShowImport] = useState(false);
  const [editPrice, setEditPrice] = useState<Activity | null>(null);
  const [priceValue, setPriceValue] = useState("");
  const [notice, setNotice] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const timer = useRef<ReturnType<typeof setTimeout> | null>(null);

  const load = useCallback(async (needle = q, chapter = chapterFilter) => {
    const p = new URLSearchParams({ limit: "300" });
    if (needle) p.set("q", needle);
    if (chapter) p.set("chapter", chapter);
    const d = await api<{ tree: Chapter[]; total: number; flat: Activity[]; capitulos: GroupRow[] }>(`/api/catalog?${p}`);
    setTree(d.tree);
    setTotal(d.total);
    setShown(d.flat.length);
    setCapitulos(d.capitulos);
  }, [q, chapterFilter]);

  useEffect(() => { load(""); /* primera carga */ }, [load]);

  const onSearch = (v: string) => {
    setQ(v);
    if (timer.current) clearTimeout(timer.current);
    timer.current = setTimeout(() => load(v, chapterFilter), 250);
  };

  const toggleGroup = async (kind: "CAPITULO" | "SECCION", code: string, active: boolean) => {
    await api("/api/catalog/groups", {
      method: "PATCH", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ kind, code, active }),
    });
    setNotice(active
      ? `${kind === "CAPITULO" ? "Capítulo" : "Sección"} ${code} reactivado: vuelve a participar en las propuestas.`
      : `${kind === "CAPITULO" ? "Capítulo" : "Sección"} ${code} apagado: sus actividades no se propondrán automáticamente (no se borró nada).`);
    load();
  };

  const toggleActivity = async (a: Activity) => {
    await api("/api/catalog", {
      method: "PATCH", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ id: a.id, active: !a.active }),
    });
    load();
  };

  const savePrice = async () => {
    if (!editPrice) return;
    await api("/api/catalog", {
      method: "PATCH", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ id: editPrice.id, unitPrice: Number(priceValue.replace(/[^\d,.-]/g, "").replace(",", ".")) || 0 }),
    });
    setEditPrice(null);
    load();
  };

  return (
    <div className="min-h-screen">
      <Nav />
      <div className="mx-auto max-w-[1500px] px-4 py-8 sm:px-6">
        <SectionTitle
          title="Catálogo maestro de actividades"
          desc={`Base reutilizable de la empresa · ${total} actividades · define qué existe, cómo se mide y su precio de referencia`}
          right={
            <div className="flex flex-wrap gap-2">
              <Btn icon={FileSpreadsheet} onClick={() => setShowImport(true)}>Importar catálogo / precios</Btn>
              <Btn variant="primary" icon={Plus} onClick={() => { setDuplicate(null); setShowAdd(true); }}>Nueva actividad</Btn>
            </div>
          }
        />

        {notice && <Alert tone="ok">{notice}</Alert>}
        {error && <Alert tone="error">{error}</Alert>}

        <div className="my-4 flex flex-wrap items-center gap-2">
          <div className="relative w-96 max-w-full">
            <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-fog" />
            <Input value={q} onChange={(e) => onSearch(e.target.value)} placeholder="Buscar por código, nombre, capítulo…" className="pl-8" />
          </div>
          <Select value={chapterFilter} onChange={(e) => { setChapterFilter(e.target.value); load(q, e.target.value); }} className="w-64">
            <option value="">Todos los capítulos</option>
            {capitulos.map((c) => (
              <option key={c.id} value={c.code}>{c.code} · {c.name} ({c.actividades}){c.active ? "" : " — apagado"}</option>
            ))}
          </Select>
          <Chip className="border-line bg-ink-750 text-mist">Mostrando {shown} de {total}</Chip>
        </div>

        <Alert tone="info">
          <div className="flex items-start gap-2">
            <BookMarked size={14} className="mt-0.5 shrink-0" />
            <span>
              Puede <strong>apagar capítulos, secciones o actividades completas</strong>: dejan de proponerse automáticamente
              sin borrarse. Las clases IFC de cada actividad determinan con qué elementos BIM puede corresponder
              (un IfcWall solo se propone para actividades de muro).
            </span>
          </div>
        </Alert>

        {tree === null ? (
          <Spinner label="Cargando catálogo…" />
        ) : (
          <div className="mt-5 space-y-4">
            {tree.map((ch) => {
              const isOpen = open[ch.code] !== false;
              return (
                <Card key={ch.code} className={cx("overflow-hidden", !ch.active && "opacity-60")}>
                  <div className="flex items-center gap-3 border-b border-line bg-ink-800/60 px-4 py-3">
                    <button onClick={() => setOpen({ ...open, [ch.code]: !isOpen })} className="text-fog hover:text-acc">
                      {isOpen ? <ChevronDown size={15} /> : <ChevronRight size={15} />}
                    </button>
                    <span className="font-mono text-sm font-bold text-acc">{ch.code}</span>
                    <span className={cx("text-sm font-bold tracking-wide", ch.active ? "text-white" : "text-fog line-through")}>{ch.name}</span>
                    <Chip className="border-line bg-ink-750 text-mist">{ch.total} actividades</Chip>
                    <button onClick={() => toggleGroup("CAPITULO", ch.code, !ch.active)}
                      title={ch.active ? "Apagar capítulo completo" : "Reactivar capítulo"}
                      className={cx("ml-auto flex items-center gap-1.5 rounded-lg border px-2.5 py-1 text-[11px] font-semibold transition-colors",
                        ch.active ? "border-emerald-400/30 bg-emerald-400/10 text-emerald-300 hover:bg-emerald-400/20"
                          : "border-line bg-ink-800 text-fog hover:text-white")}>
                      {ch.active ? <><Power size={12} /> Activo</> : <><PowerOff size={12} /> Apagado</>}
                    </button>
                  </div>

                  {isOpen && ch.sections.map((s) => (
                    <div key={s.code} className={cx("border-b border-line/60 last:border-0", !s.active && "opacity-60")}>
                      <div className="flex items-center gap-2 bg-ink-850 px-4 py-2 pl-10">
                        <Layers size={11} className="text-fog" />
                        <span className="font-mono text-[11px] font-semibold text-mist">{s.code}</span>
                        <span className={cx("text-xs font-semibold", s.active ? "text-slate-300" : "text-fog line-through")}>{s.name}</span>
                        <Chip className="border-line bg-ink-800 text-fog">{s.total}</Chip>
                        <button onClick={() => toggleGroup("SECCION", s.code, !s.active)}
                          className={cx("ml-auto rounded-md border px-2 py-0.5 text-[10px] font-semibold transition-colors",
                            s.active ? "border-emerald-400/25 bg-emerald-400/5 text-emerald-300" : "border-line bg-ink-800 text-fog")}>
                          {s.active ? "Sección activa" : "Sección apagada"}
                        </button>
                      </div>

                      <table className="w-full text-left text-xs">
                        <tbody>
                          {s.activities.map((a) => (
                            <tr key={a.id} className={cx("border-t border-line/40 transition-colors hover:bg-ink-800/60", !a.active && "opacity-40")}>
                              <td className="w-28 px-4 py-2.5 pl-12 font-mono font-semibold text-slate-300">{a.code}</td>
                              <td className="px-2 py-2.5">
                                <p className="font-medium text-slate-100">{a.name}</p>
                                <div className="mt-1 flex flex-wrap gap-1">
                                  {a.ifcClasses.slice(0, 5).map((c) => (
                                    <Chip key={c} className="border-cyan-400/25 bg-cyan-400/5 font-mono text-cyan-300">{c.replace(/^IFC/, "Ifc")}</Chip>
                                  ))}
                                  {a.keywords.slice(0, 5).map((k) => <Chip key={k}>{k}</Chip>)}
                                  {a.origin === "LISTADO_PRECIOS" && <Chip className="border-emerald-400/25 bg-emerald-400/5 text-emerald-300">importada</Chip>}
                                </div>
                              </td>
                              <td className="w-16 px-2 py-2.5 text-center">
                                <Chip className="border-line-strong bg-ink-750 font-mono text-slate-200">{a.unit}</Chip>
                              </td>
                              <td className="w-36 px-2 py-2.5">
                                <Chip className="border-violet-400/30 bg-violet-400/10 text-violet-300">
                                  {METHOD_META[a.method]?.label ?? a.method}
                                </Chip>
                              </td>
                              <td className="w-32 px-2 py-2.5 text-right">
                                <button onClick={() => { setEditPrice(a); setPriceValue(String(a.unitPrice ?? 0)); }}
                                  className="group inline-flex items-center gap-1 font-mono text-[11px] tabular-nums text-slate-300 hover:text-acc"
                                  title={a.priceSource ?? "Editar precio unitario"}>
                                  {a.unitPrice > 0 ? <>$ {fmt(a.unitPrice, 0)}</> : <span className="text-amber-300">sin precio</span>}
                                  <Pencil size={10} className="opacity-0 transition-opacity group-hover:opacity-100" />
                                </button>
                              </td>
                              <td className="w-24 px-3 py-2.5">
                                <div className="flex items-center justify-end gap-1">
                                  <button onClick={() => { setDuplicate(a); setShowAdd(true); }} title="Duplicar actividad"
                                    className="rounded-md p-1.5 text-fog transition-colors hover:bg-ink-700 hover:text-acc">
                                    <Copy size={13} />
                                  </button>
                                  <button onClick={() => toggleActivity(a)} title={a.active ? "Desactivar" : "Activar"}
                                    className={cx("rounded-md p-1.5 transition-colors",
                                      a.active ? "text-emerald-400 hover:bg-emerald-400/10" : "text-fog hover:bg-ink-700")}>
                                    <Power size={13} />
                                  </button>
                                </div>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  ))}
                </Card>
              );
            })}
            {tree.length === 0 && total === 0 && !q && (
              <Card className="px-6 py-12 text-center">
                <BookMarked size={26} className="mx-auto text-acc" />
                <p className="mt-3 text-sm font-bold text-white">El catálogo maestro está vacío</p>
                <p className="mx-auto mt-1 max-w-xl text-xs leading-relaxed text-mist">
                  BIMCost Quantity se instala <strong>sin actividades ni precios internos</strong>: el catálogo es de su
                  empresa. Impórtelo desde su Excel indicando qué columna corresponde a código, descripción, unidad y
                  valor unitario, o cree las actividades una a una.
                </p>
                <div className="mt-4 flex flex-wrap justify-center gap-2">
                  <Btn variant="primary" icon={FileSpreadsheet} onClick={() => setShowImport(true)}>
                    Importar catálogo desde Excel
                  </Btn>
                  <Btn icon={Plus} onClick={() => { setDuplicate(null); setShowAdd(true); }}>Crear actividad manualmente</Btn>
                </div>
              </Card>
            )}
            {tree.length === 0 && (total > 0 || q) && (
              <Card className="p-10 text-center text-sm text-mist">Sin resultados para «{q}».</Card>
            )}
          </div>
        )}
      </div>

      {/* Crear / duplicar */}
      <Modal open={showAdd} onClose={() => { setShowAdd(false); setDuplicate(null); }}
        title={duplicate ? `Duplicar actividad ${duplicate.code}` : "Nueva actividad del catálogo maestro"} wide>
        <ActivityForm
          duplicateFrom={duplicate}
          onCancel={() => { setShowAdd(false); setDuplicate(null); }}
          onCreated={(a) => {
            setShowAdd(false); setDuplicate(null);
            setNotice(`Actividad ${a.code} creada en el catálogo maestro.`);
            load();
          }}
        />
      </Modal>

      {/* Importar catálogo / listado de precios */}
      <Modal open={showImport} onClose={() => setShowImport(false)} title="Importar catálogo o listado de precios" wide>
        <CatalogImport onDone={() => load()} />
      </Modal>

      {/* Editar precio */}
      <Modal open={!!editPrice} onClose={() => setEditPrice(null)} title="Precio unitario de referencia">
        {editPrice && (
          <div className="space-y-3">
            <p className="text-xs text-mist">
              <span className="font-mono text-acc">{editPrice.code}</span> — {editPrice.name} ({editPrice.unit})
            </p>
            <Field label="Valor unitario" hint={editPrice.priceSource ?? "Referencia para el presupuesto preliminar; BC Budget puede actualizarlo"}>
              <Input value={priceValue} onChange={(e) => setPriceValue(e.target.value)} className="font-mono" inputMode="decimal" autoFocus />
            </Field>
            <div className="flex justify-end gap-2">
              <Btn onClick={() => setEditPrice(null)}>Cancelar</Btn>
              <Btn variant="primary" icon={CircleDollarSign} onClick={savePrice}>Guardar precio</Btn>
            </div>
          </div>
        )}
      </Modal>
    </div>
  );
}
