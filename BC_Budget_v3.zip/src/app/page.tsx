"use client";

import { useEffect, useState, useRef } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import {
  Calculator, Coins, Upload, Plus, FileText, ArrowRight, Sparkles,
  GitCompare, ShieldCheck, Layers, FileBox, RefreshCw, CheckCircle2,
  PieChart, Building2, AlertCircle, FileSpreadsheet, Download
} from "lucide-react";
import { Nav } from "@/components/Nav";
import { Btn, Card, Chip, Modal, Input, Field, Textarea, Spinner, Empty, Alert, cx } from "@/components/ui";
import { api, fmt } from "@/lib/client";

interface BudgetProjectRow {
  id: string;
  code: string;
  name: string;
  client: string | null;
  location: string | null;
  currency: string;
  status: string;
  sourceBcq: {
    packageId?: string;
    revision?: string;
    exportedAt?: string;
    totalQuantities?: number;
  } | null;
  stats: {
    totalActivities: number;
    withApu: number;
    withoutApu: number;
    pendingPriceReview: number;
    pendingRevision: number;
    revisionsCount: number;
    totalDirectCost: number;
    totalBudget: number;
  };
  updatedAt: string;
}

const BUDGET_PIPELINE = [
  { icon: FileBox, label: "PAQUETE .BCQ", desc: "Cantidades validadas con evidencia de BC Quantity" },
  { icon: Calculator, label: "ANÁLISIS APU", desc: "Materiales, mano de obra, equipos y rendimientos" },
  { icon: Coins, label: "EXPLOSIÓN", desc: "Consolidación total de insumos del proyecto" },
  { icon: PieChart, label: "AIU & IVA", desc: "Administración, imprevistos y utilidad configurable" },
  { icon: GitCompare, label: "REVISIONES", desc: "Comparativo de cambios entre revisiones .bcq" },
  { icon: FileText, label: "PRESUPUESTO", desc: "Presupuesto ejecutivo y oferta económica" },
];

export default function BudgetDashboard() {
  const router = useRouter();
  const [projects, setProjects] = useState<BudgetProjectRow[] | null>(null);
  const [showNew, setShowNew] = useState(false);
  const [showImport, setShowImport] = useState(false);
  const [busy, setBusy] = useState(false);
  const [demoBusy, setDemoBusy] = useState(false);
  const [diffResult, setDiffResult] = useState<any>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const fileRef = useRef<HTMLInputElement>(null);

  const [form, setForm] = useState({ code: "", name: "", client: "", location: "", description: "", currency: "COP" });

  const load = () =>
    api<{ projects: BudgetProjectRow[] }>("/api/budget/projects").then((d) => setProjects(d.projects));

  useEffect(() => {
    load().catch(() => setProjects([]));
  }, []);

  const createManual = async () => {
    if (!form.code.trim() || !form.name.trim()) {
      setError("Código y nombre son obligatorios.");
      return;
    }
    setBusy(true);
    setError(null);
    try {
      const d = await api<{ project: { id: string } }>("/api/budget/projects", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      });
      router.push(`/presupuestos/${d.project.id}`);
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setBusy(false);
    }
  };

  const handleImportBcq = async () => {
    const file = fileRef.current?.files?.[0];
    if (!file) {
      setError("Seleccione un archivo .bcq");
      return;
    }
    setBusy(true);
    setError(null);
    try {
      const fd = new FormData();
      fd.append("file", file);
      fd.append("actor", "Presupuestador");

      const res = await fetch("/api/budget/import-bcq", {
        method: "POST",
        body: fd,
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Error al importar paquete .bcq");

      setNotice(`Paquete .bcq importado: Proyecto ${data.projectCode} (${data.revision}) · ${data.totalActivities} actividades procesadas.`);
      setShowImport(false);
      if (data.diff && (data.diff.activitiesAdded.length || data.diff.activitiesModified.length || data.diff.activitiesRemoved.length)) {
        setDiffResult(data.diff);
      } else {
        router.push(`/presupuestos/${data.projectId}`);
      }
      load();
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setBusy(false);
    }
  };

  const loadDemoBcq = async (revision: "REV-01" | "REV-02") => {
    setDemoBusy(true);
    setError(null);
    try {
      const data = await api<any>("/api/budget/import-bcq", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ sample: "CASA_SARA", revision, actor: "Presupuestos Demo" }),
      });

      setNotice(`Muestra Casa Sara (${revision}) cargada con éxito.`);
      if (data.diff && (data.diff.activitiesAdded?.length || data.diff.activitiesModified?.length || data.diff.activitiesRemoved?.length)) {
        setDiffResult(data.diff);
      } else {
        router.push(`/presupuestos/${data.projectId}`);
      }
      load();
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setDemoBusy(false);
    }
  };

  const money = (n: number) => `$ ${fmt(n, 0)}`;

  return (
    <div className="min-h-screen pb-20">
      <Nav />

      {/* HERO BUDGET */}
      <section className="bc-grid-bg border-b border-line">
        <div className="mx-auto max-w-[1540px] px-4 py-12 sm:px-6 sm:py-16">
          <div className="max-w-3xl bc-fade-up">
            <div className="mb-4 inline-flex items-center gap-2 rounded-lg border border-emerald-400/40 bg-emerald-400/10 px-3 py-1 text-xs font-bold text-emerald-400">
              <Coins size={14} /> Ecosistema BIMCost · Módulo de Costos y APUs
            </div>
            <h1 className="text-4xl font-black leading-[1.05] tracking-tight text-white sm:text-5xl">
              De cantidades validadas a{" "}
              <span className="bg-gradient-to-r from-emerald-400 to-teal-300 bg-clip-text text-transparent">
                costos reales de construcción
              </span>
            </h1>
            <p className="mt-4 max-w-2xl text-sm leading-relaxed text-mist sm:text-base">
              <strong>BIMCost Budget</strong> es el sistema especializado de presupuestación que transforma paquetes{" "}
              <code className="rounded bg-ink-800 px-1.5 py-0.5 font-mono text-emerald-400">.bcq</code> en análisis de precios unitarios (APUs),
              explosión de insumos, gestión de AIU y comparación automática entre revisiones.
            </p>

            <div className="mt-6 flex flex-wrap items-center gap-3">
              <Btn variant="primary" icon={Upload} onClick={() => setShowImport(true)} className="bg-emerald-500 text-slate-950 font-bold hover:bg-emerald-400">
                Importar paquete .bcq
              </Btn>
              <Btn icon={Sparkles} loading={demoBusy} onClick={() => loadDemoBcq("REV-01")}>
                Cargar muestra Casa Sara (REV-01)
              </Btn>
              <Link href="/apus">
                <Btn icon={Calculator}>Catálogo de APUs</Btn>
              </Link>
            </div>
          </div>

          {/* PIPELINE */}
          <div className="mt-12 grid grid-cols-2 gap-2.5 sm:grid-cols-3 lg:grid-cols-6">
            {BUDGET_PIPELINE.map((p, i) => (
              <div
                key={p.label}
                className="relative rounded-xl border border-line bg-ink-850/80 p-3.5 backdrop-blur transition-all duration-200 hover:border-emerald-400/40 hover:bg-ink-800"
              >
                <div className="flex items-center gap-2">
                  <span className="font-mono text-[10px] font-bold text-emerald-400">0{i + 1}</span>
                  <p.icon size={15} className="text-emerald-400" />
                  <span className="text-[11px] font-bold tracking-wide text-slate-200">{p.label}</span>
                </div>
                <p className="mt-2 text-[10.5px] leading-snug text-fog">{p.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CONTENIDO PRINCIPAL */}
      <section className="mx-auto max-w-[1540px] px-4 py-10 sm:px-6">
        {notice && (
          <div className="mb-6">
            <Alert tone="ok">{notice}</Alert>
          </div>
        )}

        <div className="mb-6 flex flex-wrap items-center justify-between gap-4">
          <div>
            <h2 className="text-xl font-extrabold text-white">Proyectos Presupuestales</h2>
            <p className="text-xs text-mist">
              Presupuestos estructurados vinculados a sus paquetes nativos <span className="font-mono text-emerald-400">.bcq</span>
            </p>
          </div>
          <div className="flex items-center gap-2">
            <Btn size="sm" icon={Upload} onClick={() => setShowImport(true)}>
              Importar .bcq
            </Btn>
            <Btn size="sm" icon={Plus} onClick={() => setShowNew(true)}>
              Nuevo presupuesto manual
            </Btn>
          </div>
        </div>

        {projects === null ? (
          <Spinner label="Cargando presupuestos…" />
        ) : projects.length === 0 ? (
          <Empty
            icon={Calculator}
            title="Aún no hay presupuestos en BC Budget"
            hint="Importe un archivo .bcq exportado desde BIMCost Quantity o pruebe la muestra Casa Sara con APUs automáticos."
            action={
              <div className="flex flex-wrap justify-center gap-3">
                <Btn variant="primary" icon={Upload} onClick={() => setShowImport(true)}>
                  Importar paquete .bcq
                </Btn>
                <Btn icon={Sparkles} onClick={() => loadDemoBcq("REV-01")}>
                  Probar muestra Casa Sara
                </Btn>
              </div>
            }
          />
        ) : (
          <div className="grid gap-5 md:grid-cols-2 xl:grid-cols-3">
            {projects.map((p) => {
              const hasUnassigned = p.stats.withoutApu > 0;
              const hasRevisionPending = p.stats.pendingRevision > 0;

              return (
                <Link key={p.id} href={`/presupuestos/${p.id}`} className="group block">
                  <Card className="flex h-full flex-col justify-between p-5 transition-all duration-200 hover:border-emerald-400/50 hover:shadow-[0_8px_30px_rgba(16,185,129,0.15)]">
                    <div>
                      {/* ENCABEZADO DE TARJETA */}
                      <div className="flex items-start justify-between gap-3">
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="font-mono text-xs font-bold text-emerald-400">{p.code}</span>
                            {p.sourceBcq?.revision && (
                              <Chip className="border-emerald-400/30 bg-emerald-400/10 font-mono text-emerald-300">
                                {p.sourceBcq.revision}
                              </Chip>
                            )}
                          </div>
                          <h3 className="mt-1 text-base font-extrabold text-white transition-colors group-hover:text-emerald-400">
                            {p.name}
                          </h3>
                          <p className="text-xs text-mist">
                            {p.client || "Sin cliente"} · {p.location || "Ubicación no especificada"}
                          </p>
                        </div>
                      </div>

                      {/* ESTADO / ALERTAS */}
                      <div className="mt-3 flex flex-wrap gap-1.5">
                        {hasUnassigned ? (
                          <Chip className="border-amber-400/40 bg-amber-400/10 text-amber-300">
                            <AlertCircle size={11} /> {p.stats.withoutApu} sin APU
                          </Chip>
                        ) : (
                          <Chip className="border-emerald-400/30 bg-emerald-400/10 text-emerald-300">
                            <CheckCircle2 size={11} /> 100% APUs Asignados
                          </Chip>
                        )}
                        {p.stats.pendingPriceReview > 0 && (
                          <Chip className="border-sky-400/40 bg-sky-400/10 text-sky-300">
                            {p.stats.pendingPriceReview} PU Quantity por actualizar
                          </Chip>
                        )}
                        {hasRevisionPending && (
                          <Chip className="border-sky-400/40 bg-sky-400/10 text-sky-300">
                            <RefreshCw size={11} /> Revisión pendiente
                          </Chip>
                        )}
                        {p.stats.revisionsCount > 1 && (
                          <Chip className="border-line bg-ink-750 font-mono text-mist">
                            {p.stats.revisionsCount} revisiones .bcq
                          </Chip>
                        )}
                      </div>

                      {/* CIFRAS FINANCIERAS */}
                      <div className="mt-5 grid grid-cols-2 gap-3 rounded-xl border border-line bg-ink-800/60 p-3.5">
                        <div>
                          <p className="text-[10px] font-bold uppercase tracking-wider text-fog">Costo Directo</p>
                          <p className="mt-0.5 font-mono text-base font-black text-slate-100">
                            {money(p.stats.totalDirectCost)}
                          </p>
                          <p className="text-[10px] text-fog">{p.stats.totalActivities} actividades</p>
                        </div>
                        <div className="border-l border-line pl-3">
                          <p className="text-[10px] font-bold uppercase tracking-wider text-emerald-400">Presupuesto c/ AIU</p>
                          <p className="mt-0.5 font-mono text-base font-black text-emerald-400">
                            {money(p.stats.totalBudget)}
                          </p>
                          <p className="text-[10px] text-fog">{p.currency}</p>
                        </div>
                      </div>
                    </div>

                    <div className="mt-4 flex items-center justify-between border-t border-line/60 pt-3 text-[11.5px] font-semibold text-emerald-400">
                      <span>Ver estructura y APUs</span>
                      <ArrowRight size={14} className="transition-transform group-hover:translate-x-1" />
                    </div>
                  </Card>
                </Link>
              );
            })}
          </div>
        )}
      </section>

      {/* MODAL: IMPORTAR PAQUETE .BCQ */}
      <Modal open={showImport} onClose={() => setShowImport(false)} title="Importar paquete de cantidades (.bcq)" wide>
        <div className="space-y-4">
          <Alert tone="info">
            Seleccione el archivo <strong className="font-mono">.bcq</strong> exportado desde <strong>BIMCost Quantity</strong>.
            Budget conservará la trazabilidad completa (fuentes, elementos, reglas de medición y decisiones).
          </Alert>

          {error && <Alert tone="error">{error}</Alert>}

          <Field label="Archivo BIMCost Quantity Package (.bcq)">
            <Input ref={fileRef} type="file" accept=".bcq,.zip" className="py-2 text-xs" />
          </Field>

          <div className="rounded-xl border border-line bg-ink-800/50 p-4">
            <p className="text-xs font-bold text-slate-200">¿Qué hace BC Budget al importar?</p>
            <ul className="mt-2 space-y-1.5 text-xs text-mist">
              <li className="flex items-center gap-2">
                <CheckCircle2 size={13} className="text-emerald-400" />
                <span>Estructura los capítulos, subcapítulos y actividades validadas del proyecto.</span>
              </li>
              <li className="flex items-center gap-2">
                <CheckCircle2 size={13} className="text-emerald-400" />
                <span>Asigna automáticamente APUs maestros sugeridos según la compatibilidad de actividad y unidad.</span>
              </li>
              <li className="flex items-center gap-2">
                <CheckCircle2 size={13} className="text-emerald-400" />
                <span>Si el proyecto ya existía, detecta diferencias de cantidades entre revisiones conservando sus APUs y precios.</span>
              </li>
            </ul>
          </div>

          <div className="flex justify-end gap-2 pt-2">
            <Btn onClick={() => setShowImport(false)}>Cancelar</Btn>
            <Btn variant="primary" icon={Upload} loading={busy} onClick={handleImportBcq}>
              Importar paquete
            </Btn>
          </div>
        </div>
      </Modal>

      {/* MODAL: DIFF DE REVISIÓN */}
      <Modal open={!!diffResult} onClose={() => setDiffResult(null)} title="Revisión .bcq actualizada — Comparativo de cambios" wide>
        {diffResult && (
          <div className="space-y-4">
            <Alert tone="ok">
              La revisión fue procesada. Sus APUs asignados y precios personalizados fueron preservados intactos.
            </Alert>

            {diffResult.activitiesModified?.length > 0 && (
              <div>
                <p className="mb-1.5 text-xs font-bold uppercase tracking-wider text-amber-300">
                  Actividades con cantidades modificadas ({diffResult.activitiesModified.length})
                </p>
                <div className="max-h-52 overflow-auto rounded-lg border border-line">
                  <table className="w-full text-left text-xs">
                    <thead className="bg-ink-800 text-[10px] uppercase text-fog">
                      <tr>
                        <th className="px-3 py-1.5">Código</th>
                        <th className="px-3 py-1.5">Actividad</th>
                        <th className="px-3 py-1.5 text-right">Cant. Anterior</th>
                        <th className="px-3 py-1.5 text-right">Nueva Cant.</th>
                        <th className="px-3 py-1.5 text-right">Variación</th>
                      </tr>
                    </thead>
                    <tbody>
                      {diffResult.activitiesModified.map((a: any) => (
                        <tr key={a.code} className="border-t border-line/40">
                          <td className="px-3 py-1.5 font-mono text-acc">{a.code}</td>
                          <td className="px-3 py-1.5 text-slate-200">{a.name}</td>
                          <td className="px-3 py-1.5 text-right font-mono text-fog">{fmt(a.oldQuantity, 2)}</td>
                          <td className="px-3 py-1.5 text-right font-mono font-bold text-white">{fmt(a.newQuantity, 2)} {a.unit}</td>
                          <td className={cx("px-3 py-1.5 text-right font-mono font-bold", a.diff > 0 ? "text-emerald-400" : "text-rose-400")}>
                            {a.diff > 0 ? `+${fmt(a.diff, 2)}` : fmt(a.diff, 2)}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            {diffResult.activitiesAdded?.length > 0 && (
              <div>
                <p className="mb-1.5 text-xs font-bold uppercase tracking-wider text-emerald-400">
                  Nuevas actividades añadidas en esta revisión ({diffResult.activitiesAdded.length})
                </p>
                <div className="max-h-40 overflow-auto rounded-lg border border-line p-2">
                  {diffResult.activitiesAdded.map((a: any) => (
                    <div key={a.code} className="flex items-center justify-between py-1 text-xs">
                      <span><strong className="font-mono text-emerald-400">{a.code}</strong> {a.name}</span>
                      <span className="font-mono text-slate-300">{fmt(a.quantity, 2)} {a.unit}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            <div className="flex justify-end pt-2">
              <Btn variant="primary" onClick={() => setDiffResult(null)}>
                Entendido, ir al presupuesto
              </Btn>
            </div>
          </div>
        )}
      </Modal>

      {/* MODAL: NUEVO PRESUPUESTO MANUAL */}
      <Modal open={showNew} onClose={() => setShowNew(false)} title="Crear presupuesto manual">
        <div className="space-y-4">
          {error && <Alert tone="error">{error}</Alert>}
          <div className="grid grid-cols-2 gap-3">
            <Field label="Código *" hint="Ej. PRES-2026-01">
              <Input value={form.code} onChange={(e) => setForm({ ...form, code: e.target.value })} placeholder="PRES-2026-01" className="font-mono uppercase" />
            </Field>
            <Field label="Moneda">
              <Input value={form.currency} onChange={(e) => setForm({ ...form, currency: e.target.value })} placeholder="COP" className="font-mono uppercase" />
            </Field>
          </div>
          <Field label="Nombre del proyecto *">
            <Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="Edificio Residencial Las Palmas" />
          </Field>
          <div className="grid grid-cols-2 gap-3">
            <Field label="Cliente">
              <Input value={form.client} onChange={(e) => setForm({ ...form, client: e.target.value })} placeholder="Inversiones ABC" />
            </Field>
            <Field label="Ubicación">
              <Input value={form.location} onChange={(e) => setForm({ ...form, location: e.target.value })} placeholder="Medellín, Colombia" />
            </Field>
          </div>
          <Field label="Descripción">
            <Textarea value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} placeholder="Alcance del presupuesto..." />
          </Field>
          <div className="flex justify-end gap-2 pt-2">
            <Btn onClick={() => setShowNew(false)}>Cancelar</Btn>
            <Btn variant="primary" loading={busy} onClick={createManual}>
              Crear presupuesto
            </Btn>
          </div>
        </div>
      </Modal>
    </div>
  );
}
