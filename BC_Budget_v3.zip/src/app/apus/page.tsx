"use client";

import { useEffect, useState, useMemo } from "react";
import {
  Calculator, Plus, Search, Copy, Trash2, SlidersHorizontal,
  ChevronRight, ChevronDown, BookOpen, Building2, Tag, Info,
} from "lucide-react";
import { Nav } from "@/components/Nav";
import { Card, Chip, Input, Btn, Spinner, Empty, Alert, Modal, cx } from "@/components/ui";
import { api, fmt } from "@/lib/client";
import { ApuEditorModal } from "@/components/budget/ApuEditorModal";

/* ------------------------------------------------------------------ */
/* Constantes                                                          */
/* ------------------------------------------------------------------ */
const REFERENCE_SOURCE = "BANCO_50_APU_COLOMBIA";

/* ------------------------------------------------------------------ */
/* Tipos auxiliares                                                    */
/* ------------------------------------------------------------------ */
interface ApuRow {
  id: string;
  code: string;
  name: string;
  unit: string;
  category: string;
  source: string;
  unitCost: number;
  priceStatus: string;
  isPreferred: boolean;
  versionLabel: string;
  region: string;
  description?: string | null;
  activityCode?: string | null;
  itemsCount?: number;
}

interface TreeNode {
  chapter: string;
  apus: ApuRow[];
  expanded: boolean;
}

/* ------------------------------------------------------------------ */
/* Badge de origen (referencia vs empresa)                             */
/* ------------------------------------------------------------------ */
function OriginBadge({ source }: { source: string }) {
  const isRef = source === REFERENCE_SOURCE;
  return (
    <span className={cx(
      "inline-flex items-center gap-1 rounded-full border px-2 py-0.5 text-[9.5px] font-bold",
      isRef
        ? "border-amber-400/40 bg-amber-400/10 text-amber-300"
        : "border-emerald-400/40 bg-emerald-400/10 text-emerald-300"
    )}>
      {isRef ? <BookOpen size={9} /> : <Building2 size={9} />}
      {isRef ? "APU de referencia" : "APU empresa"}
    </span>
  );
}

/* ------------------------------------------------------------------ */
/* Tooltip de referencia                                               */
/* ------------------------------------------------------------------ */
function RefTooltip({ apu, onCopy }: { apu: ApuRow; onCopy: () => void }) {
  const [show, setShow] = useState(false);
  return (
    <div className="relative inline-flex">
      <button
        onMouseEnter={() => setShow(true)}
        onMouseLeave={() => setShow(false)}
        onClick={() => setShow(!show)}
        className="rounded p-1 text-amber-400/60 hover:text-amber-400"
        title="Este es un APU del banco de referencia — revísalo antes de usar">
        <Info size={12} />
      </button>
      {show && (
        <div className="absolute bottom-full left-0 z-30 mb-1 w-72 rounded-xl border border-amber-400/30 bg-ink-800 p-3 text-[11px] text-slate-200 shadow-xl">
          <p className="mb-2 font-bold text-amber-300">APU de referencia · banco Colombia 2026</p>
          <p className="text-fog">Este APU proviene del banco de plantillas incluido en BC Budget. Sus precios son <strong>referenciales</strong> — deben validarse y actualizarse para tu región y fecha de proyecto antes de usarlos en un presupuesto.</p>
          <button onClick={onCopy}
            className="mt-2 inline-flex w-full items-center justify-center gap-1.5 rounded-lg bg-amber-400/15 px-3 py-1.5 text-[10.5px] font-bold text-amber-300 hover:bg-amber-400/25">
            <Copy size={11} /> Copiar para crear mi versión
          </button>
        </div>
      )}
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Página principal                                                    */
/* ------------------------------------------------------------------ */
export default function MasterApusPage() {
  const [apus, setApus]             = useState<ApuRow[] | null>(null);
  const [q, setQ]                   = useState("");
  const [showRef, setShowRef]       = useState(true);
  const [expandedChapters, setExpandedChapters] = useState<Set<string>>(new Set());
  const [expandedApu, setExpandedApu] = useState<string | null>(null);
  const [apuDetail, setApuDetail]   = useState<{ apu: ApuRow; items: any[] } | null>(null);
  const [loadingDetail, setLoadingDetail] = useState<string | null>(null);
  const [editingApu, setEditingApu] = useState<any | null>(null);
  const [showNewModal, setShowNewModal] = useState(false);
  const [notice, setNotice]         = useState<string | null>(null);
  const [error, setError]           = useState<string | null>(null);

  const load = () =>
    api<{ apus: ApuRow[] }>("/api/budget/apus").then((d) => setApus(d.apus));

  useEffect(() => { load(); }, []);

  /* ------- Árbol por capítulo ------- */
  const tree = useMemo<TreeNode[]>(() => {
    const filtered = (apus ?? []).filter((a) => {
      if (!showRef && a.source === REFERENCE_SOURCE) return false;
      if (q && !`${a.code} ${a.name} ${a.category}`.toLowerCase().includes(q.toLowerCase())) return false;
      return true;
    });

    // Agrupar por capítulo (parte del código antes del punto, o category)
    const chapterMap = new Map<string, ApuRow[]>();
    for (const a of filtered) {
      // Intentar extraer capítulo desde category: "02 ESTRUCTURA" → "02 ESTRUCTURA"
      const chap = a.category || a.code.split(".")[0] || "GENERAL";
      const list = chapterMap.get(chap) ?? [];
      list.push(a);
      chapterMap.set(chap, list);
    }

    return [...chapterMap.entries()]
      .sort(([a], [b]) => a.localeCompare(b, "es", { numeric: true }))
      .map(([chapter, chapApus]) => ({
        chapter,
        apus: [...chapApus].sort((a, b) =>
          a.code.localeCompare(b.code, "es", { numeric: true })
        ),
        expanded: expandedChapters.has(chapter),
      }));
  }, [apus, q, showRef, expandedChapters]);

  const toggleChapter = (chapter: string) =>
    setExpandedChapters((prev) => {
      const next = new Set(prev);
      next.has(chapter) ? next.delete(chapter) : next.add(chapter);
      return next;
    });

  const expandAll = () =>
    setExpandedChapters(new Set(tree.map((t) => t.chapter)));
  const collapseAll = () =>
    setExpandedChapters(new Set());

  /* ------- Cargar detalle de un APU ------- */
  const loadApuDetail = async (apu: ApuRow) => {
    if (expandedApu === apu.id) { setExpandedApu(null); setApuDetail(null); return; }
    setExpandedApu(apu.id);
    setLoadingDetail(apu.id);
    try {
      const d = await api<{ apu: any; items: any[] }>(`/api/budget/apus?id=${apu.id}`);
      setApuDetail({ apu: d.apu, items: d.items });
    } finally { setLoadingDetail(null); }
  };

  /* ------- Abrir editor ------- */
  const openEdit = async (apu: ApuRow) => {
    const d = await api<{ apu: any; items: any[] }>(`/api/budget/apus?id=${apu.id}`);
    setEditingApu({
      ...d.apu,
      components: d.items.map((it) => ({
        insumoId: it.insumoId, category: it.category, description: it.description,
        unit: it.unit, quantity: it.quantity, wastePercentage: it.wastePercentage,
        unitPrice: it.unitPrice, subtotal: it.subtotal,
      })),
    });
    setShowNewModal(true);
  };

  const duplicateApu = async (apu: ApuRow) => {
    const d = await api<{ apu: any; items: any[] }>(`/api/budget/apus?id=${apu.id}`);
    setEditingApu({
      code: `${d.apu.code}-COPIA`,
      name: `${d.apu.name} (Copia)`,
      unit: d.apu.unit,
      category: d.apu.category,
      description: d.apu.description,
      components: d.items.map((it) => ({
        insumoId: it.insumoId, category: it.category, description: it.description,
        unit: it.unit, quantity: it.quantity, wastePercentage: it.wastePercentage,
        unitPrice: it.unitPrice, subtotal: it.subtotal,
      })),
    });
    setShowNewModal(true);
  };

  const handleSaved = async (apuData: any) => {
    try {
      if (editingApu?.id) {
        await api("/api/budget/apus", {
          method: "PATCH",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ id: editingApu.id, ...apuData }),
        });
        setNotice(`APU ${apuData.code} actualizado.`);
      } else {
        await api("/api/budget/apus", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(apuData),
        });
        setNotice(`Nuevo APU ${apuData.code} creado.`);
      }
      setEditingApu(null); setShowNewModal(false); load();
    } catch (e) { setError((e as Error).message); }
  };

  const deleteApu = async (id: string, name: string) => {
    if (!confirm(`¿Eliminar el APU «${name}» del catálogo maestro?`)) return;
    try {
      await api(`/api/budget/apus?id=${id}`, { method: "DELETE" });
      setNotice("APU eliminado."); load();
    } catch (e) { setError((e as Error).message); }
  };

  const money = (n: number) => `$ ${fmt(n, 0)}`;
  const totalApus = (apus ?? []).length;
  const refCount  = (apus ?? []).filter((a) => a.source === REFERENCE_SOURCE).length;
  const ownCount  = totalApus - refCount;

  /* ---------------------------------------------------------------- */
  /* Render                                                            */
  /* ---------------------------------------------------------------- */
  return (
    <div className="min-h-screen pb-20">
      <Nav />
      <main className="mx-auto max-w-[1540px] px-4 py-8 sm:px-6">

        {/* ENCABEZADO */}
        <div className="mb-6 flex flex-wrap items-center justify-between gap-4">
          <div>
            <h1 className="text-xl font-black text-white">Catálogo de APUs</h1>
            <p className="text-xs text-mist">
              Análisis de Precios Unitarios · {ownCount} propios · {refCount} de referencia
            </p>
          </div>
          <Btn variant="primary" icon={Plus}
            onClick={() => { setEditingApu(null); setShowNewModal(true); }}
            className="bg-emerald-500 font-bold text-slate-950 hover:bg-emerald-400">
            Nuevo APU
          </Btn>
        </div>

        {notice && <div className="mb-4"><Alert tone="ok">{notice}</Alert></div>}
        {error   && <div className="mb-4"><Alert tone="error">{error}</Alert></div>}

        {/* BARRA DE HERRAMIENTAS */}
        <div className="mb-4 flex flex-wrap items-center gap-3">
          <div className="relative w-72">
            <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-fog" />
            <Input value={q} onChange={(e) => setQ(e.target.value)}
              placeholder="Buscar APU por código, nombre o capítulo…"
              className="pl-8 text-xs" />
          </div>

          {/* Toggle APUs de referencia */}
          <button onClick={() => setShowRef(!showRef)}
            className={cx(
              "inline-flex items-center gap-1.5 rounded-lg border px-3 py-1.5 text-xs font-semibold transition-colors",
              showRef
                ? "border-amber-400/40 bg-amber-400/10 text-amber-300"
                : "border-line bg-ink-800 text-fog hover:text-white"
            )}>
            <BookOpen size={13} />
            {showRef ? "Ocultar referencias" : "Mostrar referencias"}
            <Chip className={cx("font-mono text-[9.5px]",
              showRef ? "border-amber-400/30 bg-amber-400/10 text-amber-300"
                : "border-line bg-ink-700 text-fog")}>
              {refCount}
            </Chip>
          </button>

          {/* Expandir / Colapsar */}
          <div className="flex gap-1.5">
            <button onClick={expandAll}
              className="rounded-lg border border-line bg-ink-800 px-2.5 py-1.5 text-[11px] font-semibold text-mist hover:text-white">
              Expandir todos
            </button>
            <button onClick={collapseAll}
              className="rounded-lg border border-line bg-ink-800 px-2.5 py-1.5 text-[11px] font-semibold text-mist hover:text-white">
              Colapsar todos
            </button>
          </div>
        </div>

        {/* ÁRBOL DE CAPÍTULOS */}
        {apus === null ? (
          <Spinner label="Cargando catálogo de APUs…" />
        ) : tree.length === 0 ? (
          <Empty icon={Calculator} title="No se encontraron APUs"
            hint="Cree su primer APU o importe su listado de insumos." />
        ) : (
          <div className="space-y-2">
            {tree.map((node) => {
              const isOpen = expandedChapters.has(node.chapter);
              const refInChapter = node.apus.filter((a) => a.source === REFERENCE_SOURCE).length;
              const ownInChapter = node.apus.length - refInChapter;

              return (
                <div key={node.chapter} className="overflow-hidden rounded-xl border border-line bg-ink-900">
                  {/* CABECERA DE CAPÍTULO */}
                  <button
                    onClick={() => toggleChapter(node.chapter)}
                    className="flex w-full items-center gap-3 px-4 py-3 text-left hover:bg-ink-800/60">
                    <span className={cx("transition-transform", isOpen ? "rotate-90" : "")}>
                      <ChevronRight size={15} className="text-fog" />
                    </span>
                    <span className="flex-1 text-sm font-bold text-slate-100">{node.chapter}</span>
                    <div className="flex items-center gap-1.5 text-[10.5px]">
                      {ownInChapter > 0 && (
                        <Chip className="border-emerald-400/30 bg-emerald-400/10 text-emerald-300">
                          {ownInChapter} propios
                        </Chip>
                      )}
                      {refInChapter > 0 && (
                        <Chip className="border-amber-400/30 bg-amber-400/10 text-amber-300">
                          {refInChapter} referencia
                        </Chip>
                      )}
                    </div>
                  </button>

                  {/* LISTA DE APUs DEL CAPÍTULO */}
                  {isOpen && (
                    <div className="border-t border-line/60">
                      {node.apus.map((apu) => {
                        const isRef      = apu.source === REFERENCE_SOURCE;
                        const isExpanded = expandedApu === apu.id;
                        const isLoading  = loadingDetail === apu.id;

                        return (
                          <div key={apu.id}
                            className={cx("border-b border-line/30 last:border-b-0",
                              isRef ? "bg-amber-400/[0.02]" : "")}>

                            {/* FILA DEL APU */}
                            <div className="flex items-center gap-2 px-4 py-2.5">
                              {/* Expandir detalle */}
                              <button onClick={() => loadApuDetail(apu)}
                                className="shrink-0 rounded p-0.5 text-fog hover:text-white">
                                {isLoading
                                  ? <span className="inline-block h-3.5 w-3.5 animate-spin rounded-full border-2 border-fog border-t-transparent" />
                                  : isExpanded
                                    ? <ChevronDown size={14} />
                                    : <ChevronRight size={14} />}
                              </button>

                              {/* Código */}
                              <span className={cx("w-28 shrink-0 font-mono text-xs font-bold",
                                isRef ? "text-amber-400" : "text-emerald-400")}>
                                {apu.code}
                              </span>

                              {/* Nombre */}
                              <span className="flex-1 text-xs font-medium text-slate-100 leading-tight">
                                {apu.name}
                              </span>

                              {/* Badge referencia */}
                              {isRef && <OriginBadge source={apu.source} />}
                              {!isRef && apu.isPreferred && (
                                <Chip className="border-emerald-400/30 bg-emerald-400/10 text-[9.5px] text-emerald-300">
                                  <Tag size={9} className="mr-0.5 inline" /> preferido
                                </Chip>
                              )}

                              {/* Unidad y costo */}
                              <span className="w-14 shrink-0 text-center font-mono text-[10.5px] text-fog">{apu.unit}</span>
                              <span className="w-32 shrink-0 text-right font-mono text-xs font-bold text-white">
                                {money(apu.unitCost)}
                              </span>

                              {/* Acciones */}
                              <div className="flex shrink-0 items-center gap-0.5">
                                {isRef ? (
                                  <RefTooltip apu={apu} onCopy={() => duplicateApu(apu)} />
                                ) : (
                                  <button onClick={() => openEdit(apu)}
                                    className="rounded p-1.5 text-fog hover:bg-acc/15 hover:text-acc"
                                    title="Editar APU">
                                    <SlidersHorizontal size={13} />
                                  </button>
                                )}
                                <button onClick={() => duplicateApu(apu)}
                                  className="rounded p-1.5 text-fog hover:bg-ink-700 hover:text-white"
                                  title={isRef ? "Copiar para crear mi versión" : "Duplicar APU"}>
                                  <Copy size={13} />
                                </button>
                                {!isRef && (
                                  <button onClick={() => deleteApu(apu.id, apu.name)}
                                    className="rounded p-1.5 text-fog hover:bg-rose-500/15 hover:text-rose-400"
                                    title="Eliminar APU">
                                    <Trash2 size={13} />
                                  </button>
                                )}
                              </div>
                            </div>

                            {/* DETALLE DEL APU (expandible) */}
                            {isExpanded && apuDetail?.apu.id === apu.id && (
                              <div className="border-t border-line/40 bg-ink-850 px-10 py-3">
                                {apu.description && (
                                  <p className="mb-3 text-[11px] text-fog italic">{apu.description}</p>
                                )}
                                {isRef && (
                                  <div className="mb-3 flex items-start gap-2 rounded-lg border border-amber-400/25 bg-amber-400/8 px-3 py-2 text-[11px] text-amber-200">
                                    <BookOpen size={12} className="mt-0.5 shrink-0" />
                                    <span>
                                      <strong>APU de referencia · banco Colombia 2026.</strong>{" "}
                                      Precios referenciales — válida y actualiza para tu zona antes de presupuestar.{" "}
                                      <button onClick={() => duplicateApu(apu)}
                                        className="ml-1 font-bold underline hover:text-amber-100">
                                        Copiar para mi catálogo →
                                      </button>
                                    </span>
                                  </div>
                                )}

                                {/* Tabla de componentes */}
                                {apuDetail.items.length > 0 && (
                                  <table className="w-full text-[11px]">
                                    <thead>
                                      <tr className="text-[10px] uppercase text-fog">
                                        <th className="pb-1.5 pr-3 text-left">Descripción</th>
                                        <th className="pb-1.5 pr-2 text-left">Cat.</th>
                                        <th className="pb-1.5 pr-2 text-center">Unid.</th>
                                        <th className="pb-1.5 pr-2 text-right">Cant.</th>
                                        <th className="pb-1.5 pr-2 text-right">Desp. %</th>
                                        <th className="pb-1.5 pr-2 text-right">P.U.</th>
                                        <th className="pb-1.5 text-right">Subtotal</th>
                                      </tr>
                                    </thead>
                                    <tbody>
                                      {apuDetail.items.map((it, i) => (
                                        <tr key={i} className="border-t border-line/20">
                                          <td className="py-1 pr-3 text-slate-200">{it.description}</td>
                                          <td className="py-1 pr-2">
                                            <Chip className="border-line bg-ink-800 text-[9px] text-fog">{it.category}</Chip>
                                          </td>
                                          <td className="py-1 pr-2 text-center font-mono text-fog">{it.unit}</td>
                                          <td className="py-1 pr-2 text-right font-mono">{it.quantity}</td>
                                          <td className="py-1 pr-2 text-right font-mono">{it.wastePercentage > 0 ? `${it.wastePercentage}%` : "—"}</td>
                                          <td className="py-1 pr-2 text-right font-mono">{money(it.unitPrice)}</td>
                                          <td className="py-1 text-right font-mono font-bold text-slate-100">{money(it.subtotal)}</td>
                                        </tr>
                                      ))}
                                    </tbody>
                                    <tfoot>
                                      <tr className="border-t border-line">
                                        <td colSpan={6} className="pt-2 text-right text-[10px] font-bold uppercase text-fog">
                                          Costo Directo Unitario
                                        </td>
                                        <td className="pt-2 text-right font-mono text-sm font-black text-white">
                                          {money(apu.unitCost)}
                                        </td>
                                      </tr>
                                    </tfoot>
                                  </table>
                                )}
                              </div>
                            )}
                          </div>
                        );
                      })}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </main>

      <ApuEditorModal
        open={showNewModal}
        onClose={() => { setShowNewModal(false); setEditingApu(null); }}
        initialApu={editingApu}
        onSaved={handleSaved}
      />
    </div>
  );
}
