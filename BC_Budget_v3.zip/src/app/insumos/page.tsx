"use client";

import { useEffect, useState, useMemo, useCallback } from "react";
import {
  Coins, Plus, Search, Pencil, Trash2, Check, Copy, X,
  ArrowUpDown, ArrowUp, ArrowDown, ChevronDown, ChevronUp,
} from "lucide-react";
import { Nav } from "@/components/Nav";
import { Card, Chip, Input, Btn, Spinner, Empty, Alert, Modal, Select, Field, cx } from "@/components/ui";
import { api, fmt } from "@/lib/client";
import type { InsumoCategory } from "@/db/schema";

/* ------------------------------------------------------------------ */
/* Configuración de categorías con pestañas                            */
/* ------------------------------------------------------------------ */
const TAB_CATEGORIES: { v: InsumoCategory | "TODOS"; l: string }[] = [
  { v: "TODOS",        l: "Todos" },
  { v: "MATERIAL",     l: "Materiales" },
  { v: "MANO_DE_OBRA", l: "Mano de Obra" },
  { v: "EQUIPO",       l: "Equipos y Herramientas" },
  { v: "TRANSPORTE",   l: "Transporte" },
  { v: "SUBCONTRATO",  l: "Subcontratos" },
];

type SortField = "code" | "name" | "category" | "unit" | "unitPrice" | "supplier";
type SortDir   = "asc" | "desc";

const SORT_OPTIONS: { v: SortField; l: string }[] = [
  { v: "code",      l: "Código" },
  { v: "name",      l: "Nombre" },
  { v: "category",  l: "Categoría" },
  { v: "unit",      l: "Unidad" },
  { v: "unitPrice", l: "Precio" },
  { v: "supplier",  l: "Proveedor" },
];

const BLANK_FORM = {
  code: "", name: "", unit: "UND",
  category: "MATERIAL" as InsumoCategory,
  unitPrice: "0", supplier: "", region: "COLOMBIA",
  priceDate: new Date().toISOString().slice(0, 10), notes: "",
};

/* ------------------------------------------------------------------ */
/* Componente de modal de crear / editar insumo                        */
/* ------------------------------------------------------------------ */
function InsumoModal({
  open, onClose, initial, onSaved,
}: {
  open: boolean;
  onClose: () => void;
  initial: typeof BLANK_FORM | null;
  onSaved: () => void;
}) {
  const [form, setForm] = useState(initial ?? BLANK_FORM);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => { setForm(initial ?? BLANK_FORM); setError(null); }, [initial, open]);

  const set = (k: keyof typeof BLANK_FORM, v: string) =>
    setForm((f) => ({ ...f, [k]: v }));

  const handleSave = async () => {
    if (!form.code.trim() || !form.name.trim()) {
      setError("Código y nombre son obligatorios."); return;
    }
    setBusy(true); setError(null);
    try {
      const isEdit = !!(initial as any)?.id;
      await api("/api/budget/insumos", {
        method: isEdit ? "PATCH" : "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          ...(isEdit ? { id: (initial as any).id } : {}),
          ...form,
          unitPrice: Number(form.unitPrice.replace(",", ".")) || 0,
        }),
      });
      onSaved();
      onClose();
    } catch (e) { setError((e as Error).message); }
    finally { setBusy(false); }
  };

  const isEdit = !!(initial as any)?.id;

  return (
    <Modal open={open} onClose={onClose} title={isEdit ? "Editar Insumo" : "Nuevo Insumo"}>
      <div className="space-y-4">
        {error && <Alert tone="error">{error}</Alert>}
        <div className="grid grid-cols-2 gap-3">
          <Field label="Código *">
            <Input value={form.code} onChange={(e) => set("code", e.target.value)}
              className="font-mono font-bold uppercase" />
          </Field>
          <Field label="Categoría *">
            <Select value={form.category}
              onChange={(e) => set("category", e.target.value)}>
              {TAB_CATEGORIES.filter((c) => c.v !== "TODOS").map((c) => (
                <option key={c.v} value={c.v}>{c.l}</option>
              ))}
            </Select>
          </Field>
        </div>
        <Field label="Nombre del Insumo / Recurso *">
          <Input value={form.name} onChange={(e) => set("name", e.target.value)}
            placeholder="Ej. Cemento gris saco 50 kg…" />
        </Field>
        <div className="grid grid-cols-2 gap-3">
          <Field label="Unidad *">
            <Input value={form.unit} onChange={(e) => set("unit", e.target.value.toUpperCase())}
              className="font-mono uppercase" placeholder="M3, KG, JOR…" />
          </Field>
          <Field label="Precio Unitario *">
            <Input value={form.unitPrice} onChange={(e) => set("unitPrice", e.target.value)}
              className="font-mono" inputMode="decimal" />
          </Field>
        </div>
        <Field label="Proveedor / Fuente">
          <Input value={form.supplier} onChange={(e) => set("supplier", e.target.value)}
            placeholder="Ej. Distribuidor regional…" />
        </Field>
        <div className="grid grid-cols-2 gap-3">
          <Field label="Zona / Región">
            <Input value={form.region} onChange={(e) => set("region", e.target.value)}
              placeholder="ANTIOQUIA" />
          </Field>
          <Field label="Fecha efectiva">
            <Input type="date" value={form.priceDate}
              onChange={(e) => set("priceDate", e.target.value)} />
          </Field>
        </div>
        <div className="flex justify-end gap-2 pt-2">
          <Btn onClick={onClose}>Cancelar</Btn>
          <Btn variant="primary" loading={busy} onClick={handleSave}>
            {isEdit ? "Guardar cambios" : "Crear Insumo"}
          </Btn>
        </div>
      </div>
    </Modal>
  );
}

/* ------------------------------------------------------------------ */
/* Página principal                                                    */
/* ------------------------------------------------------------------ */
export default function MasterInsumosPage() {
  const [insumos, setInsumos]       = useState<any[] | null>(null);
  const [q, setQ]                   = useState("");
  const [tab, setTab]               = useState<InsumoCategory | "TODOS">("TODOS");
  const [sortField, setSortField]   = useState<SortField>("code");
  const [sortDir, setSortDir]       = useState<SortDir>("asc");
  const [showSort, setShowSort]     = useState(false);
  const [editingPriceId, setEditingPriceId] = useState<string | null>(null);
  const [newPriceVal, setNewPriceVal] = useState("");
  const [modalOpen, setModalOpen]   = useState(false);
  const [modalInitial, setModalInitial] = useState<typeof BLANK_FORM | null>(null);
  const [notice, setNotice]         = useState<string | null>(null);
  const [error, setError]           = useState<string | null>(null);

  const load = useCallback(() => {
    api<{ insumos: any[] }>("/api/budget/insumos").then((d) => setInsumos(d.insumos));
  }, []);

  useEffect(() => { load(); }, [load]);

  /* ------- Ordenamiento ------- */
  const toggleSort = (field: SortField) => {
    if (sortField === field) setSortDir((d) => d === "asc" ? "desc" : "asc");
    else { setSortField(field); setSortDir("asc"); }
    setShowSort(false);
  };

  const sorted = useMemo(() => {
    const base = (insumos ?? []).filter((i) => {
      if (tab !== "TODOS" && i.category !== tab) return false;
      if (q && !`${i.code} ${i.name} ${i.supplier || ""}`.toLowerCase().includes(q.toLowerCase())) return false;
      return true;
    });
    return [...base].sort((a, b) => {
      const av = a[sortField] ?? "";
      const bv = b[sortField] ?? "";
      const cmp = typeof av === "number"
        ? av - bv
        : String(av).localeCompare(String(bv), "es", { numeric: true });
      return sortDir === "asc" ? cmp : -cmp;
    });
  }, [insumos, tab, q, sortField, sortDir]);

  /* ------- Acciones ------- */
  const openNew = () => {
    // Código consecutivo por categoría
    const catInsumos = (insumos ?? []).filter((i) => tab === "TODOS" ? true : i.category === tab);
    const prefix = tab === "TODOS" ? "INS" : tab === "MATERIAL" ? "MAT" :
      tab === "MANO_DE_OBRA" ? "MO" : tab === "EQUIPO" ? "EQ" :
      tab === "TRANSPORTE" ? "TR" : "SUB";
    const nums = catInsumos
      .map((i) => { const m = i.code.match(/(\d+)$/); return m ? parseInt(m[1]) : 0; })
      .filter((n) => n > 0);
    const next = nums.length ? Math.max(...nums) + 1 : 1;
    setModalInitial({
      ...BLANK_FORM,
      code: `${prefix}-${String(next).padStart(3, "0")}`,
      category: tab === "TODOS" ? "MATERIAL" : tab as InsumoCategory,
    });
    setModalOpen(true);
  };

  const openEdit = (ins: any) => {
    setModalInitial({
      ...BLANK_FORM,
      ...ins,
      unitPrice: String(ins.unitPrice ?? 0),
      priceDate: ins.priceDate
        ? new Date(ins.priceDate).toISOString().slice(0, 10)
        : new Date().toISOString().slice(0, 10),
      id: ins.id,
    } as any);
    setModalOpen(true);
  };

  const handleDuplicate = async (ins: any) => {
    const prefix = ins.code.replace(/\d+$/, "");
    const nums = (insumos ?? [])
      .filter((i) => i.code.startsWith(prefix))
      .map((i) => { const m = i.code.match(/(\d+)$/); return m ? parseInt(m[1]) : 0; });
    const next = nums.length ? Math.max(...nums) + 1 : 1;
    const newCode = `${prefix}${String(next).padStart(3, "0")}`;
    setModalInitial({
      ...BLANK_FORM,
      ...ins,
      code: newCode,
      name: `${ins.name} (Copia)`,
      unitPrice: String(ins.unitPrice ?? 0),
      priceDate: ins.priceDate
        ? new Date(ins.priceDate).toISOString().slice(0, 10)
        : new Date().toISOString().slice(0, 10),
    });
    setModalOpen(true);
  };

  const handleUpdatePrice = async (id: string) => {
    const val = Number(newPriceVal.replace(",", "."));
    if (!isFinite(val)) return;
    try {
      await api("/api/budget/insumos", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id, unitPrice: val, actor: "Presupuestador" }),
      });
      setEditingPriceId(null); load();
    } catch (e) { setError((e as Error).message); }
  };

  const handleDelete = async (id: string, name: string) => {
    if (!confirm(`¿Eliminar el insumo «${name}» del catálogo?`)) return;
    try {
      await api(`/api/budget/insumos?id=${id}`, { method: "DELETE" });
      setNotice("Insumo eliminado."); load();
    } catch (e) { setError((e as Error).message); }
  };

  const money = (n: number) => `$ ${fmt(n, 0)}`;
  const SortIcon = ({ field }: { field: SortField }) =>
    sortField !== field ? <ArrowUpDown size={11} className="opacity-30" /> :
    sortDir === "asc" ? <ArrowUp size={11} /> : <ArrowDown size={11} />;

  return (
    <div className="min-h-screen pb-20">
      <Nav />
      <main className="mx-auto max-w-[1540px] px-4 py-8 sm:px-6">

        {/* ENCABEZADO */}
        <div className="mb-6 flex flex-wrap items-center justify-between gap-4">
          <div>
            <h1 className="text-xl font-black text-white">Catálogo Maestro de Insumos & Precios</h1>
            <p className="text-xs text-mist">Base centralizada de precios de materiales, mano de obra, equipos y subcontratos</p>
          </div>
          <Btn variant="primary" icon={Plus} onClick={openNew}
            className="bg-emerald-500 font-bold text-slate-950 hover:bg-emerald-400">
            Nuevo Insumo
          </Btn>
        </div>

        {notice && <div className="mb-4"><Alert tone="ok">{notice}</Alert></div>}
        {error   && <div className="mb-4"><Alert tone="error">{error}</Alert></div>}

        {/* PESTAÑAS POR CATEGORÍA */}
        <div className="mb-4 flex flex-wrap items-center gap-1.5 border-b border-line pb-3">
          {TAB_CATEGORIES.map((c) => {
            const count = c.v === "TODOS"
              ? (insumos?.length ?? 0)
              : (insumos ?? []).filter((i) => i.category === c.v).length;
            return (
              <button key={c.v} onClick={() => setTab(c.v)}
                className={cx(
                  "inline-flex items-center gap-1.5 rounded-lg border px-3 py-1.5 text-xs font-semibold transition-colors",
                  tab === c.v
                    ? "border-emerald-400/40 bg-emerald-400/10 text-emerald-300"
                    : "border-line bg-ink-800 text-mist hover:text-white"
                )}>
                {c.l}
                {insumos && <span className={cx("rounded-full px-1.5 font-mono text-[9.5px]",
                  tab === c.v ? "bg-emerald-400/20 text-emerald-200" : "bg-ink-700 text-fog")}>
                  {count}
                </span>}
              </button>
            );
          })}
        </div>

        {/* BARRA DE BÚSQUEDA Y ORDENAMIENTO */}
        <div className="mb-4 flex flex-wrap items-center gap-3">
          <div className="relative w-64">
            <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-fog" />
            <Input value={q} onChange={(e) => setQ(e.target.value)}
              placeholder="Buscar por código, nombre…" className="pl-8 text-xs" />
          </div>

          {/* Selector de ordenamiento */}
          <div className="relative">
            <button
              onClick={() => setShowSort(!showSort)}
              className={cx(
                "inline-flex items-center gap-1.5 rounded-lg border px-3 py-1.5 text-xs font-semibold",
                showSort ? "border-acc/40 bg-acc/10 text-acc"
                  : "border-line bg-ink-800 text-mist hover:text-white"
              )}>
              <ArrowUpDown size={13} />
              Ordenar: {SORT_OPTIONS.find((o) => o.v === sortField)?.l}
              {sortDir === "asc" ? <ArrowUp size={11} /> : <ArrowDown size={11} />}
            </button>
            {showSort && (
              <div className="absolute left-0 top-full z-20 mt-1 rounded-xl border border-line bg-ink-800 p-1 shadow-xl">
                {SORT_OPTIONS.map((o) => (
                  <button key={o.v} onClick={() => toggleSort(o.v)}
                    className={cx(
                      "flex w-full items-center gap-2 rounded-lg px-3 py-2 text-xs font-semibold",
                      sortField === o.v ? "bg-acc/10 text-acc" : "text-mist hover:text-white"
                    )}>
                    <SortIcon field={o.v} /> {o.l}
                  </button>
                ))}
              </div>
            )}
          </div>

          <span className="text-[11px] text-fog">{sorted.length} insumo{sorted.length !== 1 ? "s" : ""}</span>
        </div>

        {/* TABLA */}
        {insumos === null ? (
          <Spinner label="Cargando catálogo de insumos…" />
        ) : sorted.length === 0 ? (
          <Empty icon={Coins} title="No se encontraron insumos"
            hint="Añada su primer insumo o ajuste los filtros de búsqueda." />
        ) : (
          <Card className="overflow-hidden">
            <div className="max-h-[600px] overflow-auto">
              <table className="w-full text-left text-xs">
                <thead className="sticky top-0 bg-ink-800 text-[10px] uppercase text-fog">
                  <tr>
                    {([
                      ["code",      "Código"],
                      ["name",      "Nombre"],
                      ["category",  "Categoría"],
                      ["unit",      "Unidad"],
                      ["unitPrice", "Precio Unitario"],
                      ["supplier",  "Proveedor"],
                    ] as [SortField, string][]).map(([f, l]) => (
                      <th key={f}
                        className="cursor-pointer select-none px-4 py-2.5 hover:text-white"
                        onClick={() => toggleSort(f)}>
                        <span className="inline-flex items-center gap-1">
                          {l} <SortIcon field={f} />
                        </span>
                      </th>
                    ))}
                    <th className="w-28 px-3 py-2.5 text-right">Acciones</th>
                  </tr>
                </thead>
                <tbody>
                  {sorted.map((ins) => (
                    <tr key={ins.id} className="border-t border-line/40 transition-colors hover:bg-ink-800/60">
                      <td className="px-4 py-2 font-mono font-bold text-emerald-400">{ins.code}</td>
                      <td className="px-4 py-2 font-medium text-slate-100">{ins.name}</td>
                      <td className="px-3 py-2">
                        <Chip className="border-line bg-ink-750 text-[10.5px]">{ins.category}</Chip>
                      </td>
                      <td className="px-2 py-2 text-center font-mono text-fog">{ins.unit}</td>

                      {/* Precio editable inline */}
                      <td className="px-4 py-2 text-right">
                        {editingPriceId === ins.id ? (
                          <div className="flex items-center justify-end gap-1">
                            <Input value={newPriceVal}
                              onChange={(e) => setNewPriceVal(e.target.value)}
                              className="h-7 w-28 py-0 text-right font-mono text-xs font-bold"
                              autoFocus
                              onKeyDown={(e) => {
                                if (e.key === "Enter") handleUpdatePrice(ins.id);
                                if (e.key === "Escape") setEditingPriceId(null);
                              }} />
                            <button onClick={() => handleUpdatePrice(ins.id)}
                              className="rounded p-1 text-emerald-400 hover:bg-emerald-400/15">
                              <Check size={13} />
                            </button>
                            <button onClick={() => setEditingPriceId(null)}
                              className="rounded p-1 text-fog hover:text-rose-400">
                              <X size={13} />
                            </button>
                          </div>
                        ) : (
                          <button
                            onClick={() => { setEditingPriceId(ins.id); setNewPriceVal(String(ins.unitPrice)); }}
                            className="group inline-flex items-center gap-1 font-mono font-bold text-slate-100 hover:text-emerald-300"
                            title="Clic para editar precio">
                            <span>{money(ins.unitPrice)}</span>
                            <Pencil size={11} className="opacity-0 group-hover:opacity-100 text-fog" />
                          </button>
                        )}
                      </td>

                      <td className="px-3 py-2 text-fog">{ins.supplier || ins.source || "—"}</td>

                      <td className="px-3 py-2 text-right">
                        <div className="inline-flex items-center gap-0.5">
                          <button onClick={() => openEdit(ins)}
                            className="rounded p-1.5 text-fog hover:bg-acc/15 hover:text-acc"
                            title="Editar insumo"><Pencil size={13} /></button>
                          <button onClick={() => handleDuplicate(ins)}
                            className="rounded p-1.5 text-fog hover:bg-ink-700 hover:text-white"
                            title="Duplicar insumo"><Copy size={13} /></button>
                          <button onClick={() => handleDelete(ins.id, ins.name)}
                            className="rounded p-1.5 text-fog hover:bg-rose-500/15 hover:text-rose-400"
                            title="Eliminar insumo"><Trash2 size={13} /></button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </Card>
        )}
      </main>

      <InsumoModal
        open={modalOpen}
        onClose={() => setModalOpen(false)}
        initial={modalInitial}
        onSaved={() => { load(); setNotice("Insumo guardado correctamente."); }}
      />
    </div>
  );
}
