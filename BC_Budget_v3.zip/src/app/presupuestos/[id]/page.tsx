import { BudgetWorkspace } from "@/components/budget/BudgetWorkspace";

export default async function BudgetProjectPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  return <BudgetWorkspace projectId={id} />;
}
