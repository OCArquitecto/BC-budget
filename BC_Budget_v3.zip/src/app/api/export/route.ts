import { NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { sortByCode } from "@/lib/codes";
import {
  projects, quantities, catalogActivities, sources, structureNodes, decisions,
} from "@/db/schema";

const csvSafe = (v: unknown) => {
  const s = v === null || v === undefined ? "" : String(v);
  return /[",\n;]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
};

export async function GET(req: Request) {
  const url = new URL(req.url);
  const projectId = url.searchParams.get("projectId");
  const format = url.searchParams.get("format") ?? "json";
  if (!projectId) return NextResponse.json({ error: "projectId requerido" }, { status: 400 });

  const [project] = await db.select().from(projects).where(eq(projects.id, projectId)).limit(1);
  if (!project) return NextResponse.json({ error: "Proyecto no encontrado" }, { status: 404 });

  const qtys = await db.select().from(quantities).where(eq(quantities.projectId, projectId));
  const acts = await db.select().from(catalogActivities);
  const actMap = new Map(acts.map((a) => [a.id, a]));
  const src = await db.select().from(sources).where(eq(sources.projectId, projectId));
  const srcMap = new Map(src.map((s) => [s.id, s]));
  const nodes = await db.select().from(structureNodes).where(eq(structureNodes.projectId, projectId));
  const decs = await db.select().from(decisions).where(eq(decisions.projectId, projectId));

  if (format === "csv") {
    const header = ["Codigo", "Actividad", "Estado", "Cantidad", "Unidad", "Metodo", "Origen", "Elementos", "Regla", "ValidadaPor", "Fecha"];
    const lines = [header.join(";")];
    for (const q of qtys) {
      const act = q.activityId ? actMap.get(q.activityId) : null;
      const origen = q.sourceId ? srcMap.get(q.sourceId)?.name : (q.evidence as { fuentes?: string[] } | null)?.fuentes?.join(" + ") ?? "";
      lines.push([
        act?.code ?? "", act?.name ?? q.note ?? "", q.status,
        q.value === null ? "" : String(q.value).replace(".", ","),
        q.unit, q.method, origen, String(q.elementCount),
        q.rule ?? "", q.validatedBy ?? "", q.validatedAt ? new Date(q.validatedAt).toISOString() : "",
      ].map(csvSafe).join(";"));
    }
    return new NextResponse(lines.join("\n"), {
      headers: {
        "Content-Type": "text/csv; charset=utf-8",
        "Content-Disposition": `attachment; filename="${project.code}-cantidades.csv"`,
      },
    });
  }

  // JSON completo con trazabilidad (contrato de salida hacia BC Budget)
  const chapters = sortByCode(nodes.filter((n) => n.kind === "CAPITULO"), (n) => n.code);
  const sections = sortByCode(nodes.filter((n) => n.kind === "SECCION"), (n) => n.code);
  const actNodes = sortByCode(nodes.filter((n) => n.kind === "ACTIVIDAD"), (n) => n.code);

  const qtyDto = qtys.map((q) => {
    const act = q.activityId ? actMap.get(q.activityId) : null;
    return {
      id: q.id,
      actividad: act ? { codigo: act.code, nombre: act.name, unidad: act.unit } : null,
      estado: q.status,
      cantidad: q.value,
      unidad: q.unit,
      metodoMedicion: q.method,
      regla: q.rule,
      origen: {
        tipo: q.sourceKind,
        fuente: q.sourceId ? srcMap.get(q.sourceId)?.name ?? null : null,
      },
      elementos: { total: q.elementCount, ids: q.elementIds },
      evidencia: q.evidence,
      validadaPor: q.validatedBy,
      validadaEn: q.validatedAt,
      nota: q.note,
    };
  });

  const tree = chapters.map((ch) => ({
    codigo: ch.code,
    nombre: ch.name,
    secciones: sections
      .filter((s) => s.parentId === ch.id)
      .map((s) => ({
        codigo: s.code,
        nombre: s.name,
        actividades: actNodes.filter((a) => a.parentId === s.id).map((a) => {
          const act = a.activityId ? actMap.get(a.activityId) : null;
          const qs = qtyDto.filter((q) => q.actividad?.codigo === a.code);
          const validada = qs.filter((q) => q.estado === "VALIDADA").reduce((acc, q) => acc + (q.cantidad ?? 0), 0);
          return {
            codigo: a.code,
            nombre: a.name,
            unidad: act?.unit ?? null,
            metodo: act?.method ?? null,
            totalValidada: Math.round(validada * 1000) / 1000,
            cantidades: qs,
          };
        })
        // No se exportan las líneas que quedaron sin ninguna cantidad.
        .filter((a) => a.cantidades.length > 0),
      })),
  }));

  const payload = {
    formato: "BIMCost-Quantity/BC-Budget@1",
    exportadoEn: new Date().toISOString(),
    proyecto: {
      codigo: project.code, nombre: project.name, cliente: project.client,
      ubicacion: project.location, unidades: project.units,
    },
    alcance: "QUÉ se construye, CUÁNTO y DE DÓNDE sale cada cantidad. Los costos se calculan en BC Budget.",
    fuentes: src.map((s) => ({ nombre: s.name, tipo: s.kind, disciplina: s.discipline, archivo: s.fileName, esquemaIfc: s.ifcSchema })),
    estructura: tree,
    cantidades: qtyDto,
    decisiones: decs.map((d) => ({ fecha: d.createdAt, entidad: d.entityType, accion: d.action, actor: d.actor, detalle: d.detail })),
  };

  return new NextResponse(JSON.stringify(payload, null, 2), {
    headers: {
      "Content-Type": "application/json; charset=utf-8",
      "Content-Disposition": `attachment; filename="${project.code}-quantity.json"`,
    },
  });
}
