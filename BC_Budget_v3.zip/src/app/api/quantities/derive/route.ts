import { NextResponse } from "next/server";
import { eq, inArray } from "drizzle-orm";
import { db } from "@/db";
import { quantities, elements as elementsTable, catalogActivities, type MeasureConfig } from "@/db/schema";
import { measureElements, defaultConfigFor } from "@/lib/engine";
import { toWorkElement, addDecision, ensureStructureNodes } from "@/lib/server";

/**
 * Deriva UNA O VARIAS actividades a partir de una cantidad ya medida.
 *
 * Caso típico: sobre los mismos muros se aplican a la vez friso, pintura y
 * enchape. Cada actividad derivada:
 *   · reutiliza los MISMOS elementos IFC (mismos GlobalId),
 *   · guarda el vínculo con su origen (derivedFromId),
 *   · puede llevar su propia regla de medición (una cara, dos caras,
 *     contorno, área neta…), elegida en el mismo momento de derivar.
 *
 * Acepta tanto `activityId` (una) como `activities` (varias).
 */
export async function POST(req: Request) {
  const body = await req.json();
  const { quantityId, activityId, activities, measureConfig, label, note, actor, elementIds } = body ?? {};

  if (!quantityId) {
    return NextResponse.json({ error: "quantityId es obligatorio." }, { status: 400 });
  }

  /** Lista normalizada: cada entrada puede traer su propia configuración. */
  type Petition = { activityId: string; measureConfig?: MeasureConfig; label?: string };
  const petitions: Petition[] = Array.isArray(activities) && activities.length
    ? activities.map((a: Petition | string) =>
        typeof a === "string" ? { activityId: a } : { activityId: a.activityId, measureConfig: a.measureConfig, label: a.label })
    : activityId
      ? [{ activityId, measureConfig, label }]
      : [];

  if (!petitions.length) {
    return NextResponse.json({ error: "Debe indicar al menos una actividad a derivar." }, { status: 400 });
  }

  const [origin] = await db.select().from(quantities).where(eq(quantities.id, quantityId)).limit(1);
  if (!origin) return NextResponse.json({ error: "Cantidad de origen no encontrada." }, { status: 404 });

  const [originAct] = origin.activityId
    ? await db.select().from(catalogActivities).where(eq(catalogActivities.id, origin.activityId)).limit(1)
    : [undefined];

  /* --- subconjunto opcional de elementos --- */
  const baseIds = (origin.elementIds as string[]) ?? [];
  const subset = Array.isArray(elementIds) && elementIds.length
    ? baseIds.filter((id) => (elementIds as string[]).includes(id))
    : baseIds;
  const parcial = subset.length > 0 && subset.length < baseIds.length;

  const els = subset.length
    ? await db.select().from(elementsTable).where(inArray(elementsTable.id, subset))
    : [];
  const work = els.map(toWorkElement).filter((w) => !w.excluded);

  const created: unknown[] = [];
  const omitidas: { actividad: string; motivo: string }[] = [];
  const avisos: string[] = [];

  for (const p of petitions) {
    const [act] = await db.select().from(catalogActivities).where(eq(catalogActivities.id, p.activityId)).limit(1);
    if (!act) {
      omitidas.push({ actividad: p.activityId, motivo: "Actividad no encontrada en el catálogo." });
      continue;
    }
    if (!work.length && act.method !== "MANUAL") {
      omitidas.push({ actividad: act.code, motivo: "La cantidad de origen no tiene elementos BIM medibles." });
      continue;
    }

    /* --- Evitar duplicar la MISMA actividad sobre los mismos elementos --- */
    const already = await db
      .select()
      .from(quantities)
      .where(eq(quantities.projectId, origin.projectId));
    const globalIds = work.map((w) => w.globalId).filter((g): g is string => !!g);
    const clash = already.find(
      (q) =>
        q.activityId === act.id &&
        q.status !== "RECHAZADA" &&
        (q.elementGlobalIds ?? []).some((g) => globalIds.includes(g))
    );
    if (clash) {
      omitidas.push({
        actividad: `${act.code} ${act.name}`,
        motivo: "Estos elementos ya tienen esa actividad medida; no se duplica.",
      });
      continue;
    }

    const cfg: MeasureConfig =
      p.measureConfig ??
      (measureConfig as MeasureConfig | undefined) ??
      (act.measureConfig as MeasureConfig | null) ??
      defaultConfigFor(act.method, [...new Set(work.map((w) => w.ifcClass))]);

    const measured = measureElements(work, act.method, cfg);
    const isManual = act.method === "MANUAL";
    if (measured.missing > 0) {
      avisos.push(`${act.code}: ${measured.missing} elemento(s) sin datos de medición.`);
    }

    const [row] = await db
      .insert(quantities)
      .values({
        projectId: origin.projectId,
        matchId: origin.matchId,
        groupId: origin.groupId,
        activityId: act.id,
        sourceId: origin.sourceId,
        sourceKind: origin.sourceKind,
        derivedFromId: origin.id,
        label: p.label ?? label ?? null,
        value: isManual ? null : measured.value,
        unit: act.unit,
        method: act.method,
        measureConfig: cfg,
        rule: measured.rule,
        evidence: {
          computadaEn: new Date().toISOString(),
          derivadaDe: {
            cantidadId: origin.id,
            actividad: originAct ? `${originAct.code} ${originAct.name}` : null,
            valorOrigen: origin.value,
            unidadOrigen: origin.unit,
            elementosOrigen: baseIds.length,
            elementosSeleccionados: work.length,
            parcial,
            nota: parcial
              ? `Acabado aplicado a ${work.length} de ${baseIds.length} elementos de la actividad padre, según decisión profesional.`
              : "Reutiliza los mismos elementos IFC del origen. Si el diseño cambia, re-mida el origen y luego esta derivada.",
          },
          clases: [...new Set(work.map((w) => w.ifcClass))],
          camposUtilizados: measured.fields,
          elementosMedidos: measured.measuredCount,
          elementosSinDato: measured.missing,
          elementosSinDatoEjemplos: measured.missingElements,
          configuracionMedicion: cfg,
          derivacionMultiple: petitions.length > 1,
          advertencias: [
            "Cantidad DERIVADA: mide los mismos elementos que su origen con otra regla (p. ej. acabado sobre muro).",
            ...(measured.missing > 0 ? [`${measured.missing} elemento(s) sin datos suficientes.`] : []),
          ],
          porQueEstaActividad: {
            decision: "DERIVADA por decisión profesional desde una cantidad existente",
            coincidencias: ["derivación explícita del profesional"],
          },
        },
        elementIds: work.map((w) => w.id),
        elementGlobalIds: globalIds,
        elementCount: work.length,
        status: isManual ? "PENDIENTE" : "PROPUESTA",
        note: note ?? null,
      })
      .returning();

    await ensureStructureNodes(origin.projectId, act.id);
    await addDecision(origin.projectId, "CANTIDAD", row.id, "DERIVO_ACTIVIDAD", {
      origen: originAct ? `${originAct.code} ${originAct.name}` : origin.id,
      nuevaActividad: `${act.code} ${act.name}`,
      cantidad: measured.value, unidad: act.unit, metodo: act.method,
      configuracion: cfg,
      elementos: work.length,
      elementosDelPadre: baseIds.length,
      seleccionParcial: parcial,
      enLote: petitions.length > 1,
      nota: note ?? null,
    }, actor);

    created.push(row);
  }

  if (!created.length) {
    return NextResponse.json(
      { error: omitidas[0]?.motivo ?? "No se pudo derivar ninguna actividad.", omitidas },
      { status: 409 }
    );
  }

  return NextResponse.json({
    quantities: created,
    quantity: created[0],
    creadas: created.length,
    omitidas,
    aviso: avisos.length ? avisos.join(" ") : null,
  });
}
