import { NextResponse } from "next/server";
import { eq, inArray } from "drizzle-orm";
import { db } from "@/db";
import { quantities, catalogActivities } from "@/db/schema";
import { addDecision, ensureStructureNodes, pruneEmptyStructure } from "@/lib/server";

export async function POST(req: Request) {
  const body = await req.json();
  const { ids, action, actor, note } = body ?? {};
  if (!Array.isArray(ids) || !ids.length) {
    return NextResponse.json({ error: "Seleccione al menos una cantidad." }, { status: 400 });
  }
  const rows = await db.select().from(quantities).where(inArray(quantities.id, ids as string[]));
  if (!rows.length) return NextResponse.json({ error: "No se encontraron cantidades." }, { status: 404 });
  const projectId = rows[0].projectId;

  const result = { validadas: 0, rechazadas: 0, eliminadas: 0, omitidas: 0, motivos: [] as string[] };

  /* ----------------------- ELIMINACIÓN EN LOTE ---------------------- */
  if (action === "delete") {
    const all = await db.select().from(quantities).where(eq(quantities.projectId, projectId));
    const removeIds = new Set(rows.map((r) => r.id));
    let changed = true;
    while (changed) {
      changed = false;
      for (const q of all) {
        if (!removeIds.has(q.id) && q.derivedFromId && removeIds.has(q.derivedFromId)) {
          removeIds.add(q.id);
          changed = true;
        }
      }
    }
    const acts = await db.select().from(catalogActivities);
    const actMap = new Map(acts.map((a) => [a.id, a]));
    const detalle = rows.map((q) => {
      const a = q.activityId ? actMap.get(q.activityId) : null;
      return { actividad: a ? `${a.code} ${a.name}` : q.label ?? q.id.slice(0, 8), valor: q.value, unidad: q.unit };
    });

    await db.delete(quantities).where(inArray(quantities.id, [...removeIds]));
    const podados = await pruneEmptyStructure(projectId);
    await addDecision(projectId, "CANTIDAD", null, "ELIMINACION_MASIVA_CANTIDADES", {
      seleccionadas: rows.length,
      eliminadasConDerivadas: removeIds.size,
      nodosEstructuraRetirados: podados,
      detalle: detalle.slice(0, 25),
      nota: note ?? null,
    }, actor);

    result.eliminadas = removeIds.size;
    return NextResponse.json({ ...result, nodosEstructuraRetirados: podados });
  }

  for (const q of rows) {
    if (action === "validate") {
      if (q.value === null) {
        result.omitidas++;
        result.motivos.push(`Sin valor: requiere medición manual (${q.label ?? q.id.slice(0, 8)})`);
        continue;
      }
      await db.update(quantities).set({
        status: "VALIDADA", validatedBy: actor ?? null, validatedAt: new Date(),
        note: note ?? q.note,
      }).where(eq(quantities.id, q.id));
      if (q.activityId) await ensureStructureNodes(projectId, q.activityId);
      await addDecision(projectId, "CANTIDAD", q.id, "VALIDO_CANTIDAD", {
        valor: q.value, unidad: q.unit, metodo: q.method, enLote: true, nota: note ?? null,
      }, actor);
      result.validadas++;
    } else if (action === "reject") {
      await db.update(quantities).set({ status: "RECHAZADA" }).where(eq(quantities.id, q.id));
      await addDecision(projectId, "CANTIDAD", q.id, "RECHAZO_CANTIDAD", {
        valor: q.value, unidad: q.unit, enLote: true, nota: note ?? null,
      }, actor);
      result.rechazadas++;
    } else {
      return NextResponse.json({ error: `Acción no soportada: ${action}` }, { status: 400 });
    }
  }

  await addDecision(projectId, "CANTIDAD", null,
    action === "validate" ? "VALIDACION_MASIVA_CANTIDADES" : "RECHAZO_MASIVO_CANTIDADES",
    { seleccionadas: rows.length, ...result, nota: note ?? null }, actor);

  return NextResponse.json(result);
}
