import { NextResponse } from "next/server";
import { db } from "@/db";
import { budgetProjects, budgetItems, budgetRevisions } from "@/db/schema";
import { desc, eq, sql } from "drizzle-orm";
import { ensureBudgetMasterSeeded } from "@/lib/budget/sample-data";

export async function GET() {
  await ensureBudgetMasterSeeded();
  const rows = await db.select().from(budgetProjects).orderBy(desc(budgetProjects.updatedAt));

  const enriched = await Promise.all(
    rows.map(async (p) => {
      const items = await db
        .select({
          directCost: budgetItems.directCost,
          status: budgetItems.status,
          unitCost: budgetItems.unitCost,
          priceReviewRequired: budgetItems.priceReviewRequired,
        })
        .from(budgetItems)
        .where(eq(budgetItems.projectId, p.id));

      const [revs] = await db
        .select({ n: sql<number>`count(*)::int` })
        .from(budgetRevisions)
        .where(eq(budgetRevisions.projectId, p.id));

      const directCostTotal = Math.round(items.reduce((acc, it) => acc + (it.directCost || 0), 0) * 100) / 100;
      const st = p.settings || {};
      const admin = (st.administracion ?? 18) / 100;
      const imp = (st.imprevistos ?? 3) / 100;
      const util = (st.utilidad ?? 5) / 100;
      const iva = (st.iva ?? 19) / 100;

      const vAdmin = directCostTotal * admin;
      const vImp = directCostTotal * imp;
      const vUtil = directCostTotal * util;

      const bases = st.ivaBases || ["UTILIDAD"];
      let baseIva = 0;
      if (bases.includes("DIRECTO")) baseIva += directCostTotal;
      if (bases.includes("ADMINISTRACION")) baseIva += vAdmin;
      if (bases.includes("IMPREVISTOS")) baseIva += vImp;
      if (bases.includes("UTILIDAD")) baseIva += vUtil;

      const vIva = baseIva * iva;
      const totalBudget = Math.round((directCostTotal + vAdmin + vImp + vUtil + vIva) * 100) / 100;

      return {
        ...p,
        stats: {
          totalActivities: items.length,
          withApu: items.filter((it) => it.status === "APU_ASIGNADO" || it.status === "CANTIDAD_MODIFICADA").length,
          withoutApu: items.filter((it) => it.status === "SIN_APU" || it.status === "PRECIO_IMPORTADO").length,
          pendingPriceReview: items.filter((it) => it.priceReviewRequired).length,
          pendingRevision: items.filter((it) => it.status === "REVISION_PENDIENTE").length,
          revisionsCount: revs?.n ?? 0,
          totalDirectCost: directCostTotal,
          totalBudget,
        },
      };
    })
  );

  return NextResponse.json({ projects: enriched });
}

export async function POST(req: Request) {
  await ensureBudgetMasterSeeded();
  const body = await req.json();
  const { code, name, client, location, region, priceDate, description, currency } = body || {};

  if (!code || !name) {
    return NextResponse.json({ error: "Código y nombre son obligatorios." }, { status: 400 });
  }

  const [project] = await db
    .insert(budgetProjects)
    .values({
      code: String(code).trim().toUpperCase(),
      name: String(name).trim(),
      client: client || null,
      location: location || null,
      region: region || location || "COLOMBIA",
      priceDate: priceDate ? new Date(priceDate) : new Date(),
      description: description || null,
      currency: currency || "COP",
      status: "ACTIVO",
      settings: {
        administracion: 18,
        imprevistos: 3,
        utilidad: 5,
        iva: 19,
        ivaBases: ["UTILIDAD"],
        currency: currency || "COP",
      },
    })
    .returning();

  return NextResponse.json({ project });
}
