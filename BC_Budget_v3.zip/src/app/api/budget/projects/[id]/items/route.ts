import { NextResponse } from "next/server";
import { db } from "@/db";
import { budgetItems, masterApus, apuItems, masterInsumos, budgetDecisions, type BudgetItemStatus } from "@/db/schema";
import { eq } from "drizzle-orm";

export async function PATCH(req: Request, ctx: { params: Promise<{ id: string }> }) {
  const { id: projectId } = await ctx.params;
  const body = await req.json();
  const { itemId, action, apuId, quantityOverride, overrideReason, customApu, notes, actor } = body || {};

  if (!itemId) {
    return NextResponse.json({ error: "itemId es obligatorio." }, { status: 400 });
  }

  const [item] = await db.select().from(budgetItems).where(eq(budgetItems.id, itemId)).limit(1);
  if (!item || item.projectId !== projectId) {
    return NextResponse.json({ error: "Ítem de presupuesto no encontrado." }, { status: 404 });
  }

  /* --- ASIGNAR APU MAESTRO --- */
  if (action === "assign_apu") {
    if (!apuId) return NextResponse.json({ error: "apuId requerido." }, { status: 400 });
    const [apu] = await db.select().from(masterApus).where(eq(masterApus.id, apuId)).limit(1);
    if (!apu) return NextResponse.json({ error: "APU no encontrado." }, { status: 404 });

    const unitCost = apu.unitCost || 0;
    const directCost = Math.round(item.finalQuantity * unitCost * 100) / 100;
    const status: BudgetItemStatus = item.quantityOverride !== null ? "CANTIDAD_MODIFICADA" : "APU_ASIGNADO";

    await db
      .update(budgetItems)
      .set({
        apuId: apu.id,
        customApu: null,
        unitCost,
        directCost,
        priceReviewRequired: false,
        status,
        updatedAt: new Date(),
      })
      .where(eq(budgetItems.id, itemId));

    await db.insert(budgetDecisions).values({
      projectId,
      entityType: "ITEM_PRESUPUESTO",
      entityId: itemId,
      action: "ASIGNO_APU_MAESTRO",
      detail: {
        actividad: `${item.activityCode} ${item.activityName}`,
        apu: `${apu.code} ${apu.name}`,
        costoUnitario: unitCost,
        costoDirecto: directCost,
      },
      actor: actor || null,
    });

    return NextResponse.json({ ok: true, unitCost, directCost, status });
  }

  /* --- MODIFICAR CANTIDAD EN BUDGET (CON TRAZABILIDAD) --- */
  if (action === "override_quantity") {
    const val = quantityOverride !== null && quantityOverride !== undefined ? Number(quantityOverride) : null;
    const finalQuantity = val !== null && isFinite(val) ? val : item.quantityBcq;
    const directCost = Math.round(finalQuantity * item.unitCost * 100) / 100;
    const status: BudgetItemStatus = val !== null && Math.abs(val - item.quantityBcq) > 0.0001
      ? "CANTIDAD_MODIFICADA"
      : item.apuId ? "APU_ASIGNADO" : "SIN_APU";

    await db
      .update(budgetItems)
      .set({
        quantityOverride: val,
        overrideReason: overrideReason || null,
        finalQuantity,
        directCost,
        status,
        updatedAt: new Date(),
      })
      .where(eq(budgetItems.id, itemId));

    await db.insert(budgetDecisions).values({
      projectId,
      entityType: "ITEM_PRESUPUESTO",
      entityId: itemId,
      action: "AJUSTO_CANTIDAD_EN_PRESUPUESTO",
      detail: {
        actividad: `${item.activityCode} ${item.activityName}`,
        cantidadOriginalBCQ: item.quantityBcq,
        cantidadAjustadaBudget: val,
        motivo: overrideReason || "Ajuste profesional de presupuestación",
        costoDirectoAnterior: item.directCost,
        costoDirectoNuevo: directCost,
      },
      actor: actor || null,
    });

    return NextResponse.json({ ok: true, finalQuantity, directCost, status });
  }

  /* --- ASIGNAR APU PERSONALIZADO PARA ESTA LÍNEA --- */
  if (action === "custom_apu") {
    if (!customApu) return NextResponse.json({ error: "customApu requerido." }, { status: 400 });
    const unitCost = Number(customApu.unitCost) || 0;
    const directCost = Math.round(item.finalQuantity * unitCost * 100) / 100;
    const status: BudgetItemStatus = item.quantityOverride !== null ? "CANTIDAD_MODIFICADA" : "APU_ASIGNADO";

    await db
      .update(budgetItems)
      .set({
        apuId: null,
        customApu,
        unitCost,
        directCost,
        priceReviewRequired: false,
        status,
        updatedAt: new Date(),
      })
      .where(eq(budgetItems.id, itemId));

    await db.insert(budgetDecisions).values({
      projectId,
      entityType: "ITEM_PRESUPUESTO",
      entityId: itemId,
      action: "ASIGNO_APU_PERSONALIZADO",
      detail: {
        actividad: `${item.activityCode} ${item.activityName}`,
        apuName: customApu.name,
        componentes: customApu.components?.length || 0,
        unitCost,
        directCost,
      },
      actor: actor || null,
    });

    return NextResponse.json({ ok: true, unitCost, directCost, status });
  }

  /* --- EDITAR NOTAS --- */
  if (action === "edit_notes") {
    await db
      .update(budgetItems)
      .set({ notes: notes || null, updatedAt: new Date() })
      .where(eq(budgetItems.id, itemId));
    return NextResponse.json({ ok: true });
  }

  return NextResponse.json({ error: `Acción no soportada: ${action}` }, { status: 400 });
}
