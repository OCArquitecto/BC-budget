import { NextResponse } from "next/server";
import { db } from "@/db";
import { budgetRevisions } from "@/db/schema";
import { desc, eq } from "drizzle-orm";
import type { BcqElement, BcqQuantity } from "@/lib/bcq";

export async function GET(_req: Request, ctx: { params: Promise<{ id: string }> }) {
  const { id: projectId } = await ctx.params;
  const [rev] = await db.select().from(budgetRevisions)
    .where(eq(budgetRevisions.projectId, projectId))
    .orderBy(desc(budgetRevisions.revisionNumber)).limit(1);
  if (!rev) return NextResponse.json({ elements: [], revision: null });
  const snap = (rev.snapshotData ?? {}) as { elements?: BcqElement[]; quantities?: BcqQuantity[] };
  const els = snap.elements ?? [];
  const qs = snap.quantities ?? [];
  const byGlobal = new Map<string, { id: string; code: string; name: string; status: string }[]>();
  for (const q of qs) {
    if (q.status === "RECHAZADA") continue;
    for (const gid of q.elementGlobalIds ?? []) {
      const list = byGlobal.get(gid) ?? [];
      if (!list.some((a) => a.id === q.activityId)) list.push({ id: q.activityId, code: q.activityCode, name: q.activityName, status: q.status });
      byGlobal.set(gid, list);
    }
  }
  const elements = els.map((e, i) => ({
    id: e.id || `bcq-element-${i}`,
    globalId: e.globalId,
    name: e.name,
    ifcClass: e.ifcClass,
    typeName: e.typeName,
    semanticType: e.semanticType,
    level: e.level,
    material: e.material,
    dimensions: e.dimensions ?? null,
    dimensionSources: e.dimensionSources ?? null,
    geometry: e.geometry ? {
      kind:   e.geometry.kind   ?? "BCQ",
      size:   e.geometry.size   ?? e.geometry.oriented?.size   ?? [1, 1, 1],
      center: e.geometry.center ?? e.geometry.oriented?.center ?? [i * 1.5, 0, 0],
      yaw:    e.geometry.yaw    ?? 0,
      oriented: e.geometry.oriented ? {
        size:   e.geometry.oriented.size,
        center: e.geometry.oriented.center ?? e.geometry.center ?? [i * 1.5, 0, 0],
        axes:   e.geometry.oriented.axes   ?? [[1,0,0],[0,1,0],[0,0,1]],
      } : e.geometry.size ? {
        // Si hay size/center pero no oriented, crear un oriented sintético
        // para que Viewer3D pueda renderizar la caja orientada
        size:   e.geometry.size,
        center: e.geometry.center ?? [i * 1.5, 0, 0],
        axes:   [[1,0,0],[0,1,0],[0,0,1]] as [[number,number,number],[number,number,number],[number,number,number]],
      } : undefined,
    } : null,
    activities: e.globalId ? byGlobal.get(e.globalId) ?? [] : [],
  }));
  return NextResponse.json({ elements, revision: rev.revisionName, packageId: rev.packageId });
}
