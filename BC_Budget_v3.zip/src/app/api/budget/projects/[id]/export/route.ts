import { NextResponse } from "next/server";
import { db } from "@/db";
import {
  budgetProjects, budgetNodes, budgetItems, masterApus, apuItems,
  masterInsumos, budgetDecisions, budgetRevisions,
} from "@/db/schema";
import { eq, asc, inArray } from "drizzle-orm";
import { sortByCode } from "@/lib/codes";
import * as XLSX from "xlsx";

export async function GET(req: Request, ctx: { params: Promise<{ id: string }> }) {
  const { id: projectId } = await ctx.params;
  const url = new URL(req.url);
  const format = url.searchParams.get("format") || "xlsx";
  const visibleLevels = new Set((url.searchParams.get("levels") || "actividad,seccion,capitulo,total").split(","));

  const [project] = await db.select().from(budgetProjects).where(eq(budgetProjects.id, projectId)).limit(1);
  if (!project) return NextResponse.json({ error: "Proyecto no encontrado" }, { status: 404 });

  const nodes = await db.select().from(budgetNodes).where(eq(budgetNodes.projectId, projectId));
  const items = await db.select().from(budgetItems).where(eq(budgetItems.projectId, projectId));
  const itemByNodeId = new Map(items.map((it) => [it.nodeId, it]));

  const chapters = sortByCode(nodes.filter((n) => n.kind === "CAPITULO"), (n) => n.code);
  const sections = sortByCode(nodes.filter((n) => n.kind === "SECCION"), (n) => n.code);
  const actNodes = sortByCode(nodes.filter((n) => n.kind === "ACTIVIDAD"), (n) => n.code);

  const st = project.settings || {};
  const adminPct = (st.administracion ?? 18) / 100;
  const impPct = (st.imprevistos ?? 3) / 100;
  const utilPct = (st.utilidad ?? 5) / 100;
  const ivaPct = (st.iva ?? 19) / 100;

  // Filas planas para Excel/CSV
  const rows: {
    item: string;
    descripcion: string;
    unidad: string;
    cantidad: number | string;
    valorUnitario: number | string;
    valorTotal: number | string;
    tipo: string;
  }[] = [];

  let directCostTotal = 0;

  for (const ch of chapters) {
    const chSectionIds = sections.filter((s) => s.parentId === ch.id).map((s) => s.id);
    const chNodeIds = actNodes.filter((a) => a.parentId && chSectionIds.includes(a.parentId)).map((a) => a.id);
    const chapterTotal = items.filter((i) => chNodeIds.includes(i.nodeId)).reduce((n, i) => n + (i.directCost || 0), 0);
    rows.push({
      item: ch.code,
      descripcion: ch.name.toUpperCase(),
      unidad: "",
      cantidad: "",
      valorUnitario: "",
      valorTotal: visibleLevels.has("capitulo") ? Math.round(chapterTotal * 100) / 100 : "",
      tipo: "CAPITULO",
    });

    const chSecs = sections.filter((s) => s.parentId === ch.id);
    for (const sec of chSecs) {
      const secNodeIds = actNodes.filter((a) => a.parentId === sec.id).map((a) => a.id);
      const sectionTotal = items.filter((i) => secNodeIds.includes(i.nodeId)).reduce((n, i) => n + (i.directCost || 0), 0);
      rows.push({
        item: sec.code,
        descripcion: sec.name,
        unidad: "",
        cantidad: "",
        valorUnitario: "",
        valorTotal: visibleLevels.has("seccion") ? Math.round(sectionTotal * 100) / 100 : "",
        tipo: "SECCION",
      });

      const secActs = actNodes.filter((a) => a.parentId === sec.id);
      for (const act of secActs) {
        const item = itemByNodeId.get(act.id);
        const qty = item?.finalQuantity || 0;
        const uCost = item?.unitCost || 0;
        const dCost = item?.directCost || 0;
        directCostTotal += dCost;

        rows.push({
          item: act.code,
          descripcion: act.name,
          unidad: act.unit || item?.unit || "",
          cantidad: qty,
          valorUnitario: visibleLevels.has("actividad") ? uCost : "",
          valorTotal: visibleLevels.has("actividad") ? dCost : "",
          tipo: "ACTIVIDAD",
        });
      }
    }
  }

  const vAdmin = Math.round(directCostTotal * adminPct * 100) / 100;
  const vImp = Math.round(directCostTotal * impPct * 100) / 100;
  const vUtil = Math.round(directCostTotal * utilPct * 100) / 100;

  const bases = st.ivaBases || ["UTILIDAD"];
  let baseIva = 0;
  if (bases.includes("DIRECTO")) baseIva += directCostTotal;
  if (bases.includes("ADMINISTRACION")) baseIva += vAdmin;
  if (bases.includes("IMPREVISTOS")) baseIva += vImp;
  if (bases.includes("UTILIDAD")) baseIva += vUtil;

  const vIva = Math.round(baseIva * ivaPct * 100) / 100;
  const totalBudget = Math.round((directCostTotal + vAdmin + vImp + vUtil + vIva) * 100) / 100;

  /* --- EXPORTAR EXCEL (.xlsx) --- */
  if (format === "xlsx") {
    const wb = XLSX.utils.book_new();

    // 1. Hoja Presupuesto
    const presData = [
      ["PRESUPUESTO GENERAL DE OBRA — BIMCOST BUDGET"],
      [`PROYECTO: ${project.name} (${project.code})`],
      [`CLIENTE: ${project.client || "—"} | UBICACIÓN: ${project.location || "—"}`],
      [`MONEDA: ${project.currency || "COP"}`],
      [],
      ["ÍTEM", "DESCRIPCIÓN DE LA ACTIVIDAD", "UNIDAD", "CANTIDAD", "VALOR UNITARIO", "VALOR TOTAL"],
      ...rows.map((r) => [r.item, r.descripcion, r.unidad, r.cantidad, r.valorUnitario, r.valorTotal]),
      [],
      ["", "", "", "", "COSTO DIRECTO:", visibleLevels.has("total") ? directCostTotal : ""],
      ["", "", "", "", `ADMINISTRACIÓN (${st.administracion || 18}%):`, visibleLevels.has("total") ? vAdmin : ""],
      ["", "", "", "", `IMPREVISTOS (${st.imprevistos || 3}%):`, visibleLevels.has("total") ? vImp : ""],
      ["", "", "", "", `UTILIDAD (${st.utilidad || 5}%):`, visibleLevels.has("total") ? vUtil : ""],
      ["", "", "", "", `IVA (${st.iva || 19}% sobre ${bases.join("+")}):`, visibleLevels.has("total") ? vIva : ""],
      ["", "", "", "", "TOTAL PRESUPUESTO:", visibleLevels.has("total") ? totalBudget : ""],
    ];

    const wsPres = XLSX.utils.aoa_to_sheet(presData);
    XLSX.utils.book_append_sheet(wb, wsPres, "Presupuesto General");

    const buf = XLSX.write(wb, { type: "buffer", bookType: "xlsx" });

    return new NextResponse(buf, {
      headers: {
        "Content-Type": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        "Content-Disposition": `attachment; filename="${project.code}_Presupuesto_Budget.xlsx"`,
      },
    });
  }

  /* --- EXPORTAR CSV --- */
  if (format === "csv") {
    const csvLines = [
      "Item;Descripcion;Unidad;Cantidad;ValorUnitario;ValorTotal",
      ...rows.map((r) =>
        [r.item, `"${r.descripcion.replace(/"/g, '""')}"`, r.unidad, r.cantidad, r.valorUnitario, r.valorTotal].join(";")
      ),
      `TOTAL_COSTO_DIRECTO;;;;;${visibleLevels.has("total") ? directCostTotal : ""}`,
      `TOTAL_PRESUPUESTO_CON_AIU;;;;;${visibleLevels.has("total") ? totalBudget : ""}`,
    ];

    return new NextResponse(csvLines.join("\n"), {
      headers: {
        "Content-Type": "text/csv; charset=utf-8",
        "Content-Disposition": `attachment; filename="${project.code}_Presupuesto.csv"`,
      },
    });
  }

  /* --- EXPORTAR JSON (.bcb / API Contract) --- */
  return NextResponse.json({
    format: "BCB",
    version: "1.0",
    project,
    financialSummary: {
      costoDirecto: directCostTotal,
      administracion: vAdmin,
      imprevistos: vImp,
      utilidad: vUtil,
      baseIva,
      iva: vIva,
      totalPresupuesto: totalBudget,
      currency: project.currency || "COP",
    },
    items,
  });
}
