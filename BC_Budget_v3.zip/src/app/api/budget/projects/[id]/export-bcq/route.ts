/* ================================================================== */
/*  Export: .bcq enriquecido con capa "budget"                         */
/*                                                                      */
/*  Genera un archivo .bcq que contiene la capa "quantity" original     */
/*  (tomada del snapshot guardado al importar) PLUS la capa "budget"   */
/*  con el WBS completo, APUs usados, explosión de insumos, AIU y      */
/*  resumen financiero.                                                 */
/*                                                                      */
/*  Compatible con:                                                     */
/*   - BC Quantity  (lee la capa quantity tal cual la exportó)          */
/*   - BC Budget    (re-importación idempotente)                        */
/*   - BC Planning  (consume budget/explosion.ndjson + quantity layers) */
/* ================================================================== */
import { NextResponse } from "next/server";
import { createHash, randomUUID } from "node:crypto";
import { deflateRawSync, crc32 as zlibCrc32 } from "node:zlib";
import { db } from "@/db";
import {
  budgetProjects, budgetNodes, budgetItems, budgetRevisions,
  masterApus, apuItems, masterInsumos,
} from "@/db/schema";
import { asc, desc, eq, inArray } from "drizzle-orm";
import { sortByCode } from "@/lib/codes";

/* ------------------------------------------------------------------ */
/* ZIP sin dependencias externas (mismo motor que en Quantity)          */
/* ------------------------------------------------------------------ */
function crc32b(buf: Buffer): number {
  const c = zlibCrc32(buf);
  return typeof c === "bigint" ? Number(c) : c;
}
function dosDateTime(d: Date) {
  const time = ((d.getHours() & 0x1f) << 11) | ((d.getMinutes() & 0x3f) << 5) | ((d.getSeconds() >> 1) & 0x1f);
  const date = (((d.getFullYear() - 1980) & 0x7f) << 9) | (((d.getMonth() + 1) & 0xf) << 5) | (d.getDate() & 0x1f);
  return { time, date };
}
function buildZip(entries: { path: string; data: Buffer; store?: boolean }[]): Buffer {
  const now = new Date();
  const { time, date } = dosDateTime(now);
  const locals: Buffer[] = [];
  const centrals: Buffer[] = [];
  let offset = 0;
  for (const e of entries) {
    const name = Buffer.from(e.path, "utf8");
    const crc = crc32b(e.data);
    const comp = e.store ? e.data : deflateRawSync(e.data);
    const useStore = e.store || comp.length >= e.data.length;
    const finalData = useStore ? e.data : comp;
    const method = useStore ? 0 : 8;
    const loc = Buffer.alloc(30);
    loc.writeUInt32LE(0x04034b50, 0); loc.writeUInt16LE(20, 4); loc.writeUInt16LE(0x0800, 6);
    loc.writeUInt16LE(method, 8); loc.writeUInt16LE(time, 10); loc.writeUInt16LE(date, 12);
    loc.writeUInt32LE(crc, 14); loc.writeUInt32LE(finalData.length, 18);
    loc.writeUInt32LE(e.data.length, 22); loc.writeUInt16LE(name.length, 26); loc.writeUInt16LE(0, 28);
    locals.push(loc, name, finalData);
    const cen = Buffer.alloc(46);
    cen.writeUInt32LE(0x02014b50, 0); cen.writeUInt16LE(20, 4); cen.writeUInt16LE(20, 6);
    cen.writeUInt16LE(0x0800, 8); cen.writeUInt16LE(method, 10); cen.writeUInt16LE(time, 12);
    cen.writeUInt16LE(date, 14); cen.writeUInt32LE(crc, 16); cen.writeUInt32LE(finalData.length, 20);
    cen.writeUInt32LE(e.data.length, 24); cen.writeUInt16LE(name.length, 28); cen.writeUInt16LE(0, 30);
    cen.writeUInt16LE(0, 32); cen.writeUInt16LE(0, 34); cen.writeUInt16LE(0, 36);
    cen.writeUInt32LE((0o100644 << 16) >>> 0, 38); cen.writeUInt32LE(offset, 42);
    centrals.push(cen, name);
    offset += loc.length + name.length + finalData.length;
  }
  const cenBuf = Buffer.concat(centrals);
  const eocd = Buffer.alloc(22);
  eocd.writeUInt32LE(0x06054b50, 0); eocd.writeUInt16LE(0, 4); eocd.writeUInt16LE(0, 6);
  eocd.writeUInt16LE(entries.length, 8); eocd.writeUInt16LE(entries.length, 10);
  eocd.writeUInt32LE(cenBuf.length, 12); eocd.writeUInt32LE(offset, 16); eocd.writeUInt16LE(0, 20);
  return Buffer.concat([...locals, cenBuf, eocd]);
}

/* ------------------------------------------------------------------ */
/* Helpers                                                              */
/* ------------------------------------------------------------------ */
function sha256hex(text: string): string {
  return createHash("sha256").update(text, "utf8").digest("hex");
}
function toJson(v: unknown): string { return JSON.stringify(v, null, 2) + "\n"; }
function toNdjson(arr: unknown[]): string {
  return arr.length ? arr.map((l) => JSON.stringify(l)).join("\n") + "\n" : "";
}

/* ------------------------------------------------------------------ */
/* Ruta GET                                                             */
/* ------------------------------------------------------------------ */
export async function GET(_req: Request, ctx: { params: Promise<{ id: string }> }) {
  const { id: projectId } = await ctx.params;

  /* 1. Proyecto */
  const [project] = await db.select().from(budgetProjects)
    .where(eq(budgetProjects.id, projectId)).limit(1);
  if (!project) return NextResponse.json({ error: "Proyecto no encontrado" }, { status: 404 });

  /* 2. Última revisión con snapshot (tiene la capa quantity original) */
  const [lastRev] = await db.select().from(budgetRevisions)
    .where(eq(budgetRevisions.projectId, projectId))
    .orderBy(desc(budgetRevisions.revisionNumber)).limit(1);

  const snap = (lastRev?.snapshotData ?? {}) as Record<string, unknown>;

  /* 3. WBS completo */
  const nodes = await db.select().from(budgetNodes)
    .where(eq(budgetNodes.projectId, projectId)).orderBy(asc(budgetNodes.sortOrder));
  const items = await db.select().from(budgetItems)
    .where(eq(budgetItems.projectId, projectId));
  const itemByNodeId = new Map(items.map((it) => [it.nodeId, it]));

  /* 4. APUs usados */
  const apuIds = [...new Set(items.map((it) => it.apuId).filter((id): id is string => !!id))];
  const apuRows = apuIds.length
    ? await db.select().from(masterApus).where(inArray(masterApus.id, apuIds))
    : [];
  const apuById = new Map(apuRows.map((a) => [a.id, a]));
  const apuComponentsAll = apuIds.length
    ? await db.select().from(apuItems).where(inArray(apuItems.apuId, apuIds)).orderBy(asc(apuItems.sortOrder))
    : [];
  const apuCompsByApu = new Map<string, typeof apuComponentsAll>();
  for (const c of apuComponentsAll) {
    const list = apuCompsByApu.get(c.apuId) ?? [];
    list.push(c); apuCompsByApu.set(c.apuId, list);
  }

  /* 5. Catálogo de insumos completo (compartido en el ecosistema) */
  const insumos = await db.select().from(masterInsumos);
  const insumoById = new Map(insumos.map((i) => [i.id, i]));

  /* 6. AIU */
  const st = (project.settings ?? {}) as Record<string, unknown>;
  const adminPct  = (st.administracion as number ?? 18) / 100;
  const impPct    = (st.imprevistos   as number ?? 3)  / 100;
  const utilPct   = (st.utilidad      as number ?? 5)  / 100;
  const ivaPct    = (st.iva           as number ?? 19) / 100;
  const ivaBases  = (st.ivaBases as string[] | undefined) ?? ["UTILIDAD"];

  /* 7. Construir WBS budget con costos */
  const chapters = sortByCode(nodes.filter((n) => n.kind === "CAPITULO"), (n) => n.code);
  const sections = nodes.filter((n) => n.kind === "SECCION");
  const actNodes = nodes.filter((n) => n.kind === "ACTIVIDAD");

  let directCostTotal = 0;
  const wbsItems: object[] = [];

  for (const ch of chapters) {
    const chSecs = sortByCode(sections.filter((s) => s.parentId === ch.id), (s) => s.code);
    for (const sec of chSecs) {
      const secActs = sortByCode(actNodes.filter((a) => a.parentId === sec.id), (a) => a.code);
      for (const act of secActs) {
        const it = itemByNodeId.get(act.id);
        if (!it) continue;
        directCostTotal += it.directCost ?? 0;

        const apuSnap = it.apuId ? apuById.get(it.apuId) ?? null : null;
        const apuComps = it.apuId ? (apuCompsByApu.get(it.apuId) ?? []) : [];

        wbsItems.push({
          capituloCodigo:    ch.code,
          capituloNombre:    ch.name,
          subcapituloCodigo: sec.code,
          subcapituloNombre: sec.name,
          codigo:            act.code,
          nombre:            act.name,
          unidad:            act.unit ?? it.unit,
          cantidadBcq:       it.quantityBcq,
          cantidadFinal:     it.finalQuantity,
          cantidadModificada: it.quantityOverride !== null,
          costoUnitario:     it.unitCost,
          costoDirecto:      it.directCost,
          estado:            it.status,
          fuentes:           (it.sourceMeta as Record<string,unknown>)?.sources ?? [],
          elementCount:      (it.sourceMeta as Record<string,unknown>)?.elementCount ?? 0,
          elementGlobalIds:  (it.sourceMeta as Record<string,unknown>)?.elementGlobalIds ?? [],
          apu: apuSnap ? {
            id:         apuSnap.id,
            codigo:     apuSnap.code,
            nombre:     apuSnap.name,
            unidad:     apuSnap.unit,
            costoUnitario: apuSnap.unitCost,
            componentes: apuComps.map((c) => {
              const ins = c.insumoId ? insumoById.get(c.insumoId) ?? null : null;
              return {
                insumoId:         c.insumoId ?? null,
                codigoInsumo:     ins?.code ?? null,
                descripcion:      c.description,
                categoria:        c.category,
                unidad:           c.unit,
                cantidad:         c.quantity,
                desperdicio:      c.wastePercentage,
                precioUnitario:   c.unitPrice,
                subtotal:         c.subtotal,
              };
            }),
          } : it.customApu ? {
            id:         null,
            codigo:     `CUSTOM-${act.code}`,
            nombre:     `APU personalizado · ${act.name}`,
            unidad:     act.unit ?? it.unit,
            costoUnitario: it.unitCost,
            componentes: ((it.customApu as {components?: unknown[]}).components ?? []).map((c: unknown) => {
              const comp = c as Record<string,unknown>;
              return {
                insumoId:       null,
                codigoInsumo:   null,
                descripcion:    comp.description ?? "",
                categoria:      comp.category ?? "MATERIAL",
                unidad:         comp.unit ?? "UND",
                cantidad:       comp.quantity ?? 0,
                desperdicio:    comp.wastePercentage ?? 0,
                precioUnitario: comp.unitPrice ?? 0,
                subtotal:       comp.subtotal ?? 0,
              };
            }),
          } : null,
        });
      }
    }
  }

  /* 8. Explosión de insumos */
  const explosionMap = new Map<string, {
    insumoId: string | null;
    codigoInsumo: string;
    nombre: string;
    unidad: string;
    categoria: string;
    precioUnitario: number;
    cantidadTotal: number;
    costoTotal: number;
    actividades: { codigo: string; nombre: string; cantidadActividad: number; consumoUnitario: number; subtotalCantidad: number }[];
  }>();

  const addToExplosion = (
    key: string, insumoId: string | null, code: string, name: string,
    unit: string, cat: string, price: number,
    actCode: string, actName: string, actQty: number, consumption: number
  ) => {
    const totalQty = Math.round(actQty * consumption * 1000) / 1000;
    const totalCost = Math.round(totalQty * price * 100) / 100;
    const cur = explosionMap.get(key) ?? {
      insumoId, codigoInsumo: code, nombre: name, unidad: unit, categoria: cat,
      precioUnitario: price, cantidadTotal: 0, costoTotal: 0, actividades: [],
    };
    cur.cantidadTotal = Math.round((cur.cantidadTotal + totalQty) * 1000) / 1000;
    cur.costoTotal    = Math.round((cur.costoTotal + totalCost) * 100) / 100;
    cur.actividades.push({ codigo: actCode, nombre: actName, cantidadActividad: actQty, consumoUnitario: consumption, subtotalCantidad: totalQty });
    explosionMap.set(key, cur);
  };

  for (const it of items) {
    if (it.finalQuantity <= 0) continue;
    if (it.customApu) {
      for (const c of (it.customApu as { components?: Record<string,unknown>[] }).components ?? []) {
        const consumption = (c.quantity as number) * (1 + (c.wastePercentage as number) / 100);
        const key = `${c.category}::${(c.description as string).trim().toLowerCase()}`;
        addToExplosion(key, null, `INS-${(c.category as string).slice(0,3)}`,
          c.description as string, c.unit as string, c.category as string,
          c.unitPrice as number, it.activityCode, it.activityName, it.finalQuantity, consumption);
      }
    } else if (it.apuId) {
      for (const c of apuCompsByApu.get(it.apuId) ?? []) {
        const ins = c.insumoId ? insumoById.get(c.insumoId) : null;
        const consumption = c.quantity * (1 + c.wastePercentage / 100);
        const price = c.unitPrice || ins?.unitPrice || 0;
        const key = c.insumoId ? `insumo::${c.insumoId}` : `noins::${c.category}::${c.description.trim().toLowerCase()}`;
        addToExplosion(key, c.insumoId ?? null,
          ins?.code ?? `INS-${c.category.slice(0,3)}`,
          c.description || ins?.name || "Insumo",
          c.unit || ins?.unit || "UND", c.category,
          price, it.activityCode, it.activityName, it.finalQuantity, consumption);
      }
    }
  }
  const explosion = [...explosionMap.values()].sort((a, b) => b.costoTotal - a.costoTotal);

  /* 9. Resumen AIU y financiero */
  const dc = Math.round(directCostTotal * 100) / 100;
  const vAdmin = Math.round(dc * adminPct * 100) / 100;
  const vImp   = Math.round(dc * impPct   * 100) / 100;
  const vUtil  = Math.round(dc * utilPct  * 100) / 100;
  let baseIva = 0;
  if (ivaBases.includes("DIRECTO"))         baseIva += dc;
  if (ivaBases.includes("ADMINISTRACION"))  baseIva += vAdmin;
  if (ivaBases.includes("IMPREVISTOS"))     baseIva += vImp;
  if (ivaBases.includes("UTILIDAD"))        baseIva += vUtil;
  const vIva   = Math.round(baseIva * ivaPct * 100) / 100;
  const total  = Math.round((dc + vAdmin + vImp + vUtil + vIva) * 100) / 100;

  const aiu = {
    tasaAdministracion: st.administracion ?? 18,
    tasaImprevistos:    st.imprevistos ?? 3,
    tasaUtilidad:       st.utilidad ?? 5,
    tasaIva:            st.iva ?? 19,
    baseIva:            ivaBases,
    costoDirecto:       dc,
    administracion:     vAdmin,
    imprevistos:        vImp,
    utilidad:           vUtil,
    iva:                vIva,
    totalPresupuesto:   total,
    moneda:             project.currency ?? "COP",
  };

  /* 10. Catálogo de insumos completo para el ecosistema */
  const catalogoInsumos = insumos.map((ins) => ({
    id:            ins.id,
    codigo:        ins.code,
    nombre:        ins.name,
    unidad:        ins.unit,
    categoria:     ins.category,
    precioUnitario: ins.unitPrice,
    moneda:        ins.currency,
    region:        ins.region,
    proveedor:     ins.supplier ?? null,
    fuente:        ins.source   ?? null,
    fechaPrecio:   ins.priceDate?.toISOString() ?? null,
    activo:        ins.active,
  }));

  /* 11. Resumen por capítulo */
  const resumenCapitulos = chapters.map((ch) => {
    const chSecs  = sections.filter((s) => s.parentId === ch.id).map((s) => s.id);
    const chActs  = actNodes.filter((a) => a.parentId && chSecs.includes(a.parentId)).map((a) => a.id);
    const chItems = items.filter((i) => chActs.includes(i.nodeId));
    const dc_ch   = Math.round(chItems.reduce((s, i) => s + (i.directCost ?? 0), 0) * 100) / 100;
    return {
      codigo:       ch.code,
      nombre:       ch.name,
      costoDirecto: dc_ch,
      porcentaje:   dc > 0 ? Math.round((dc_ch / dc) * 10000) / 100 : 0,
      actividades:  chItems.length,
    };
  });

  /* 12. Serializar archivos internos */
  const exportedAt = new Date().toISOString();

  // Capa quantity: se toma el snapshot original guardado al importar el .bcq de Quantity.
  // Si no hay snapshot, se sintetizan los datos desde lo que Budget tiene en BD.
  const quantityProject   = toJson(snap.project   ?? { id: project.id, codigo: project.code, nombre: project.name });
  const quantitySources   = toJson(snap.sources   ?? []);
  const quantityCatalog   = toJson(snap.catalog   ?? []);
  const quantityStructure = toJson(snap.structure  ?? []);
  const quantityQuantities= toNdjson(Array.isArray(snap.quantities) ? snap.quantities : []);
  const quantityElements  = toNdjson(Array.isArray(snap.elements)   ? snap.elements   : []);
  const quantityDecisions = toNdjson(Array.isArray(snap.decisions)  ? snap.decisions  : []);

  // Capa budget
  const budgetItemsJson   = toJson(wbsItems);
  const budgetExplosion   = toNdjson(explosion);
  const budgetAiuJson     = toJson(aiu);
  const budgetSummaryJson = toJson({
    proyecto:  { codigo: project.code, nombre: project.name, cliente: project.client, ubicacion: project.location },
    revision:  lastRev?.revisionName ?? "REV-01",
    packageId: lastRev?.packageId    ?? null,
    resumenCapitulos,
    financiero: aiu,
    exportadoEn: exportedAt,
    producidoPor: "BIMCost Budget",
  });
  const budgetCatalogInsumos = toJson(catalogoInsumos);

  /* 13. Calcular hashes */
  const files: { path: string; text: string }[] = [
    // Capa quantity
    { path: "project.json",                     text: quantityProject   },
    { path: "sources.json",                     text: quantitySources   },
    { path: "catalog-snapshot.json",            text: quantityCatalog   },
    { path: "structure.json",                   text: quantityStructure },
    { path: "quantities.ndjson",                text: quantityQuantities },
    { path: "elements.ndjson",                  text: quantityElements  },
    { path: "traceability/decisions.ndjson",    text: quantityDecisions },
    // Capa budget
    { path: "budget/items.json",                text: budgetItemsJson   },
    { path: "budget/explosion.ndjson",          text: budgetExplosion   },
    { path: "budget/aiu.json",                  text: budgetAiuJson     },
    { path: "budget/summary.json",              text: budgetSummaryJson },
    { path: "budget/catalogo-insumos.json",     text: budgetCatalogInsumos },
  ];

  const archivos = files.map((f) => ({
    ruta:   f.path,
    sha256: sha256hex(f.text),
    bytes:  Buffer.byteLength(f.text, "utf8"),
    capa:   f.path.startsWith("budget/") ? "budget" : "quantity",
  }));

  /* 14. Manifest enriquecido (declara ambas capas) */
  const manifest = {
    formato:              "BCQ",
    version:              "1.0",
    paqueteId:            randomUUID(),
    proyecto:             { id: project.sourceBcq?.projectId ?? project.id, revision: lastRev?.revisionNumber ?? 1 },
    proyectoCodigo:       project.code,
    proyectoNombre:       project.name,
    exportadoEnUtc:       exportedAt,
    aplicacionProductora: "BIMCost Budget",
    productorVersion:     "1.0.0",
    productorBuild:       "2026-release",
    modoExportacion:      "SOLO_VALIDADAS",
    capas:                ["quantity", "budget"],
    conteos: {
      fuentes:       Array.isArray(snap.sources)   ? (snap.sources as unknown[]).length : 0,
      actividades:   wbsItems.length,
      lineasCantidad: Array.isArray(snap.quantities) ? (snap.quantities as unknown[]).length : 0,
      elementos:     Array.isArray(snap.elements)   ? (snap.elements  as unknown[]).length : 0,
      decisiones:    Array.isArray(snap.decisions)  ? (snap.decisions as unknown[]).length : 0,
      insumos:       insumos.length,
    },
    financiero: {
      costoDirecto:     dc,
      totalPresupuesto: total,
      moneda:           project.currency ?? "COP",
    },
    archivos,
  };
  const manifestText = toJson(manifest);

  /* 15. Construir el ZIP */
  const schemaStub = toJson({
    "$schema": "https://json-schema.org/draft/2020-12/schema",
    "title": "BIMCost Quantity Package (BCQ) 1.0 — enriquecido por Budget",
    "capas": ["quantity", "budget"],
    "nota": "Consulte BCQ-1.0.md en el repositorio de BIMCost para la especificación completa.",
  });

  const zipEntries: { path: string; data: Buffer; store?: boolean }[] = [
    { path: "mimetype",  data: Buffer.from("application/vnd.bimcost.quantity+zip", "utf8"), store: true },
    { path: "manifest.json", data: Buffer.from(manifestText, "utf8") },
    ...files.map((f) => ({ path: f.path, data: Buffer.from(f.text, "utf8") })),
    { path: "schemas/bcq-1.0.schema.json", data: Buffer.from(schemaStub, "utf8") },
  ];

  const zipBuffer = buildZip(zipEntries);

  /* 16. Nombre del archivo */
  const safeCode = project.code.replace(/[^\w.-]+/g, "_") || "proyecto";
  const rev = lastRev?.revisionName ?? "REV-01";
  const fileName = `${safeCode}_Budget_${rev}.bcq`;

  return new NextResponse(new Uint8Array(zipBuffer), {
    status: 200,
    headers: {
      "Content-Type": "application/vnd.bimcost.quantity+zip",
      "Content-Disposition": `attachment; filename="${fileName}"`,
      "Content-Length": String(zipBuffer.length),
    },
  });
}
