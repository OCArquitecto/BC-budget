import { NextResponse } from "next/server";
import { db } from "@/db";
import { budgetProjects, budgetItems, apuItems, masterInsumos, type InsumoCategory } from "@/db/schema";
import { eq, inArray } from "drizzle-orm";

export interface ResourceExplosionItem {
  insumoId?: string;
  code: string;
  name: string;
  unit: string;
  category: InsumoCategory;
  unitPrice: number;
  totalQuantity: number;
  totalCost: number;
  activitiesCount: number;
  participatingActivities: {
    activityCode: string;
    activityName: string;
    activityQuantity: number;
    unitConsumption: number;
    subtotalQuantity: number;
  }[];
}

export async function GET(_req: Request, ctx: { params: Promise<{ id: string }> }) {
  const { id: projectId } = await ctx.params;
  const [project] = await db.select().from(budgetProjects).where(eq(budgetProjects.id, projectId)).limit(1);
  if (!project) return NextResponse.json({ error: "Proyecto no encontrado" }, { status: 404 });

  const items = await db.select().from(budgetItems).where(eq(budgetItems.projectId, projectId));
  const apuIds = items.map((it) => it.apuId).filter((id): id is string => !!id);

  const apuComponents = apuIds.length
    ? await db.select().from(apuItems).where(inArray(apuItems.apuId, apuIds))
    : [];

  const insumos = await db.select().from(masterInsumos);
  const insumoById = new Map(insumos.map((i) => [i.id, i]));

  const explosionMap = new Map<string, ResourceExplosionItem>();

  for (const item of items) {
    if (item.finalQuantity <= 0) continue;

    if (item.customApu) {
      for (const comp of item.customApu.components || []) {
        const key = `${comp.category}:${comp.description.trim().toLowerCase()}`;
        const unitConsumption = comp.quantity * (1 + comp.wastePercentage / 100);
        const totalQtyForLine = Math.round(item.finalQuantity * unitConsumption * 1000) / 1000;
        const totalCostForLine = Math.round(totalQtyForLine * comp.unitPrice * 100) / 100;

        const cur = explosionMap.get(key) ?? {
          code: `INS-${comp.category.slice(0, 3)}`,
          name: comp.description,
          unit: comp.unit,
          category: comp.category,
          unitPrice: comp.unitPrice,
          totalQuantity: 0,
          totalCost: 0,
          activitiesCount: 0,
          participatingActivities: [],
        };
        cur.totalQuantity = Math.round((cur.totalQuantity + totalQtyForLine) * 1000) / 1000;
        cur.totalCost = Math.round((cur.totalCost + totalCostForLine) * 100) / 100;
        cur.activitiesCount++;
        cur.participatingActivities.push({
          activityCode: item.activityCode,
          activityName: item.activityName,
          activityQuantity: item.finalQuantity,
          unitConsumption,
          subtotalQuantity: totalQtyForLine,
        });
        explosionMap.set(key, cur);
      }
    } else if (item.apuId) {
      const comps = apuComponents.filter((c) => c.apuId === item.apuId);
      for (const comp of comps) {
        const ins = comp.insumoId ? insumoById.get(comp.insumoId) : null;
        const key = comp.insumoId ? `insumo:${comp.insumoId}` : `${comp.category}:${comp.description.trim().toLowerCase()}`;
        const unitConsumption = comp.quantity * (1 + comp.wastePercentage / 100);
        const totalQtyForLine = Math.round(item.finalQuantity * unitConsumption * 1000) / 1000;
        const price = comp.unitPrice || ins?.unitPrice || 0;
        const totalCostForLine = Math.round(totalQtyForLine * price * 100) / 100;

        const cur = explosionMap.get(key) ?? {
          insumoId: comp.insumoId || undefined,
          code: ins?.code || `INS-${comp.category.slice(0, 3)}`,
          name: comp.description || ins?.name || "Insumo",
          unit: comp.unit || ins?.unit || "UND",
          category: comp.category,
          unitPrice: price,
          totalQuantity: 0,
          totalCost: 0,
          activitiesCount: 0,
          participatingActivities: [],
        };
        cur.totalQuantity = Math.round((cur.totalQuantity + totalQtyForLine) * 1000) / 1000;
        cur.totalCost = Math.round((cur.totalCost + totalCostForLine) * 100) / 100;
        cur.activitiesCount++;
        cur.participatingActivities.push({
          activityCode: item.activityCode,
          activityName: item.activityName,
          activityQuantity: item.finalQuantity,
          unitConsumption,
          subtotalQuantity: totalQtyForLine,
        });
        explosionMap.set(key, cur);
      }
    }
  }

  const list = [...explosionMap.values()].sort((a, b) => b.totalCost - a.totalCost);

  const byCategory: Record<InsumoCategory, { totalCost: number; itemsCount: number }> = {
    MATERIAL: { totalCost: 0, itemsCount: 0 },
    MANO_DE_OBRA: { totalCost: 0, itemsCount: 0 },
    EQUIPO: { totalCost: 0, itemsCount: 0 },
    TRANSPORTE: { totalCost: 0, itemsCount: 0 },
    SUBCONTRATO: { totalCost: 0, itemsCount: 0 },
  };

  for (const it of list) {
    if (byCategory[it.category]) {
      byCategory[it.category].totalCost += it.totalCost;
      byCategory[it.category].itemsCount++;
    }
  }

  const grandTotal = Math.round(list.reduce((acc, it) => acc + it.totalCost, 0) * 100) / 100;

  return NextResponse.json({
    explosion: list,
    resumenPorCategoria: byCategory,
    granTotalCostoDirecto: grandTotal,
    moneda: project.currency || "COP",
  });
}
