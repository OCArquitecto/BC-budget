import { NextResponse } from "next/server";
import { db } from "@/db";
import { budgetNodes, budgetItems, budgetDecisions } from "@/db/schema";
import { and, eq, inArray } from "drizzle-orm";

export async function POST(req: Request, ctx: { params: Promise<{ id: string }> }) {
  const { id: projectId } = await ctx.params;
  const body = await req.json();
  const { kind, parentId, code, name, unit, quantity, referenceUnitPrice, actor } = body || {};
  if (!["CAPITULO", "SECCION", "ACTIVIDAD"].includes(kind) || !code || !name) {
    return NextResponse.json({ error: "Tipo, código y nombre son obligatorios." }, { status: 400 });
  }
  if (kind !== "CAPITULO" && !parentId) {
    return NextResponse.json({ error: "Debe seleccionar el nodo padre." }, { status: 400 });
  }
  const [node] = await db.insert(budgetNodes).values({
    projectId, parentId: kind === "CAPITULO" ? null : parentId,
    kind, code: String(code).trim(), name: String(name).trim(),
    activityId: kind === "ACTIVIDAD" ? `manual:${projectId}:${code}` : null,
    unit: kind === "ACTIVIDAD" ? String(unit || "UND").toUpperCase() : null,
    sortOrder: Number(body.sortOrder) || 0,
  }).returning();

  let item = null;
  if (kind === "ACTIVIDAD") {
    const qty = Number(quantity) || 0;
    const ref = Number(referenceUnitPrice) || 0;
    [item] = await db.insert(budgetItems).values({
      projectId, nodeId: node.id, activityCode: node.code, activityName: node.name,
      unit: node.unit || "UND", quantityBcq: 0, quantityOverride: qty,
      overrideReason: "Actividad añadida manualmente en BC Budget",
      finalQuantity: qty, referenceUnitPrice: ref,
      referencePriceSource: ref > 0 ? "INGRESO_MANUAL_BUDGET" : null,
      priceReviewRequired: true, unitCost: ref, directCost: qty * ref,
      status: ref > 0 ? "PRECIO_IMPORTADO" : "SIN_APU",
    }).returning();
  }
  await db.insert(budgetDecisions).values({
    projectId, entityType: "ESTRUCTURA", entityId: node.id,
    action: `CREO_${kind}`, detail: { code: node.code, name: node.name, parentId, quantity, referenceUnitPrice }, actor: actor || null,
  });
  return NextResponse.json({ node, item });
}

export async function PATCH(req: Request, ctx: { params: Promise<{ id: string }> }) {
  const { id: projectId } = await ctx.params;
  const body = await req.json();
  const { nodeId, parentId, code, name, unit, actor } = body || {};
  if (!nodeId) return NextResponse.json({ error: "nodeId requerido." }, { status: 400 });
  const [before] = await db.select().from(budgetNodes).where(and(eq(budgetNodes.id, nodeId), eq(budgetNodes.projectId, projectId))).limit(1);
  if (!before) return NextResponse.json({ error: "Nodo no encontrado." }, { status: 404 });
  const patch: Partial<typeof budgetNodes.$inferInsert> = {};
  if (parentId !== undefined) patch.parentId = parentId || null;
  if (typeof code === "string" && code.trim()) patch.code = code.trim();
  if (typeof name === "string" && name.trim()) patch.name = name.trim();
  if (typeof unit === "string") patch.unit = unit.toUpperCase();
  await db.update(budgetNodes).set(patch).where(eq(budgetNodes.id, nodeId));
  if (before.kind === "ACTIVIDAD") {
    await db.update(budgetItems).set({
      ...(patch.code ? { activityCode: patch.code } : {}),
      ...(patch.name ? { activityName: patch.name } : {}),
      ...(patch.unit ? { unit: patch.unit } : {}),
      updatedAt: new Date(),
    }).where(eq(budgetItems.nodeId, nodeId));
  }
  await db.insert(budgetDecisions).values({
    projectId, entityType: "ESTRUCTURA", entityId: nodeId, action: `MODIFICO_${before.kind}`,
    detail: { antes: before, despues: patch }, actor: actor || null,
  });
  return NextResponse.json({ ok: true });
}

export async function DELETE(req: Request, ctx: { params: Promise<{ id: string }> }) {
  const { id: projectId } = await ctx.params;
  const url = new URL(req.url);
  const nodeId = url.searchParams.get("nodeId");
  const actor = url.searchParams.get("actor");
  if (!nodeId) return NextResponse.json({ error: "nodeId requerido." }, { status: 400 });
  const nodes = await db.select().from(budgetNodes).where(eq(budgetNodes.projectId, projectId));
  const root = nodes.find((n) => n.id === nodeId);
  if (!root) return NextResponse.json({ error: "Nodo no encontrado." }, { status: 404 });
  const removeIds = new Set([nodeId]);
  let changed = true;
  while (changed) {
    changed = false;
    for (const n of nodes) if (n.parentId && removeIds.has(n.parentId) && !removeIds.has(n.id)) { removeIds.add(n.id); changed = true; }
  }
  const items = await db.select().from(budgetItems).where(eq(budgetItems.projectId, projectId));
  const impacted = items.filter((i) => removeIds.has(i.nodeId));
  if (impacted.length) await db.delete(budgetItems).where(inArray(budgetItems.id, impacted.map((i) => i.id)));
  await db.delete(budgetNodes).where(inArray(budgetNodes.id, [...removeIds]));
  await db.insert(budgetDecisions).values({
    projectId, entityType: "ESTRUCTURA", entityId: nodeId, action: `ELIMINO_${root.kind}`,
    detail: { nodo: { code: root.code, name: root.name }, nodosEliminados: removeIds.size, actividadesEliminadas: impacted.length }, actor: actor || null,
  });
  return NextResponse.json({ ok: true, nodosEliminados: removeIds.size, actividadesEliminadas: impacted.length });
}
