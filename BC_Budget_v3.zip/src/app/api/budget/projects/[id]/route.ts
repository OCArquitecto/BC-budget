import { NextResponse } from "next/server";
import { db } from "@/db";
import {
  budgetProjects, budgetItems, budgetNodes, budgetRevisions, budgetDecisions,
  type CompanyInfo, type ProjectSettings,
} from "@/db/schema";
import { eq, desc } from "drizzle-orm";
import { sortByCode } from "@/lib/codes";

export async function GET(_req: Request, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  const [project] = await db.select().from(budgetProjects).where(eq(budgetProjects.id, id)).limit(1);
  if (!project) return NextResponse.json({ error: "Proyecto presupuestal no encontrado" }, { status: 404 });

  const nodes = await db.select().from(budgetNodes).where(eq(budgetNodes.projectId, id));
  const items = await db.select().from(budgetItems).where(eq(budgetItems.projectId, id));
  const itemByNodeId = new Map(items.map((it) => [it.nodeId, it]));

  const revisions = await db
    .select()
    .from(budgetRevisions)
    .where(eq(budgetRevisions.projectId, id))
    .orderBy(desc(budgetRevisions.revisionNumber));

  const decisions = await db
    .select()
    .from(budgetDecisions)
    .where(eq(budgetDecisions.projectId, id))
    .orderBy(desc(budgetDecisions.createdAt))
    .limit(50);

  // Construir jerarquía WBS con costos
  const chapters = sortByCode(nodes.filter((n) => n.kind === "CAPITULO"), (n) => n.code);
  const sections = sortByCode(nodes.filter((n) => n.kind === "SECCION"), (n) => n.code);
  const actNodes = sortByCode(nodes.filter((n) => n.kind === "ACTIVIDAD"), (n) => n.code);

  let directCostTotal = 0;
  const tree = chapters.map((ch) => {
    let chapterCost = 0;
    const secs = sections
      .filter((s) => s.parentId === ch.id)
      .map((sec) => {
        let secCost = 0;
        const acts = actNodes
          .filter((a) => a.parentId === sec.id)
          .map((a) => {
            const item = itemByNodeId.get(a.id);
            const cost = item?.directCost || 0;
            secCost += cost;
            return {
              ...a,
              item,
            };
          });
        chapterCost += secCost;
        return {
          ...sec,
          directCost: Math.round(secCost * 100) / 100,
          activities: acts,
        };
      });
    directCostTotal += chapterCost;
    return {
      ...ch,
      directCost: Math.round(chapterCost * 100) / 100,
      sections: secs,
    };
  });

  const st = (project.settings as ProjectSettings) || {};
  const adminPct = (st.administracion ?? 18) / 100;
  const impPct = (st.imprevistos ?? 3) / 100;
  const utilPct = (st.utilidad ?? 5) / 100;
  const ivaPct = (st.iva ?? 19) / 100;

  const vAdmin = Math.round(directCostTotal * adminPct * 100) / 100;
  const vImp = Math.round(directCostTotal * impPct * 100) / 100;
  const vUtil = Math.round(directCostTotal * utilPct * 100) / 100;

  const bases = st.ivaBases || ["UTILIDAD"];
  let baseIva = 0;
  if (bases.includes("DIRECTO")) baseIva += directCostTotal;
  if (bases.includes("ADMINISTRACION")) baseIva += vAdmin;
  if (bases.includes("IMPREVISTOS")) baseIva += vImp;
  if (bases.includes("UTILIDAD")) baseIva += vUtil;

  const vIva = Math.round(baseIva * ivaPct * 100) / 100;
  const totalBudget = Math.round((directCostTotal + vAdmin + vImp + vUtil + vIva) * 100) / 100;

  return NextResponse.json({
    project,
    tree,
    items,
    revisions,
    decisions,
    financialSummary: {
      costoDirecto: Math.round(directCostTotal * 100) / 100,
      administracion: vAdmin,
      imprevistos: vImp,
      utilidad: vUtil,
      baseIva: Math.round(baseIva * 100) / 100,
      iva: vIva,
      totalPresupuesto: totalBudget,
      porcentajes: {
        administracion: st.administracion ?? 18,
        imprevistos: st.imprevistos ?? 3,
        utilidad: st.utilidad ?? 5,
        iva: st.iva ?? 19,
        ivaBases: bases,
      },
      currency: st.currency || project.currency || "COP",
      stats: {
        totalActivities: items.length,
        withApu: items.filter((it) => it.status === "APU_ASIGNADO" || it.status === "CANTIDAD_MODIFICADA").length,
        withoutApu: items.filter((it) => it.status === "SIN_APU" || it.status === "PRECIO_IMPORTADO").length,
        pendingPriceReview: items.filter((it) => it.priceReviewRequired).length,
        modifiedQuantity: items.filter((it) => it.status === "CANTIDAD_MODIFICADA").length,
        pendingRevision: items.filter((it) => it.status === "REVISION_PENDIENTE").length,
      },
    },
  });
}

export async function PATCH(req: Request, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  const body = await req.json();
  const { name, client, location, region, priceDate, description, currency, status, company, settings, actor } = body || {};

  const patch: Partial<typeof budgetProjects.$inferInsert> = {};
  if (typeof name === "string" && name.trim()) patch.name = name.trim();
  if (typeof client === "string") patch.client = client;
  if (typeof location === "string") patch.location = location;
  if (typeof region === "string") patch.region = region;
  if (priceDate) patch.priceDate = new Date(priceDate);
  if (typeof description === "string") patch.description = description;
  if (typeof currency === "string") patch.currency = currency;
  if (typeof status === "string") patch.status = status;
  if (company !== undefined) patch.company = company as CompanyInfo;
  if (settings !== undefined) patch.settings = settings as ProjectSettings;
  patch.updatedAt = new Date();

  await db.update(budgetProjects).set(patch).where(eq(budgetProjects.id, id));

  await db.insert(budgetDecisions).values({
    projectId: id,
    entityType: "PROYECTO",
    entityId: id,
    action: "ACTUALIZO_DATOS_PRESUPUESTO",
    detail: { campos: Object.keys(patch) },
    actor: actor || null,
  });

  return NextResponse.json({ ok: true });
}

export async function DELETE(_req: Request, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  await db.delete(budgetProjects).where(eq(budgetProjects.id, id));
  return NextResponse.json({ ok: true });
}
