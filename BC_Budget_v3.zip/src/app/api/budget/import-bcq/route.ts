import { NextResponse } from "next/server";
import { importBcqIntoBudget } from "@/lib/budget/importer";
import { generateSaraBcq } from "@/lib/budget/sample-bcq";

export async function POST(req: Request) {
  try {
    const contentType = req.headers.get("content-type") || "";

    if (contentType.includes("multipart/form-data")) {
      const form = await req.formData();
      const file = form.get("file");
      const actor = String(form.get("actor") || "") || null;

      if (!(file instanceof File)) {
        return NextResponse.json({ error: "Debe adjuntar un archivo .bcq válido." }, { status: 400 });
      }

      const buffer = await file.arrayBuffer();
      const result = await importBcqIntoBudget(buffer, actor);
      return NextResponse.json({ ok: true, ...result });
    }

    // JSON request: for sample .bcq generation (e.g. demo button)
    const body = await req.json().catch(() => ({}));
    const { sample, revision, actor } = body || {};

    if (sample === "CASA_SARA") {
      const rev = revision === "REV-02" ? "REV-02" : "REV-01";
      const buffer = await generateSaraBcq(rev);
      const result = await importBcqIntoBudget(buffer, actor || "Muestra BIMCost");
      return NextResponse.json({ ok: true, ...result });
    }

    return NextResponse.json({ error: "Solicitud de importación inválida." }, { status: 400 });
  } catch (err) {
    console.error("Error importing .bcq into Budget:", err);
    return NextResponse.json(
      { error: (err as Error).message || "Error al procesar el archivo .bcq" },
      { status: 500 }
    );
  }
}
