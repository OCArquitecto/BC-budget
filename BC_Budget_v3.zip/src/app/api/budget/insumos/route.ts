import { NextResponse } from "next/server";
import { db } from "@/db";
import { masterInsumos, insumoPrices, type InsumoCategory } from "@/db/schema";
import { ensureBudgetMasterSeeded } from "@/lib/budget/sample-data";
import { and, asc, eq, ilike, or } from "drizzle-orm";

export async function GET(req: Request) {
  await ensureBudgetMasterSeeded();
  const url = new URL(req.url);
  const q = (url.searchParams.get("q") || "").trim();
  const category = url.searchParams.get("category");
  const region = url.searchParams.get("region");

  const conds = [];
  if (q) {
    conds.push(or(ilike(masterInsumos.code, `%${q}%`), ilike(masterInsumos.name, `%${q}%`)));
  }
  if (category) conds.push(eq(masterInsumos.category, category as InsumoCategory));
  if (region) conds.push(eq(masterInsumos.region, region));

  const rows = await db
    .select()
    .from(masterInsumos)
    .where(conds.length ? and(...conds) : undefined)
    .orderBy(asc(masterInsumos.category), asc(masterInsumos.name));

  return NextResponse.json({ insumos: rows, total: rows.length });
}

export async function POST(req: Request) {
  await ensureBudgetMasterSeeded();
  const body = await req.json();
  const { code, name, unit, category, unitPrice, supplier, source, notes, region, priceDate, actor } = body || {};

  if (!code || !name || !unit || !category) {
    return NextResponse.json({ error: "Código, nombre, unidad y categoría son obligatorios." }, { status: 400 });
  }

  const [created] = await db
    .insert(masterInsumos)
    .values({
      code: String(code).trim().toUpperCase(),
      name: String(name).trim(),
      unit: String(unit).trim().toUpperCase(),
      category: category as InsumoCategory,
      unitPrice: Number(unitPrice) || 0,
      currency: "COP",
      region: region || "COLOMBIA",
      priceDate: priceDate ? new Date(priceDate) : new Date(),
      supplier: supplier || null,
      source: source || null,
      notes: notes || null,
      active: true,
    })
    .returning();

  await db.insert(insumoPrices).values({
    insumoId: created.id, region: created.region, currency: created.currency,
    price: created.unitPrice, supplier: created.supplier, source: created.source,
    effectiveDate: created.priceDate, createdBy: actor || null,
  });
  return NextResponse.json({ insumo: created });
}

export async function PATCH(req: Request) {
  const body = await req.json();
  const { id, unitPrice, supplier, notes, active, name, unit, region, priceDate, source, actor } = body || {};

  if (!id) return NextResponse.json({ error: "id requerido." }, { status: 400 });

  const patch: Partial<typeof masterInsumos.$inferInsert> = {};
  if (typeof unitPrice === "number") patch.unitPrice = unitPrice;
  if (typeof supplier === "string") patch.supplier = supplier;
  if (typeof notes === "string") patch.notes = notes;
  if (typeof active === "boolean") patch.active = active;
  if (typeof name === "string") patch.name = name.trim();
  if (typeof unit === "string") patch.unit = unit.trim().toUpperCase();
  if (typeof region === "string") patch.region = region;
  if (priceDate) patch.priceDate = new Date(priceDate);
  if (typeof source === "string") patch.source = source;

  await db.update(masterInsumos).set(patch).where(eq(masterInsumos.id, id));
  const [updated] = await db.select().from(masterInsumos).where(eq(masterInsumos.id, id)).limit(1);
  if (updated && typeof unitPrice === "number") {
    await db.insert(insumoPrices).values({
      insumoId: id, region: region || updated.region, currency: updated.currency,
      price: unitPrice, supplier: supplier ?? updated.supplier,
      source: source ?? updated.source, effectiveDate: priceDate ? new Date(priceDate) : new Date(),
      createdBy: actor || null,
    });
  }
  return NextResponse.json({ ok: true });
}

export async function DELETE(req: Request) {
  const url = new URL(req.url);
  const id = url.searchParams.get("id");
  if (!id) return NextResponse.json({ error: "id requerido." }, { status: 400 });

  await db.delete(masterInsumos).where(eq(masterInsumos.id, id));
  return NextResponse.json({ ok: true });
}
