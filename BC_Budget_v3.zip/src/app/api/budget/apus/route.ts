import { NextResponse } from "next/server";
import { db } from "@/db";
import { masterApus, apuItems, masterInsumos, apuVersions, type InsumoCategory } from "@/db/schema";
import { ensureBudgetMasterSeeded } from "@/lib/budget/sample-data";
import { asc, eq, inArray } from "drizzle-orm";

export async function GET(req: Request) {
  await ensureBudgetMasterSeeded();
  const url = new URL(req.url);
  const apuId = url.searchParams.get("id");
  const suggestName = (url.searchParams.get("activityName") || "").trim();
  const suggestCode = (url.searchParams.get("activityCode") || "").trim();
  const suggestUnit = (url.searchParams.get("unit") || "").trim().toUpperCase();
  const region = (url.searchParams.get("region") || "").trim().toUpperCase();

  if (apuId) {
    const [apu] = await db.select().from(masterApus).where(eq(masterApus.id, apuId)).limit(1);
    if (!apu) return NextResponse.json({ error: "APU no encontrado" }, { status: 404 });

    const items = await db
      .select()
      .from(apuItems)
      .where(eq(apuItems.apuId, apuId))
      .orderBy(asc(apuItems.sortOrder));

    const insumoIds = items.map((it) => it.insumoId).filter((id): id is string => !!id);
    const insumos = insumoIds.length
      ? await db.select().from(masterInsumos).where(inArray(masterInsumos.id, insumoIds))
      : [];
    const insumoMap = new Map(insumos.map((i) => [i.id, i]));

    const enrichedItems = items.map((it) => ({
      ...it,
      insumo: it.insumoId ? insumoMap.get(it.insumoId) || null : null,
    }));

    const versions = await db.select().from(apuVersions).where(eq(apuVersions.apuId, apuId));
    return NextResponse.json({ apu, items: enrichedItems, versions });
  }

  const apus = await db.select().from(masterApus).orderBy(asc(masterApus.code));
  const allItems = await db.select().from(apuItems);

  const itemsByApu = new Map<string, number>();
  for (const it of allItems) {
    itemsByApu.set(it.apuId, (itemsByApu.get(it.apuId) || 0) + 1);
  }

  const tokens = suggestName.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "")
    .split(/[^a-z0-9]+/).filter((t) => t.length > 3);
  const scored = apus.map((a) => {
    let score = 0;
    const reasons: string[] = [];
    const hay = `${a.name} ${a.description || ""} ${a.category}`.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "");
    if (suggestUnit && a.unit.toUpperCase() === suggestUnit) { score += 35; reasons.push(`misma unidad ${suggestUnit}`); }
    if (suggestCode && a.activityCode === suggestCode) { score += 50; reasons.push("misma actividad técnica validada por la empresa"); }
    const hits = tokens.filter((t) => hay.includes(t));
    if (hits.length) { score += Math.min(hits.length, 4) * 12; reasons.push(`coincide: ${hits.join(", ")}`); }
    if (region && a.region.toUpperCase() === region) { score += 15; reasons.push(`región ${a.region}`); }
    if (a.isPreferred) { score += 8; reasons.push("preferido por la empresa"); }
    return { ...a, itemsCount: itemsByApu.get(a.id) || 0, suggestionScore: score, suggestionReasons: reasons };
  }).sort((a, b) => suggestName || suggestCode || suggestUnit ? b.suggestionScore - a.suggestionScore : a.code.localeCompare(b.code, "es", { numeric: true }));

  return NextResponse.json({ apus: scored, total: scored.length });
}

export async function POST(req: Request) {
  await ensureBudgetMasterSeeded();
  const body = await req.json();
  const {
    code, familyCode, activityCode, name, unit, category, description, items, duplicateFromId,
    versionLabel, region, currency, effectiveDate, validUntil, source, priceStatus,
    isPreferred, actor,
  } = body || {};

  if (!code || !name || !unit) {
    return NextResponse.json({ error: "Código, nombre y unidad son obligatorios." }, { status: 400 });
  }

  let itemsToInsert: {
    insumoId: string | null;
    category: InsumoCategory;
    description: string;
    unit: string;
    quantity: number;
    wastePercentage: number;
    unitPrice: number;
    subtotal: number;
    sortOrder: number;
  }[] = [];

  let unitCost = 0;

  if (Array.isArray(items) && items.length) {
    for (let i = 0; i < items.length; i++) {
      const it = items[i];
      const qty = Number(it.quantity) || 0;
      const waste = Number(it.wastePercentage) || 0;
      const price = Number(it.unitPrice) || 0;
      const subtotal = Math.round(qty * (1 + waste / 100) * price * 100) / 100;
      unitCost += subtotal;

      itemsToInsert.push({
        insumoId: it.insumoId || null,
        category: it.category as InsumoCategory,
        description: it.description || "Insumo",
        unit: it.unit || "UND",
        quantity: qty,
        wastePercentage: waste,
        unitPrice: price,
        subtotal,
        sortOrder: i,
      });
    }
  } else if (duplicateFromId) {
    const origItems = await db.select().from(apuItems).where(eq(apuItems.apuId, duplicateFromId));
    itemsToInsert = origItems.map((it) => {
      unitCost += it.subtotal;
      return {
        insumoId: it.insumoId,
        category: it.category,
        description: it.description,
        unit: it.unit,
        quantity: it.quantity,
        wastePercentage: it.wastePercentage,
        unitPrice: it.unitPrice,
        subtotal: it.subtotal,
        sortOrder: it.sortOrder,
      };
    });
  }

  const baseCode = String(code).trim().toUpperCase();
  const existingCodes = new Set((await db.select({ code: masterApus.code }).from(masterApus)).map((a) => a.code));
  let uniqueCode = baseCode;
  if (existingCodes.has(uniqueCode)) {
    const suffix = `${String(region || "CO").replace(/[^A-Z0-9]/gi, "").toUpperCase()}-${String(versionLabel || "V1").replace(/[^A-Z0-9]/gi, "").toUpperCase()}`;
    uniqueCode = `${baseCode}@${suffix}`;
    let n = 2;
    while (existingCodes.has(uniqueCode)) uniqueCode = `${baseCode}@${suffix}-${n++}`;
  }

  const [created] = await db
    .insert(masterApus)
    .values({
      code: uniqueCode,
      familyCode: String(familyCode || code).trim().toUpperCase(),
      activityCode: activityCode || null,
      name: String(name).trim(),
      unit: String(unit).trim().toUpperCase(),
      category: category || "GENERAL",
      description: description || null,
      unitCost: Math.round(unitCost * 100) / 100,
      versionLabel: versionLabel || "V1",
      region: region || "COLOMBIA",
      currency: currency || "COP",
      effectiveDate: effectiveDate ? new Date(effectiveDate) : new Date(),
      validUntil: validUntil ? new Date(validUntil) : null,
      source: source || "BANCO_EMPRESA",
      priceStatus: priceStatus || "VIGENTE",
      isPreferred: Boolean(isPreferred),
      active: true,
    })
    .returning();

  if (itemsToInsert.length) {
    await db.insert(apuItems).values(
      itemsToInsert.map((it) => ({
        apuId: created.id,
        ...it,
      }))
    );
  }

  await db.insert(apuVersions).values({
    apuId: created.id,
    versionLabel: created.versionLabel,
    region: created.region,
    effectiveDate: created.effectiveDate,
    currency: created.currency,
    unitCost: created.unitCost,
    source: created.source,
    components: itemsToInsert,
    notes: description || null,
    createdBy: actor || null,
  });

  return NextResponse.json({ apu: created });
}

export async function PATCH(req: Request) {
  const body = await req.json();
  const {
    id, code, familyCode, activityCode, name, unit, category, description, items, active,
    versionLabel, region, currency, effectiveDate, validUntil, source, priceStatus, isPreferred, actor,
  } = body || {};

  if (!id) return NextResponse.json({ error: "id requerido." }, { status: 400 });

  const patch: Partial<typeof masterApus.$inferInsert> = {};
  if (typeof code === "string") patch.code = code.trim().toUpperCase();
  if (typeof name === "string") patch.name = name.trim();
  if (typeof unit === "string") patch.unit = unit.trim().toUpperCase();
  if (typeof category === "string") patch.category = category.trim();
  if (typeof description === "string") patch.description = description;
  if (typeof active === "boolean") patch.active = active;
  if (typeof familyCode === "string") patch.familyCode = familyCode.trim().toUpperCase();
  if (activityCode !== undefined) patch.activityCode = activityCode || null;
  if (typeof versionLabel === "string") patch.versionLabel = versionLabel;
  if (typeof region === "string") patch.region = region;
  if (typeof currency === "string") patch.currency = currency;
  if (effectiveDate) patch.effectiveDate = new Date(effectiveDate);
  if (validUntil !== undefined) patch.validUntil = validUntil ? new Date(validUntil) : null;
  if (typeof source === "string") patch.source = source;
  if (typeof priceStatus === "string") patch.priceStatus = priceStatus;
  if (typeof isPreferred === "boolean") patch.isPreferred = isPreferred;
  patch.updatedAt = new Date();

  if (Array.isArray(items)) {
    // Reemplazar componentes del APU y recalcular costo unitario
    await db.delete(apuItems).where(eq(apuItems.apuId, id));

    let unitCost = 0;
    const itemsToInsert = items.map((it, idx) => {
      const qty = Number(it.quantity) || 0;
      const waste = Number(it.wastePercentage) || 0;
      const price = Number(it.unitPrice) || 0;
      const subtotal = Math.round(qty * (1 + waste / 100) * price * 100) / 100;
      unitCost += subtotal;

      return {
        apuId: id,
        insumoId: it.insumoId || null,
        category: it.category as InsumoCategory,
        description: it.description || "Insumo",
        unit: it.unit || "UND",
        quantity: qty,
        wastePercentage: waste,
        unitPrice: price,
        subtotal,
        sortOrder: idx,
      };
    });

    if (itemsToInsert.length) {
      await db.insert(apuItems).values(itemsToInsert);
    }
    patch.unitCost = Math.round(unitCost * 100) / 100;
  }

  await db.update(masterApus).set(patch).where(eq(masterApus.id, id));
  const [updated] = await db.select().from(masterApus).where(eq(masterApus.id, id)).limit(1);
  if (updated && (Array.isArray(items) || versionLabel || region || effectiveDate || priceStatus)) {
    const comps = await db.select().from(apuItems).where(eq(apuItems.apuId, id));
    await db.insert(apuVersions).values({
      apuId: id,
      versionLabel: updated.versionLabel,
      region: updated.region,
      effectiveDate: updated.effectiveDate,
      currency: updated.currency,
      unitCost: updated.unitCost,
      source: updated.source,
      components: comps,
      notes: updated.description,
      createdBy: actor || null,
    });
  }
  return NextResponse.json({ ok: true, unitCost: updated?.unitCost ?? patch.unitCost });
}

export async function DELETE(req: Request) {
  const url = new URL(req.url);
  const id = url.searchParams.get("id");
  if (!id) return NextResponse.json({ error: "id requerido." }, { status: 400 });

  await db.delete(masterApus).where(eq(masterApus.id, id));
  return NextResponse.json({ ok: true });
}
