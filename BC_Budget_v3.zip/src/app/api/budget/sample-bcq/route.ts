import { NextResponse } from "next/server";
import { generateSaraBcq } from "@/lib/budget/sample-bcq";

export async function GET(req: Request) {
  const url = new URL(req.url);
  const rev = url.searchParams.get("rev") === "REV-02" ? "REV-02" : "REV-01";
  const buffer = await generateSaraBcq(rev);

  return new NextResponse(new Uint8Array(buffer), {
    headers: {
      "Content-Type": "application/vnd.bimcost.quantity+zip",
      "Content-Disposition": `attachment; filename="CASA-SARA-${rev}.bcq"`,
    },
  });
}
