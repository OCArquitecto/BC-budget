import { NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import * as XLSX from "xlsx";
import { db } from "@/db";
import { sources, projects } from "@/db/schema";
import { parseIfc } from "@/lib/ifc/parser";
import { ensureCatalogSeeded } from "@/lib/catalog";
import {
  importParsedElements, importExcelRows, addDecision, sha256,
  modelFingerprint, findDuplicateSource, type ExcelRow,
} from "@/lib/server";

export async function GET(_req: Request, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  const rows = await db
    .select()
    .from(sources)
    .where(eq(sources.projectId, id))
    .orderBy(sources.createdAt);
  return NextResponse.json({ sources: rows });
}

function parseSheetRows(buf: ArrayBuffer): ExcelRow[] {
  const wb = XLSX.read(buf, { type: "array" });
  const ws = wb.Sheets[wb.SheetNames[0]];
  if (!ws) return [];
  const raw = XLSX.utils.sheet_to_json<(string | number | null)[]>(ws, { header: 1, defval: null });
  if (!raw.length) return [];
  // localizar fila de encabezado (debe contener "código"/"codigo")
  let header = 0;
  for (let i = 0; i < Math.min(raw.length, 10); i++) {
    const cells = (raw[i] ?? []).map((c) => String(c ?? "").toLowerCase());
    if (cells.some((c) => /c[oó]digo/.test(c))) {
      header = i;
      break;
    }
  }
  const out: ExcelRow[] = [];
  for (let i = header + 1; i < raw.length; i++) {
    const r = raw[i] ?? [];
    const codigo = String(r[0] ?? "").trim();
    if (!codigo) continue;
    const cantidadRaw = r[3];
    const cantidad = typeof cantidadRaw === "number" ? cantidadRaw : Number(String(cantidadRaw ?? "").replace(",", "."));
    out.push({
      codigo,
      actividad: String(r[1] ?? "").trim(),
      unidad: String(r[2] ?? "").trim(),
      cantidad: isFinite(cantidad) && String(cantidadRaw ?? "").trim() !== "" ? cantidad : null,
      nota: r[4] ? String(r[4]) : undefined,
    });
  }
  return out;
}

export async function POST(req: Request, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  const [project] = await db.select().from(projects).where(eq(projects.id, id)).limit(1);
  if (!project) return NextResponse.json({ error: "Proyecto no encontrado" }, { status: 404 });
  await ensureCatalogSeeded();

  const form = await req.formData();
  const kind = String(form.get("kind") ?? "IFC").toUpperCase();
  const name = String(form.get("name") ?? "").trim();
  const discipline = String(form.get("discipline") ?? "").trim() || null;
  const actor = String(form.get("actor") ?? "") || null;
  const file = form.get("file");

  if (!(file instanceof File)) {
    return NextResponse.json({ error: "Debe adjuntar un archivo." }, { status: 400 });
  }
  if (file.size > 30 * 1024 * 1024) {
    return NextResponse.json({ error: "Archivo demasiado grande (máx. 30 MB)." }, { status: 400 });
  }

  const sourceName = name || file.name.replace(/\.(ifc|xlsx|xls|csv)$/i, "");

  if (kind === "IFC") {
    const text = await file.text();
    const unitRaw = String(form.get("unitScale") ?? "auto").trim();
    const UNITS: Record<string, { scale: number; label: string }> = {
      m: { scale: 1, label: "METROS" },
      cm: { scale: 0.01, label: "CENTÍMETROS" },
      mm: { scale: 0.001, label: "MILÍMETROS" },
      ft: { scale: 0.3048, label: "PIES" },
      in: { scale: 0.0254, label: "PULGADAS" },
    };
    const forced = UNITS[unitRaw];
    const model = parseIfc(text, file.name, forced ? { unitScale: forced.scale, unitLabel: forced.label } : undefined);
    if (model.elementCount === 0) {
      return NextResponse.json(
        { error: "El archivo no contiene elementos de construcción reconocibles.", warnings: model.warnings },
        { status: 422 }
      );
    }

    /* --- Control de modelos duplicados en el mismo proyecto --------- */
    const contentHash = sha256(text);
    const modelHash = modelFingerprint(model.elements.map((e) => e.globalId));
    const permitirDuplicado = String(form.get("allowDuplicate") ?? "") === "1";
    const dup = await findDuplicateSource(id, { contentHash, modelHash, fileName: file.name });

    if (dup && !permitirDuplicado) {
      const MOTIVO: Record<string, string> = {
        ARCHIVO_IDENTICO: "es exactamente el mismo archivo (contenido idéntico)",
        MISMO_MODELO: "contiene los mismos elementos IFC (mismos GlobalId), aunque el archivo se haya vuelto a exportar",
        MISMO_NOMBRE: "tiene el mismo nombre de archivo",
      };
      return NextResponse.json({
        error: "FUENTE_DUPLICADA",
        duplicado: {
          mensaje: `Este proyecto ya incluye «${dup.name}»: ${MOTIVO[dup.motivo]}.`,
          consecuencia: "Importarlo otra vez duplicaría todas las cantidades de ese modelo.",
          sugerencia: dup.motivo === "MISMO_MODELO"
            ? "Si es una versión actualizada del modelo, elimine primero la fuente anterior para no sumar cantidades repetidas."
            : "Elimine la fuente existente si desea reemplazarla.",
          fuenteExistente: {
            id: dup.id, nombre: dup.name, archivo: dup.fileName,
            elementos: dup.elementos, importadaEl: dup.createdAt, motivo: dup.motivo,
          },
        },
      }, { status: 409 });
    }

    const [source] = await db
      .insert(sources)
      .values({
        projectId: id, kind: "IFC", name: sourceName,
        discipline, fileName: file.name, fileSize: file.size,
        ifcSchema: model.schema, status: "ACTIVA",
        contentHash, modelHash,
        stats: {
          elementos: model.elementCount,
          entidades: model.entityCount,
          clases: model.classes,
          niveles: model.levels,
          materiales: model.materials,
          proyectoIfc: model.projectName,
          advertencias: model.warnings,
          unidad: model.lengthUnit,
          factorEscala: model.lengthScale,
          escalaOrigen: model.scaleSource,
          escalaCorregida: model.autoCorrected,
          extensionModelo: model.modelExtent,
          conGeometria: model.withGeometry,
          conCantidadesIfc: model.withIfcQuantities,
        },
      })
      .returning();
    const inserted = await importParsedElements(id, source.id, model);
    await addDecision(id, "FUENTE", source.id, "IMPORTO_IFC", {
      archivo: file.name, esquema: model.schema, elementos: inserted, clases: model.classes,
    }, actor);
    return NextResponse.json({ source, elementos: inserted, model: { clases: model.classes, advertencias: model.warnings } });
  }

  if (kind === "EXCEL") {
    const buf = await file.arrayBuffer();
    const rows = parseSheetRows(buf);
    if (!rows.length) {
      return NextResponse.json(
        { error: "No se encontraron filas válidas. Formato esperado: Código | Actividad | Unidad | Cantidad | (Nota)." },
        { status: 422 }
      );
    }
    const [source] = await db
      .insert(sources)
      .values({
        projectId: id, kind: "EXCEL", name: sourceName,
        discipline, fileName: file.name, fileSize: file.size, status: "ACTIVA",
        stats: { filas: rows.length },
        meta: { rows },
      })
      .returning();
    const result = await importExcelRows(id, source.id, rows);
    await addDecision(id, "FUENTE", source.id, "IMPORTO_EXCEL", {
      archivo: file.name, ...result,
    }, actor);
    return NextResponse.json({ source, ...result });
  }

  return NextResponse.json({ error: `Tipo de fuente no soportado: ${kind}` }, { status: 400 });
}
