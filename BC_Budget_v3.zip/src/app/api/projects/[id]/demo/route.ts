import { NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { projects, sources } from "@/db/schema";
import { parseIfc } from "@/lib/ifc/parser";
import { DEMO_SOURCES, DEMO_EXCEL_ROWS } from "@/lib/ifc/sample";
import { ensureCatalogSeeded } from "@/lib/catalog";
import { importParsedElements, importExcelRows, addDecision, sha256, modelFingerprint, findDuplicateSource } from "@/lib/server";

export async function POST(req: Request, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  const [project] = await db.select().from(projects).where(eq(projects.id, id)).limit(1);
  if (!project) return NextResponse.json({ error: "Proyecto no encontrado" }, { status: 404 });
  await ensureCatalogSeeded();

  const body = await req.json().catch(() => ({}));
  const actor = (body as { actor?: string })?.actor ?? null;

  const summary: { fuente: string; elementos?: number; filas?: number }[] = [];

  for (const demo of DEMO_SOURCES) {
    const text = demo.build();
    const model = parseIfc(text, demo.file);
    const contentHash = sha256(text);
    const modelHash = modelFingerprint(model.elements.map((e) => e.globalId));
    const dup = await findDuplicateSource(id, { contentHash, modelHash, fileName: demo.file });
    if (dup) { summary.push({ fuente: `${demo.name} (ya existía, omitido)` }); continue; }
    const [source] = await db
      .insert(sources)
      .values({
        projectId: id, kind: "IFC", name: demo.name,
        contentHash, modelHash,
        discipline: demo.discipline, fileName: demo.file,
        fileSize: text.length, ifcSchema: model.schema, status: "ACTIVA",
        stats: {
          elementos: model.elementCount,
          entidades: model.entityCount,
          clases: model.classes,
          niveles: model.levels,
          materiales: model.materials,
          proyectoIfc: model.projectName,
          advertencias: model.warnings,
          demostracion: true,
        },
      })
      .returning();
    const n = await importParsedElements(id, source.id, model);
    await addDecision(id, "FUENTE", source.id, "IMPORTO_IFC", {
      archivo: demo.file, esquema: model.schema, elementos: n, clases: model.classes, demostracion: true,
    }, actor);
    summary.push({ fuente: demo.name, elementos: n });
  }

  const [excelSource] = await db
    .insert(sources)
    .values({
      projectId: id, kind: "EXCEL", name: "Partidas no BIM (Excel)",
      discipline: "PRELIMINARES", fileName: "partidas-preliminares.xlsx",
      status: "ACTIVA", stats: { filas: DEMO_EXCEL_ROWS.length, demostracion: true },
      meta: { rows: DEMO_EXCEL_ROWS },
    })
    .returning();
  const excelResult = await importExcelRows(id, excelSource.id, DEMO_EXCEL_ROWS);
  await addDecision(id, "FUENTE", excelSource.id, "IMPORTO_EXCEL", { archivo: "partidas-preliminares.xlsx", ...excelResult, demostracion: true }, actor);
  summary.push({ fuente: "Partidas no BIM (Excel)", filas: DEMO_EXCEL_ROWS.length });

  return NextResponse.json({ ok: true, summary });
}
