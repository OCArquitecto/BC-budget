import { NextResponse } from "next/server";
import { eq, sql } from "drizzle-orm";
import { db } from "@/db";
import { projects, sources, elements, quantities, matches, groupingRuns, decisions } from "@/db/schema";
import type { CompanyInfo, ProjectSettings } from "@/db/schema";
import { addDecision } from "@/lib/server";

/** Actualiza datos del proyecto, empresa responsable y porcentajes AIU. */
export async function PATCH(req: Request, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  const body = await req.json();
  const { name, client, location, description, company, settings, actor } = body ?? {};

  const patch: Partial<typeof projects.$inferInsert> = {};
  if (typeof name === "string" && name.trim()) patch.name = name.trim();
  if (typeof client === "string") patch.client = client;
  if (typeof location === "string") patch.location = location;
  if (typeof description === "string") patch.description = description;
  if (company !== undefined) patch.company = company as CompanyInfo;
  if (settings !== undefined) patch.settings = settings as ProjectSettings;
  if (!Object.keys(patch).length) return NextResponse.json({ error: "Nada que actualizar." }, { status: 400 });

  await db.update(projects).set(patch).where(eq(projects.id, id));
  await addDecision(id, "PROYECTO", id, "ACTUALIZO_DATOS_PROYECTO", {
    campos: Object.keys(patch),
    aiu: settings ? { administracion: settings.administracion, imprevistos: settings.imprevistos, utilidad: settings.utilidad, iva: settings.iva } : undefined,
  }, actor);
  return NextResponse.json({ ok: true });
}

/** Elimina el proyecto y toda su información (fuentes, elementos, cantidades). */
export async function DELETE(req: Request, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  const url = new URL(req.url);
  const confirm = url.searchParams.get("confirm");

  const [project] = await db.select().from(projects).where(eq(projects.id, id)).limit(1);
  if (!project) return NextResponse.json({ error: "Proyecto no encontrado" }, { status: 404 });

  if (confirm !== project.code) {
    return NextResponse.json(
      { error: `Para eliminar debe confirmar con el código del proyecto (${project.code}).` },
      { status: 400 }
    );
  }

  // Las tablas dependientes tienen ON DELETE CASCADE
  await db.delete(projects).where(eq(projects.id, id));
  return NextResponse.json({ ok: true, eliminado: project.code });
}

export async function GET(_req: Request, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  const [project] = await db.select().from(projects).where(eq(projects.id, id)).limit(1);
  if (!project) return NextResponse.json({ error: "Proyecto no encontrado" }, { status: 404 });

  const src = await db.select().from(sources).where(eq(sources.projectId, id));
  const [el] = await db.select({ n: sql<number>`count(*)::int` }).from(elements).where(eq(elements.projectId, id));
  const [ex] = await db.select({ n: sql<number>`count(*)::int` }).from(elements).where(sql`${elements.projectId}=${id} and ${elements.excluded}=true`);
  const runs = await db.select().from(groupingRuns).where(eq(groupingRuns.projectId, id)).orderBy(sql`${groupingRuns.createdAt} desc`);
  const matchStats = await db
    .select({ status: matches.status, n: sql<number>`count(*)::int` })
    .from(matches)
    .where(eq(matches.projectId, id))
    .groupBy(matches.status);
  const qtyStats = await db
    .select({ status: quantities.status, n: sql<number>`count(*)::int` })
    .from(quantities)
    .where(eq(quantities.projectId, id))
    .groupBy(quantities.status);
  const [dec] = await db.select({ n: sql<number>`count(*)::int` }).from(decisions).where(eq(decisions.projectId, id));

  return NextResponse.json({
    project,
    sources: src,
    stats: {
      fuentes: src.length,
      fuentesIfc: src.filter((s) => s.kind === "IFC").length,
      elementos: el?.n ?? 0,
      excluidos: ex?.n ?? 0,
      corridas: runs.length,
      ultimaCorrida: runs[0] ?? null,
      matchesPorEstado: Object.fromEntries(matchStats.map((m) => [m.status, m.n])),
      cantidadesPorEstado: Object.fromEntries(qtyStats.map((q) => [q.status, q.n])),
      decisiones: dec?.n ?? 0,
    },
  });
}
