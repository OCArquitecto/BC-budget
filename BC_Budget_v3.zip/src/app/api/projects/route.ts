import { NextResponse } from "next/server";
import { desc, eq, sql } from "drizzle-orm";
import { db } from "@/db";
import { projects, sources, elements, quantities, matches, structureNodes } from "@/db/schema";
import { ensureCatalogSeeded } from "@/lib/catalog";
import { ensureManualSource, addDecision } from "@/lib/server";
import { catalogActivities } from "@/db/schema";

export async function GET() {
  await ensureCatalogSeeded();
  const rows = await db.select().from(projects).orderBy(desc(projects.createdAt));

  const enriched = await Promise.all(
    rows.map(async (p) => {
      const [src] = await db
        .select({ n: sql<number>`count(*)::int` })
        .from(sources)
        .where(eq(sources.projectId, p.id));
      const [els] = await db
        .select({ n: sql<number>`count(*)::int` })
        .from(elements)
        .where(eq(elements.projectId, p.id));
      const [qv] = await db
        .select({ n: sql<number>`count(*)::int` })
        .from(quantities)
        .where(eq(quantities.projectId, p.id));
      const [qval] = await db
        .select({ n: sql<number>`count(*)::int` })
        .from(quantities)
        .where(sql`${quantities.projectId} = ${p.id} and ${quantities.status} = 'VALIDADA'`);
      const [mp] = await db
        .select({ n: sql<number>`count(*)::int` })
        .from(matches)
        .where(sql`${matches.projectId} = ${p.id} and ${matches.status} in ('PENDIENTE','PROPUESTA')`);
      return {
        ...p,
        stats: {
          fuentes: src?.n ?? 0,
          elementos: els?.n ?? 0,
          cantidades: qv?.n ?? 0,
          validadas: qval?.n ?? 0,
          pendientesDecision: mp?.n ?? 0,
        },
      };
    })
  );
  return NextResponse.json({ projects: enriched });
}

export async function POST(req: Request) {
  const body = await req.json();
  const { code, name, client, location, description, template, actor } = body ?? {};
  if (!code || !name) {
    return NextResponse.json({ error: "Código y nombre del proyecto son obligatorios." }, { status: 400 });
  }
  await ensureCatalogSeeded();

  const [project] = await db
    .insert(projects)
    .values({
      code: String(code).trim().toUpperCase(),
      name: String(name).trim(),
      client: client || null,
      location: location || null,
      description: description || null,
    })
    .returning();

  await ensureManualSource(project.id);

  if (template) {
    // Precarga la estructura base de capítulos del catálogo maestro (plantilla)
    await db.insert(sources).values({
      projectId: project.id,
      kind: "TEMPLATE",
      name: "Plantilla: estructura base del catálogo",
      discipline: "GENERAL",
      stats: { nota: "Capítulos y secciones precargados desde el catálogo maestro" },
    });
    const acts = await db.select().from(catalogActivities).where(eq(catalogActivities.active, true));
    const chapters = new Map<string, string>();
    const sections = new Map<string, { name: string; chapterCode: string }>();
    for (const a of acts) {
      chapters.set(a.chapterCode, a.chapterName);
      if (!sections.has(a.sectionCode)) sections.set(a.sectionCode, { name: a.sectionName, chapterCode: a.chapterCode });
    }
    const chapterIds = new Map<string, string>();
    for (const [cc, cn] of [...chapters.entries()].sort()) {
      const [row] = await db
        .insert(structureNodes)
        .values({
          projectId: project.id, parentId: null, kind: "CAPITULO",
          code: cc, name: cn, sortOrder: parseInt(cc, 10) || 0,
        })
        .returning();
      chapterIds.set(cc, row.id);
    }
    for (const [sc, info] of [...sections.entries()].sort()) {
      const parent = chapterIds.get(info.chapterCode);
      if (!parent) continue;
      await db.insert(structureNodes).values({
        projectId: project.id, parentId: parent, kind: "SECCION",
        code: sc, name: info.name,
        sortOrder: parseInt(sc.split(".")[1] ?? "0", 10) || 0,
      });
    }
  }

  await addDecision(project.id, "PROYECTO", project.id, "CREO_PROYECTO", { code: project.code, name: project.name, plantilla: !!template }, actor);

  return NextResponse.json({ project });
}
