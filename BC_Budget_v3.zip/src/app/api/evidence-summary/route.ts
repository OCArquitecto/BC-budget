import { NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { elements, sources } from "@/db/schema";

export async function GET(req: Request) {
  const url = new URL(req.url);
  const projectId = url.searchParams.get("projectId");
  if (!projectId) return NextResponse.json({ error: "projectId requerido" }, { status: 400 });

  const rows = await db
    .select({
      ifcClass: elements.ifcClass,
      material: elements.material,
      level: elements.level,
      layer: elements.layer,
      excluded: elements.excluded,
      properties: elements.properties,
      sourceId: elements.sourceId,
    })
    .from(elements)
    .where(eq(elements.projectId, projectId));

  const count = (get: (r: (typeof rows)[number]) => string | null) => {
    const m = new Map<string, { total: number; excluidos: number }>();
    for (const r of rows) {
      const k = get(r) ?? "(sin dato)";
      const cur = m.get(k) ?? { total: 0, excluidos: 0 };
      cur.total++;
      if (r.excluded) cur.excluidos++;
      m.set(k, cur);
    }
    return [...m.entries()].map(([valor, v]) => ({ valor, ...v })).sort((a, b) => b.total - a.total);
  };

  const propKeys = new Map<string, number>();
  for (const r of rows) {
    for (const [pset, props] of Object.entries(r.properties ?? {})) {
      for (const k of Object.keys(props)) {
        const key = `${pset}.${k}`;
        propKeys.set(key, (propKeys.get(key) ?? 0) + 1);
      }
    }
  }

  const src = await db
    .select({ id: sources.id, name: sources.name, kind: sources.kind, discipline: sources.discipline })
    .from(sources)
    .where(eq(sources.projectId, projectId));

  const perSource = new Map<string, number>();
  for (const r of rows) perSource.set(r.sourceId, (perSource.get(r.sourceId) ?? 0) + 1);

  return NextResponse.json({
    total: rows.length,
    clases: count((r) => r.ifcClass),
    materiales: count((r) => r.material),
    niveles: count((r) => r.level),
    capas: count((r) => r.layer),
    propiedades: [...propKeys.entries()]
      .map(([clave, elementos_]) => ({ clave, elementos: elementos_ }))
      .sort((a, b) => b.elementos - a.elementos)
      .slice(0, 60),
    fuentes: src.map((s) => ({ ...s, elementos: perSource.get(s.id) ?? 0 })),
  });
}
