import { NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { elements } from "@/db/schema";
import { addDecision } from "@/lib/server";

export async function PATCH(req: Request, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  const body = await req.json();
  const { excluded, actor, nota } = body ?? {};
  if (typeof excluded !== "boolean") {
    return NextResponse.json({ error: "excluded (boolean) requerido" }, { status: 400 });
  }
  const [el] = await db.select().from(elements).where(eq(elements.id, id)).limit(1);
  if (!el) return NextResponse.json({ error: "Elemento no encontrado" }, { status: 404 });

  await db.update(elements).set({ excluded }).where(eq(elements.id, id));
  await addDecision(
    el.projectId, "ELEMENTO", el.id,
    excluded ? "EXCLUYO_ELEMENTO" : "REINCORPORO_ELEMENTO",
    {
      elemento: el.name, clase: el.ifcClass, globalId: el.globalId, nota: nota ?? null,
      mensaje: "La exclusión no elimina la evidencia original; solo la aparta del análisis.",
    },
    actor
  );
  return NextResponse.json({ ok: true });
}
