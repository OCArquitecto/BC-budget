import { NextResponse } from "next/server";
import { and, eq, ilike, inArray } from "drizzle-orm";
import { db } from "@/db";
import { elements, sources, groups, quantities, catalogActivities } from "@/db/schema";

export async function GET(req: Request) {
  const url = new URL(req.url);
  const projectId = url.searchParams.get("projectId");
  if (!projectId) return NextResponse.json({ error: "projectId requerido" }, { status: 400 });

  const groupId = url.searchParams.get("groupId");
  const quantityId = url.searchParams.get("quantityId");

  /** Añade las actividades presupuestales que usan cada elemento. */
  const enrichActivities = async <T extends { id: string }>(rows: T[]) => {
    if (!rows.length) return rows.map((r) => ({ ...r, activities: [] }));
    const qs = await db.select().from(quantities).where(eq(quantities.projectId, projectId));
    const acts = await db.select().from(catalogActivities);
    const actMap = new Map(acts.map((a) => [a.id, a]));
    const byElement = new Map<string, { id: string; code: string; name: string; status: string; quantityId: string }[]>();
    for (const q2 of qs) {
      if (!q2.activityId || q2.status === "RECHAZADA") continue;
      const a = actMap.get(q2.activityId);
      if (!a) continue;
      for (const eid of q2.elementIds ?? []) {
        const list = byElement.get(eid) ?? [];
        if (!list.some((x) => x.id === a.id)) {
          list.push({ id: a.id, code: a.code, name: a.name, status: q2.status, quantityId: q2.id });
        }
        byElement.set(eid, list);
      }
    }
    return rows.map((r) => ({ ...r, activities: byElement.get(r.id) ?? [] }));
  };

  /* --- por grupo de agrupación (visor / revisión) --- */
  if (groupId) {
    const [g] = await db.select().from(groups).where(eq(groups.id, groupId)).limit(1);
    if (!g) return NextResponse.json({ error: "Grupo no encontrado" }, { status: 404 });
    const ids = (g.elementIds as string[]) ?? [];
    const rows = ids.length ? await db.select().from(elements).where(inArray(elements.id, ids)) : [];
    return NextResponse.json({ elements: await enrichActivities(rows), total: rows.length });
  }

  /* --- por cantidad (visor de trazabilidad) --- */
  if (quantityId) {
    const [q] = await db.select().from(quantities).where(eq(quantities.id, quantityId)).limit(1);
    if (!q) return NextResponse.json({ error: "Cantidad no encontrada" }, { status: 404 });
    const ids = (q.elementIds as string[]) ?? [];
    const rows = ids.length ? await db.select().from(elements).where(inArray(elements.id, ids)) : [];
    return NextResponse.json({ elements: await enrichActivities(rows), total: rows.length });
  }

  const conds = [eq(elements.projectId, projectId)];
  const ifcClass = url.searchParams.get("ifcClass");
  const level = url.searchParams.get("level");
  const material = url.searchParams.get("material");
  const sourceId = url.searchParams.get("sourceId");
  const q = url.searchParams.get("q");
  const showExcluded = url.searchParams.get("excluded") !== "false";

  if (ifcClass) conds.push(eq(elements.ifcClass, ifcClass));
  if (level) conds.push(eq(elements.level, level));
  if (material) conds.push(eq(elements.material, material));
  if (sourceId) conds.push(eq(elements.sourceId, sourceId));
  if (!showExcluded) conds.push(eq(elements.excluded, false));
  if (q) conds.push(ilike(elements.name, `%${q}%`));

  const rows = await db
    .select()
    .from(elements)
    .where(and(...conds))
    .orderBy(elements.ifcClass, elements.name)
    .limit(2000);

  const src = await db
    .select({ id: sources.id, name: sources.name, discipline: sources.discipline })
    .from(sources)
    .where(eq(sources.projectId, projectId));
  const srcMap = Object.fromEntries(src.map((s) => [s.id, s]));

  const withSource = rows.map((e) => ({ ...e, source: srcMap[e.sourceId] ?? null }));
  return NextResponse.json({
    elements: await enrichActivities(withSource),
    total: rows.length,
  });
}
