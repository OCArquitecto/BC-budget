import { NextResponse } from "next/server";
import { and, eq, inArray, desc } from "drizzle-orm";
import { db } from "@/db";
import {
  elements as elementsTable, groupingRuns, groups as groupsTable,
  matches as matchesTable, catalogActivities, sources,
} from "@/db/schema";
import {
  buildGroups, proposeForGroup, CRITERIA_DEFS, CLASS_FAMILIES,
  defaultExcludedClasses, familyOf,
} from "@/lib/engine";
import { toWorkElement, addDecision, inactiveCatalogScopes } from "@/lib/server";

export async function GET(req: Request) {
  const url = new URL(req.url);
  const projectId = url.searchParams.get("projectId");
  if (!projectId) return NextResponse.json({ error: "projectId requerido" }, { status: 400 });

  const runs = await db
    .select()
    .from(groupingRuns)
    .where(eq(groupingRuns.projectId, projectId))
    .orderBy(desc(groupingRuns.createdAt));

  // Clases disponibles en el proyecto (para poder apagarlas)
  const els = await db
    .select({ ifcClass: elementsTable.ifcClass })
    .from(elementsTable)
    .where(eq(elementsTable.projectId, projectId));
  const classCount = new Map<string, number>();
  for (const e of els) classCount.set(e.ifcClass, (classCount.get(e.ifcClass) ?? 0) + 1);
  const clases = [...classCount.entries()]
    .map(([ifcClass, count]) => {
      const fam = familyOf(ifcClass);
      return {
        ifcClass,
        count,
        familia: fam?.family ?? "GENERICO",
        familiaLabel: fam?.label ?? "Sin familia definida",
        presupuestable: fam?.presupuestable ?? true,
      };
    })
    .sort((a, b) => b.count - a.count);

  let groupsOut: unknown[] = [];
  const runId = url.searchParams.get("runId") ?? runs[0]?.id;
  if (runId) {
    const g = await db.select().from(groupsTable).where(eq(groupsTable.runId, runId)).orderBy(desc(groupsTable.elementCount));
    const m = await db
      .select({ groupId: matchesTable.groupId, status: matchesTable.status, score: matchesTable.score })
      .from(matchesTable)
      .where(eq(matchesTable.runId, runId));
    const byGroup = new Map<string, { total: number; propuestas: number; pendientes: number; validadas: number; rechazadas: number; mejorScore: number }>();
    for (const mm of m) {
      const cur = byGroup.get(mm.groupId) ?? { total: 0, propuestas: 0, pendientes: 0, validadas: 0, rechazadas: 0, mejorScore: 0 };
      cur.total++;
      if (mm.status === "PROPUESTA") cur.propuestas++;
      if (mm.status === "PENDIENTE") cur.pendientes++;
      if (mm.status === "VALIDADA") cur.validadas++;
      if (mm.status === "RECHAZADA") cur.rechazadas++;
      cur.mejorScore = Math.max(cur.mejorScore, mm.score ?? 0);
      byGroup.set(mm.groupId, cur);
    }
    groupsOut = g.map((row) => ({ ...row, correspondencias: byGroup.get(row.id) ?? null }));
  }

  return NextResponse.json({
    runs,
    groups: groupsOut,
    criteriosDisponibles: CRITERIA_DEFS,
    clases,
    familias: CLASS_FAMILIES.map((f) => ({ family: f.family, label: f.label, presupuestable: f.presupuestable })),
    exclusionesSugeridas: defaultExcludedClasses(clases.map((c) => c.ifcClass)),
  });
}

export async function POST(req: Request) {
  const body = await req.json();
  const { projectId, sourceIds, criteria, excludedClasses, actor } = body ?? {};
  if (!projectId) return NextResponse.json({ error: "projectId requerido" }, { status: 400 });
  if (!Array.isArray(criteria) || criteria.length === 0 || criteria.length > 7) {
    return NextResponse.json({ error: "Seleccione entre 1 y 7 criterios de agrupación." }, { status: 400 });
  }
  const t0 = Date.now();
  const excluded: string[] = Array.isArray(excludedClasses) ? excludedClasses : [];

  let srcIds: string[] = Array.isArray(sourceIds) && sourceIds.length ? sourceIds : [];
  if (!srcIds.length) {
    const ifcSources = await db
      .select({ id: sources.id })
      .from(sources)
      .where(and(eq(sources.projectId, projectId), eq(sources.kind, "IFC")));
    srcIds = ifcSources.map((s) => s.id);
  }
  if (!srcIds.length) return NextResponse.json({ error: "El proyecto no tiene fuentes IFC con elementos." }, { status: 400 });

  const rows = await db
    .select()
    .from(elementsTable)
    .where(and(eq(elementsTable.projectId, projectId), inArray(elementsTable.sourceId, srcIds)));
  const work = rows.map(toWorkElement);
  if (!work.length) {
    return NextResponse.json({ error: "Las fuentes seleccionadas no contienen elementos IFC." }, { status: 400 });
  }

  // Las decisiones profesionales se conservan; solo se recalcula lo no decidido.
  await db
    .delete(matchesTable)
    .where(and(eq(matchesTable.projectId, projectId), inArray(matchesTable.status, ["PENDIENTE", "PROPUESTA"])));

  const [run] = await db
    .insert(groupingRuns)
    .values({ projectId, sourceIds: srcIds, criteria, excludedClasses: excluded, createdBy: actor ?? null })
    .returning();

  const built = buildGroups(work, criteria, excluded);

  // Catálogo activo, respetando capítulos y secciones apagados
  const inactive = await inactiveCatalogScopes();
  const catalog = (await db.select().from(catalogActivities))
    .filter((a) => a.active && !inactive.chapters.has(a.chapterCode) && !inactive.sections.has(a.sectionCode))
    .map((a) => ({
      id: a.id, code: a.code, name: a.name, unit: a.unit, method: a.method,
      keywords: a.keywords ?? [], ifcClasses: a.ifcClasses ?? [], active: a.active,
      chapterCode: a.chapterCode, sectionCode: a.sectionCode,
    }));

  let propuestas = 0;
  let pendientes = 0;
  let ambiguas = 0;

  for (const g of built) {
    const [stored] = await db
      .insert(groupsTable)
      .values({
        runId: run.id, projectId, groupKey: g.groupKey,
        criteriaValues: g.criteriaValues, elementIds: g.elementIds,
        elementCount: g.elementCount, ifcClasses: g.ifcClasses,
        semanticTypes: g.semanticTypes, sourceIds: g.sourceIds,
      })
      .returning();

    // UNA sola propuesta por grupo → evita duplicar cantidades
    const p = proposeForGroup(g, catalog);
    await db.insert(matchesTable).values({
      projectId, runId: run.id, groupId: stored.id,
      activityId: p.activityId, score: p.score, status: p.status,
      candidates: p.candidates, evidence: p.evidence,
    });
    if (p.status === "PROPUESTA") propuestas++; else pendientes++;
    if ((p.evidence as { ambiguo?: boolean }).ambiguo) ambiguas++;
  }

  const durationMs = Date.now() - t0;
  const analizados = work.filter(
    (w) => !w.excluded && !excluded.map((c) => c.toUpperCase()).includes(w.ifcClass.toUpperCase())
  ).length;

  await db
    .update(groupingRuns)
    .set({ elementCount: analizados, groupCount: built.length, durationMs })
    .where(eq(groupingRuns.id, run.id));

  await addDecision(projectId, "AGRUPACION", run.id, "EJECUTO_AGRUPACION", {
    criterios: criteria,
    clasesExcluidas: excluded,
    fuentes: srcIds.length,
    elementosAnalizados: analizados,
    grupos: built.length,
    propuestas, pendientes, ambiguas,
    duracionMs: durationMs,
    reglaBIM: "Las propuestas respetan la familia BIM de cada clase IFC (muro→muro, viga→viga, losa→placa).",
  }, actor);

  return NextResponse.json({
    run: { ...run, elementCount: analizados, groupCount: built.length, durationMs },
    grupos: built.length, propuestas, pendientes, ambiguas,
  });
}
