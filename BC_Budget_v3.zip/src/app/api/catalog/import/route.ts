import { NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import * as XLSX from "xlsx";
import { db } from "@/db";
import { catalogActivities } from "@/db/schema";
import { ensureCatalogSeeded, syncCatalogGroups } from "@/lib/catalog";
import {
  ifcClassesFromName, keywordsFromName, methodForUnit, normalizeUnit, parsePrice, splitCode,
} from "@/lib/infer";

type Cell = string | number | boolean | null;
const textOf = (v: Cell) => (v === null || v === undefined ? "" : String(v).trim());
const norm = (s: string) => s.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "");

interface Mapping {
  sheet: string;
  headerRow: number;   // índice 0-based de la fila de encabezados
  code: number;        // índice de columna (-1 = no usar)
  name: number;
  unit: number;
  price: number;
  chapter: number;     // opcional: columna con capítulo
  section: number;     // opcional: columna con sección
}

/** Sugerencia automática de columnas a partir de los encabezados. */
function guess(rows: Cell[][]): { headerRow: number; code: number; name: number; unit: number; price: number; chapter: number; section: number } {
  const max = Math.min(rows.length, 30);
  for (let i = 0; i < max; i++) {
    const cells = (rows[i] ?? []).map((c) => norm(textOf(c)));
    const code = cells.findIndex((c) => /^(codigo|cod|item|referencia|ref|clave)\b/.test(c));
    const name = cells.findIndex((c) => /(descripcion|actividad|concepto|detalle|nombre|item de obra|insumo)/.test(c));
    const unit = cells.findIndex((c) => /^(unidad|und|u\.?m\.?|medida|unid)/.test(c));
    const price = cells.findIndex((c) => /(valor|precio|vr|v\/r|costo|unitario|tarifa)/.test(c));
    const chapter = cells.findIndex((c) => /(capitulo|cap\.)/.test(c));
    const section = cells.findIndex((c) => /(subcapitulo|seccion|grupo)/.test(c));
    if (name >= 0 && (code >= 0 || unit >= 0 || price >= 0)) {
      return { headerRow: i, code, name, unit, price, chapter, section };
    }
  }
  return { headerRow: 0, code: 0, name: 1, unit: 2, price: 3, chapter: -1, section: -1 };
}

/* ------------------------------------------------------------------ */
/* POST ?mode=analyze  → hojas, encabezados y muestra de filas         */
/* POST ?mode=import   → importa con el mapeo indicado                 */
/* ------------------------------------------------------------------ */
export async function POST(req: Request) {
  await ensureCatalogSeeded();
  const url = new URL(req.url);
  const mode = url.searchParams.get("mode") ?? "import";
  const form = await req.formData();
  const file = form.get("file");

  if (!(file instanceof File)) {
    return NextResponse.json({ error: "Debe adjuntar el archivo Excel." }, { status: 400 });
  }
  if (file.size > 30 * 1024 * 1024) {
    return NextResponse.json({ error: "Archivo demasiado grande (máx. 30 MB)." }, { status: 400 });
  }

  const wb = XLSX.read(await file.arrayBuffer(), { type: "array" });

  /* ------------------------- ANALIZAR -------------------------- */
  if (mode === "analyze") {
    const requested = String(form.get("sheet") ?? "").trim();
    const sheet = requested && wb.SheetNames.includes(requested)
      ? requested
      : wb.SheetNames.find((n) => /listado.*precio|precios|lista.*precio/.test(norm(n)))
        ?? wb.SheetNames.find((n) => /presupuesto|item|actividad|insumo/.test(norm(n)))
        ?? wb.SheetNames[0];

    const ws = wb.Sheets[sheet];
    const rows = XLSX.utils.sheet_to_json<Cell[]>(ws, { header: 1, defval: null });
    const g = guess(rows);
    const header = (rows[g.headerRow] ?? []).map((c) => textOf(c));
    const colCount = Math.max(header.length, ...rows.slice(0, 60).map((r) => (r ?? []).length));
    const columnas = Array.from({ length: colCount }, (_, i) => ({
      index: i,
      letra: XLSX.utils.encode_col(i),
      encabezado: header[i] ?? "",
      muestra: rows.slice(g.headerRow + 1, g.headerRow + 6).map((r) => textOf((r ?? [])[i])).filter(Boolean).slice(0, 3),
    }));
    const preview = rows.slice(g.headerRow + 1, g.headerRow + 16).map((r) => (r ?? []).map(textOf));

    return NextResponse.json({
      hojas: wb.SheetNames,
      hoja: sheet,
      filas: Math.max(0, rows.length - g.headerRow - 1),
      sugerencia: g,
      columnas,
      preview,
    });
  }

  /* -------------------------- IMPORTAR ------------------------- */
  const num = (k: string, def = -1) => {
    const v = form.get(k);
    const n = v === null ? def : parseInt(String(v), 10);
    return isNaN(n) ? def : n;
  };
  const map: Mapping = {
    sheet: String(form.get("sheet") ?? wb.SheetNames[0]),
    headerRow: num("headerRow", 0),
    code: num("code"),
    name: num("name"),
    unit: num("unit"),
    price: num("price"),
    chapter: num("chapter"),
    section: num("section"),
  };
  const replacePrices = String(form.get("replacePrices") ?? "1") === "1";
  const defaultChapterCode = String(form.get("defaultChapterCode") ?? "90").trim() || "90";
  const defaultChapterName = String(form.get("defaultChapterName") ?? "CATÁLOGO IMPORTADO").trim();

  if (map.name < 0) {
    return NextResponse.json({ error: "Debe indicar al menos la columna de Descripción/Actividad." }, { status: 400 });
  }
  const ws = wb.Sheets[map.sheet];
  if (!ws) return NextResponse.json({ error: `La hoja «${map.sheet}» no existe.` }, { status: 422 });

  const rows = XLSX.utils.sheet_to_json<Cell[]>(ws, { header: 1, defval: null });

  const existing = await db.select().from(catalogActivities);
  const byCode = new Map(existing.map((a) => [a.code.trim().toUpperCase(), a]));

  const chapterNames = new Map<string, string>();
  const sectionNames = new Map<string, string>();
  const toInsert: (typeof catalogActivities.$inferInsert)[] = [];
  const priceUpdates: { id: string; price: number }[] = [];
  const muestraCreadas: { code: string; name: string; unit: string; price: number }[] = [];

  let leidas = 0, encabezados = 0, omitidas = 0, autoCode = 0, sinPrecio = 0;

  for (let i = map.headerRow + 1; i < rows.length; i++) {
    const r = rows[i] ?? [];
    const rawCode = map.code >= 0 ? textOf(r[map.code]) : "";
    const name = textOf(r[map.name]);
    const rawUnit = map.unit >= 0 ? textOf(r[map.unit]) : "";
    const rawPrice = map.price >= 0 ? r[map.price] : null;
    if (!name) continue;
    leidas++;

    const price = parsePrice(rawPrice);
    const hasUnit = !!rawUnit;

    // Filas de título (sin unidad ni precio) → capítulos / secciones
    if (!hasUnit && price === 0) {
      const segs = rawCode.split(/[.\-_/]/).filter(Boolean);
      if (segs.length === 1 && rawCode) { chapterNames.set(segs[0], name.toUpperCase()); encabezados++; continue; }
      if (segs.length === 2 && rawCode) { sectionNames.set(`${segs[0]}.${segs[1]}`, name); encabezados++; continue; }
      if (!rawCode) { omitidas++; continue; }
    }

    let code = rawCode;
    if (!code) { autoCode++; code = `IMP.${String(i).padStart(5, "0")}`; }
    const key = code.trim().toUpperCase();

    const unit = normalizeUnit(rawUnit || "UND");
    if (price === 0) sinPrecio++;

    // Capítulo/sección: de columnas dedicadas, o deducidos del código
    let chapterCode: string, chapterName: string, sectionCode: string, sectionName: string;
    const colChapter = map.chapter >= 0 ? textOf(r[map.chapter]) : "";
    const colSection = map.section >= 0 ? textOf(r[map.section]) : "";
    const split = splitCode(code);

    if (colChapter) {
      const m = colChapter.match(/^\s*([\w.]+)\s*[-–.]?\s*(.*)$/);
      chapterCode = (m?.[1] ?? colChapter).trim();
      chapterName = (m?.[2] || colChapter).trim().toUpperCase();
    } else if (/^\d/.test(code)) {
      chapterCode = split.chapter;
      chapterName = chapterNames.get(split.chapter) ?? `CAPÍTULO ${split.chapter}`;
    } else {
      chapterCode = defaultChapterCode;
      chapterName = defaultChapterName.toUpperCase();
    }
    if (colSection) {
      const m = colSection.match(/^\s*([\w.]+)\s*[-–.]?\s*(.*)$/);
      sectionCode = (m?.[1] ?? `${chapterCode}.01`).trim();
      sectionName = (m?.[2] || colSection).trim();
    } else if (/^\d/.test(code)) {
      sectionCode = split.section;
      sectionName = sectionNames.get(split.section) ?? `Sección ${split.section}`;
    } else {
      sectionCode = `${chapterCode}.01`;
      sectionName = "Ítems importados";
    }

    const found = byCode.get(key);
    if (found) {
      if (replacePrices && price > 0 && found.unitPrice !== price) priceUpdates.push({ id: found.id, price });
      continue;
    }
    if (toInsert.some((t) => t.code.trim().toUpperCase() === key)) { omitidas++; continue; }

    toInsert.push({
      code, name,
      chapterCode, chapterName: chapterName.toUpperCase(),
      sectionCode, sectionName,
      unit,
      method: methodForUnit(unit),
      keywords: keywordsFromName(name),
      ifcClasses: ifcClassesFromName(name, unit),
      unitPrice: price,
      priceSource: `${file.name} · hoja "${map.sheet}"`,
      description: null,
      origin: "LISTADO_PRECIOS",
      active: true,
    });
    if (muestraCreadas.length < 8) muestraCreadas.push({ code, name, unit, price });
  }

  // Completar nombres de capítulo/sección detectados después
  for (const row of toInsert) {
    const ch = chapterNames.get(row.chapterCode);
    if (ch) row.chapterName = ch;
    const se = sectionNames.get(row.sectionCode);
    if (se) row.sectionName = se;
  }

  const BATCH = 300;
  for (let i = 0; i < toInsert.length; i += BATCH) {
    const slice = toInsert.slice(i, i + BATCH);
    if (slice.length) await db.insert(catalogActivities).values(slice);
  }
  for (const u of priceUpdates) {
    await db.update(catalogActivities)
      .set({ unitPrice: u.price, priceSource: `${file.name} · hoja "${map.sheet}"` })
      .where(eq(catalogActivities.id, u.id));
  }
  await syncCatalogGroups();

  const [{ count } = { count: 0 }] = [{ count: (await db.select().from(catalogActivities)).length }];

  return NextResponse.json({
    ok: true,
    hoja: map.sheet,
    filasLeidas: leidas,
    encabezadosDetectados: encabezados,
    actividadesCreadas: toInsert.length,
    preciosActualizados: priceUpdates.length,
    duplicadasOmitidas: omitidas,
    codigosGenerados: autoCode,
    itemsSinPrecio: sinPrecio,
    totalCatalogo: count,
    muestra: muestraCreadas,
    aviso: "Unidad, método, palabras clave y clases IFC se SUGIRIERON a partir del nombre de cada ítem. Revíselos antes de usarlos en propuestas.",
  });
}
