import { NextResponse } from "next/server";
import { and, eq, ilike, inArray, or, sql } from "drizzle-orm";
import { db } from "@/db";
import { catalogActivities, catalogGroups, type MeasureConfig } from "@/db/schema";
import { ensureCatalogSeeded, syncCatalogGroups } from "@/lib/catalog";
import { sortByCode } from "@/lib/codes";
import { ensureCatalogGroup } from "@/lib/server";

const VALID_METHODS = [
  "SUPERFICIE_GEOMETRICA", "VOLUMEN_GEOMETRICO", "DIMENSION",
  "COUNT", "CANTIDAD_IFC", "COMPONENTES", "MANUAL",
];

/* ------------------------------------------------------------------ */
/* GET — búsqueda paginada (soporta catálogos de miles de ítems)       */
/* ------------------------------------------------------------------ */
export async function GET(req: Request) {
  await ensureCatalogSeeded();
  const url = new URL(req.url);
  const q = (url.searchParams.get("q") ?? "").trim();
  const chapter = url.searchParams.get("chapter");
  const onlyActive = url.searchParams.get("onlyActive") === "1";
  const limit = Math.min(parseInt(url.searchParams.get("limit") ?? "200", 10) || 200, 500);
  const offset = parseInt(url.searchParams.get("offset") ?? "0", 10) || 0;

  const conds = [];
  if (q) {
    const like = `%${q}%`;
    conds.push(or(ilike(catalogActivities.code, like), ilike(catalogActivities.name, like), ilike(catalogActivities.chapterName, like), ilike(catalogActivities.sectionName, like)));
  }
  if (chapter) conds.push(eq(catalogActivities.chapterCode, chapter));
  if (onlyActive) conds.push(eq(catalogActivities.active, true));

  const where = conds.length ? and(...conds) : undefined;

  // Orden jerárquico correcto (1, 2, … 10) en lugar del orden alfabético.
  const allMatching = await db.select().from(catalogActivities).where(where);
  const ordered = sortByCode(allMatching, (a) => a.code);
  const rows = ordered.slice(offset, offset + limit);

  const total = ordered.length;

  const groups = sortByCode(await db.select().from(catalogGroups), (g) => g.code);
  const inactiveChapters = new Set(groups.filter((g) => g.kind === "CAPITULO" && !g.active).map((g) => g.code));
  const inactiveSections = new Set(groups.filter((g) => g.kind === "SECCION" && !g.active).map((g) => g.code));

  const perChapter = await db
    .select({ chapterCode: catalogActivities.chapterCode, n: sql<number>`count(*)::int` })
    .from(catalogActivities)
    .groupBy(catalogActivities.chapterCode);
  const countByChapter = Object.fromEntries(perChapter.map((c) => [c.chapterCode, c.n]));
  const perSection = await db
    .select({ sectionCode: catalogActivities.sectionCode, n: sql<number>`count(*)::int` })
    .from(catalogActivities)
    .groupBy(catalogActivities.sectionCode);
  const countBySection = Object.fromEntries(perSection.map((c) => [c.sectionCode, c.n]));

  const flat = rows.map((a) => ({
    ...a,
    scopeActive: a.active && !inactiveChapters.has(a.chapterCode) && !inactiveSections.has(a.sectionCode),
  }));

  // Árbol solo de la página consultada (para la vista de catálogo)
  const chapters = new Map<string, { code: string; name: string; active: boolean; total: number; sections: Map<string, { code: string; name: string; active: boolean; total: number; activities: typeof flat }> }>();
  for (const a of flat) {
    if (!chapters.has(a.chapterCode)) {
      chapters.set(a.chapterCode, {
        code: a.chapterCode, name: a.chapterName,
        active: !inactiveChapters.has(a.chapterCode),
        total: countByChapter[a.chapterCode] ?? 0,
        sections: new Map(),
      });
    }
    const ch = chapters.get(a.chapterCode)!;
    if (!ch.sections.has(a.sectionCode)) {
      ch.sections.set(a.sectionCode, {
        code: a.sectionCode, name: a.sectionName,
        active: !inactiveSections.has(a.sectionCode),
        total: countBySection[a.sectionCode] ?? 0,
        activities: [],
      });
    }
    ch.sections.get(a.sectionCode)!.activities.push(a);
  }

  const tree = sortByCode(
    [...chapters.values()].map((c) => ({ ...c, sections: sortByCode([...c.sections.values()], (s2) => s2.code) })),
    (c) => c.code
  );

  return NextResponse.json({
    flat,
    tree,
    total,
    limit,
    offset,
    capitulos: sortByCode(groups.filter((g) => g.kind === "CAPITULO"), (g) => g.code)
      .map((g) => ({ ...g, actividades: countByChapter[g.code] ?? 0 })),
    secciones: sortByCode(groups.filter((g) => g.kind === "SECCION"), (g) => g.code)
      .map((g) => ({ ...g, actividades: countBySection[g.code] ?? 0 })),
  });
}

/* ------------------------------------------------------------------ */
/* POST — crear actividad (nueva, o duplicando una existente)          */
/* ------------------------------------------------------------------ */
export async function POST(req: Request) {
  const body = await req.json();
  const {
    duplicateFrom, code, name, chapterCode, chapterName, sectionCode, sectionName,
    unit, method, keywords, ifcClasses, description, unitPrice, measureConfig,
  } = body ?? {};

  let base: typeof catalogActivities.$inferSelect | undefined;
  if (duplicateFrom) {
    const [row] = await db.select().from(catalogActivities).where(eq(catalogActivities.id, duplicateFrom)).limit(1);
    base = row;
  }

  const finalCode = String(code ?? "").trim();
  const finalName = String(name ?? base?.name ?? "").trim();
  const finalChapterCode = String(chapterCode ?? base?.chapterCode ?? "").trim();
  const finalChapterName = String(chapterName ?? base?.chapterName ?? "").trim();
  const finalSectionCode = String(sectionCode ?? base?.sectionCode ?? "").trim();
  const finalSectionName = String(sectionName ?? base?.sectionName ?? "").trim();
  const finalUnit = String(unit ?? base?.unit ?? "").trim().toUpperCase();
  const finalMethod = String(method ?? base?.method ?? "MANUAL");

  if (!finalCode || !finalName || !finalChapterCode || !finalChapterName || !finalSectionCode || !finalSectionName || !finalUnit) {
    return NextResponse.json({ error: "Faltan campos obligatorios (código, nombre, capítulo, sección, unidad)." }, { status: 400 });
  }
  if (!VALID_METHODS.includes(finalMethod)) {
    return NextResponse.json({ error: "Método de medición inválido." }, { status: 400 });
  }

  const dup = await db.select({ n: sql<number>`count(*)::int` }).from(catalogActivities).where(eq(catalogActivities.code, finalCode));
  if ((dup[0]?.n ?? 0) > 0) {
    return NextResponse.json({ error: `El código ${finalCode} ya existe en el catálogo maestro.` }, { status: 409 });
  }

  const toArray = (v: unknown, upper = false): string[] => {
    if (Array.isArray(v)) return v.map((s) => (upper ? String(s).toUpperCase() : String(s).toLowerCase()).trim()).filter(Boolean);
    if (typeof v === "string") return v.split(",").map((s) => (upper ? s.toUpperCase() : s.toLowerCase()).trim()).filter(Boolean);
    return [];
  };

  const [created] = await db.insert(catalogActivities).values({
    code: finalCode,
    name: finalName,
    chapterCode: finalChapterCode,
    chapterName: finalChapterName.toUpperCase(),
    sectionCode: finalSectionCode,
    sectionName: finalSectionName,
    unit: finalUnit,
    method: finalMethod as typeof catalogActivities.$inferInsert["method"],
    measureConfig: (measureConfig as MeasureConfig | undefined) ?? (base?.measureConfig as MeasureConfig | null) ?? null,
    keywords: keywords !== undefined ? toArray(keywords) : base?.keywords ?? [],
    ifcClasses: ifcClasses !== undefined ? toArray(ifcClasses, true) : base?.ifcClasses ?? [],
    unitPrice: typeof unitPrice === "number" ? unitPrice : base?.unitPrice ?? 0,
    description: description ?? base?.description ?? null,
    origin: duplicateFrom ? "DUPLICADA" : "USUARIO",
    active: true,
  }).returning();

  await ensureCatalogGroup("CAPITULO", finalChapterCode, finalChapterName.toUpperCase(), null);
  await ensureCatalogGroup("SECCION", finalSectionCode, finalSectionName, finalChapterCode);

  return NextResponse.json({ activity: created });
}

/* ------------------------------------------------------------------ */
/* PATCH — activar/desactivar o editar una actividad                   */
/* ------------------------------------------------------------------ */
export async function PATCH(req: Request) {
  const body = await req.json();
  const { id, ids, active, unitPrice, unit, method, keywords, ifcClasses, name, description, measureConfig } = body ?? {};

  if (Array.isArray(ids) && ids.length && typeof active === "boolean") {
    await db.update(catalogActivities).set({ active }).where(inArray(catalogActivities.id, ids as string[]));
    return NextResponse.json({ ok: true, afectadas: ids.length });
  }
  if (!id) return NextResponse.json({ error: "id requerido." }, { status: 400 });

  const patch: Partial<typeof catalogActivities.$inferInsert> = {};
  if (typeof active === "boolean") patch.active = active;
  if (typeof unitPrice === "number") patch.unitPrice = unitPrice;
  if (typeof unit === "string" && unit.trim()) patch.unit = unit.trim().toUpperCase();
  if (typeof name === "string" && name.trim()) patch.name = name.trim();
  if (typeof description === "string") patch.description = description;
  if (typeof method === "string" && VALID_METHODS.includes(method)) {
    patch.method = method as typeof catalogActivities.$inferInsert["method"];
  }
  if (measureConfig !== undefined) patch.measureConfig = measureConfig as MeasureConfig;
  if (keywords !== undefined) {
    patch.keywords = Array.isArray(keywords)
      ? keywords.map((k: string) => String(k).toLowerCase().trim()).filter(Boolean)
      : String(keywords).split(",").map((k) => k.toLowerCase().trim()).filter(Boolean);
  }
  if (ifcClasses !== undefined) {
    patch.ifcClasses = Array.isArray(ifcClasses)
      ? ifcClasses.map((k: string) => String(k).toUpperCase().trim()).filter(Boolean)
      : String(ifcClasses).split(",").map((k) => k.toUpperCase().trim()).filter(Boolean);
  }
  if (!Object.keys(patch).length) return NextResponse.json({ error: "Nada que actualizar." }, { status: 400 });

  await db.update(catalogActivities).set(patch).where(eq(catalogActivities.id, id));
  await syncCatalogGroups();
  return NextResponse.json({ ok: true });
}
