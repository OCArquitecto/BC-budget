import { NextResponse } from "next/server";
import { and, eq, sql } from "drizzle-orm";
import { db } from "@/db";
import { catalogActivities, catalogGroups } from "@/db/schema";
import { syncCatalogGroups } from "@/lib/catalog";
import { ensureCatalogGroup } from "@/lib/server";
import { sortByCode } from "@/lib/codes";

/** Lista capítulos y secciones con su conteo de actividades. */
export async function GET() {
  await syncCatalogGroups();
  const groups = sortByCode(await db.select().from(catalogGroups), (g) => g.code);
  const perChapter = await db
    .select({ code: catalogActivities.chapterCode, n: sql<number>`count(*)::int` })
    .from(catalogActivities).groupBy(catalogActivities.chapterCode);
  const perSection = await db
    .select({ code: catalogActivities.sectionCode, n: sql<number>`count(*)::int` })
    .from(catalogActivities).groupBy(catalogActivities.sectionCode);
  const cc = Object.fromEntries(perChapter.map((r) => [r.code, r.n]));
  const sc = Object.fromEntries(perSection.map((r) => [r.code, r.n]));

  return NextResponse.json({
    capitulos: sortByCode(groups.filter((g) => g.kind === "CAPITULO"), (g) => g.code).map((g) => ({ ...g, actividades: cc[g.code] ?? 0 })),
    secciones: sortByCode(groups.filter((g) => g.kind === "SECCION"), (g) => g.code).map((g) => ({ ...g, actividades: sc[g.code] ?? 0 })),
  });
}

/** Crea un capítulo o sección. */
export async function POST(req: Request) {
  const body = await req.json();
  const { kind, code, name, parentCode } = body ?? {};
  if (!kind || !code || !name) {
    return NextResponse.json({ error: "kind, code y name son obligatorios." }, { status: 400 });
  }
  if (!["CAPITULO", "SECCION"].includes(kind)) {
    return NextResponse.json({ error: "kind debe ser CAPITULO o SECCION." }, { status: 400 });
  }
  const created = await ensureCatalogGroup(
    kind, String(code).trim(),
    kind === "CAPITULO" ? String(name).trim().toUpperCase() : String(name).trim(),
    parentCode ?? null
  );
  return NextResponse.json({ group: created });
}

/**
 * Activa o desactiva un capítulo/sección completo, o lo renombra.
 * Apagar un capítulo excluye TODAS sus actividades de las propuestas
 * automáticas, sin borrar nada del catálogo.
 */
export async function PATCH(req: Request) {
  const body = await req.json();
  const { kind, code, active, name } = body ?? {};
  if (!kind || !code) return NextResponse.json({ error: "kind y code requeridos." }, { status: 400 });

  const patch: Partial<typeof catalogGroups.$inferInsert> = {};
  if (typeof active === "boolean") patch.active = active;
  if (typeof name === "string" && name.trim()) patch.name = kind === "CAPITULO" ? name.trim().toUpperCase() : name.trim();
  if (!Object.keys(patch).length) return NextResponse.json({ error: "Nada que actualizar." }, { status: 400 });

  await db.update(catalogGroups).set(patch)
    .where(and(eq(catalogGroups.kind, kind), eq(catalogGroups.code, code)));

  // Renombrar propaga el nombre a las actividades del capítulo/sección
  if (patch.name) {
    if (kind === "CAPITULO") {
      await db.update(catalogActivities).set({ chapterName: patch.name })
        .where(eq(catalogActivities.chapterCode, code));
    } else {
      await db.update(catalogActivities).set({ sectionName: patch.name })
        .where(eq(catalogActivities.sectionCode, code));
    }
  }

  // Al apagar una sección o capítulo se marcan también sus secciones hijas
  if (kind === "CAPITULO" && typeof active === "boolean") {
    await db.update(catalogGroups).set({ active })
      .where(and(eq(catalogGroups.kind, "SECCION"), eq(catalogGroups.parentCode, code)));
  }

  return NextResponse.json({ ok: true });
}
