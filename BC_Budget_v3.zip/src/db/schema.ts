import {
  pgTable,
  uuid,
  text,
  integer,
  doublePrecision,
  boolean,
  jsonb,
  timestamp,
  index,
} from "drizzle-orm/pg-core";

/* ================================================================== */
/*  TIPOS COMPARTIDOS                                                 */
/* ================================================================== */
export type MeasurementMethod =
  | "SUPERFICIE_GEOMETRICA"
  | "VOLUMEN_GEOMETRICO"
  | "DIMENSION"
  | "COUNT"
  | "CANTIDAD_IFC"
  | "COMPONENTES"
  | "MANUAL";

export interface MeasureConfig {
  areaBasis?: "NETA" | "BRUTA" | "UNA_CARA" | "DOS_CARAS" | "LATERAL" | "PLANTA" | "SUPERFICIE_TOTAL";
  dimension?: "LARGO" | "ALTO" | "ANCHO" | "ESPESOR" | "PERIMETRO";
  volumeBasis?: "NETO" | "BRUTO";
  factor?: number;
  note?: string;
}

export interface ElementDimensions {
  length?: number | null;
  width?: number | null;
  height?: number | null;
  thickness?: number | null;
  area?: number | null;
  grossArea?: number | null;
  netArea?: number | null;
  surfaceArea?: number | null;
  crossSectionArea?: number | null;
  perimeter?: number | null;
  volume?: number | null;
  netVolume?: number | null;
  count?: number | null;
}

export interface ElementGeometry {
  kind: string;
  size: [number, number, number];
  center: [number, number, number];
  yaw: number;
  face?: {
    outline: [number, number][];
    holes: [number, number][][];
    thickness: number;
    origin: [number, number, number];
    uAxis: [number, number, number];
    vAxis: [number, number, number];
    nAxis: [number, number, number];
    clipped: boolean;
    exactArea?: number;
  };
  openings?: { width: number; height: number; area: number; name: string | null }[];
  oriented?: {
    size: [number, number, number];
    center: [number, number, number];
    axes: [[number, number, number], [number, number, number], [number, number, number]];
  };
}

export interface CompanyInfo {
  name?: string;
  nit?: string;
  address?: string;
  phone?: string;
  email?: string;
  responsible?: string;
  role?: string;
  license?: string;
  logo?: string;
}

export interface DocumentTemplate {
  budgetTitle?: string;
  budgetSubtitle?: string;
  budgetIntroduction?: string;
  budgetScope?: string;
  reportTitle?: string;
  reportSubtitle?: string;
  reportIntroduction?: string;
  reportScope?: string;
  sourcesTitle?: string;
  decisionsTitle?: string;
  observationsTitle?: string;
  footerText?: string;
  preparedByLabel?: string;
  reviewedByLabel?: string;
  showCompany?: boolean;
  showPrices?: boolean;
  showAIU?: boolean;
}

export interface ProjectSettings {
  administracion?: number;
  imprevistos?: number;
  utilidad?: number;
  iva?: number;
  ivaSobreUtilidad?: boolean;
  ivaBases?: ("DIRECTO" | "ADMINISTRACION" | "IMPREVISTOS" | "UTILIDAD")[];
  currency?: string;
  notes?: string;
  documents?: DocumentTemplate;
}

/* ================================================================== */
/*  BIMCOST QUANTITY (bc_*)                                           */
/* ================================================================== */
export const projects = pgTable("bc_projects", {
  id: uuid("id").defaultRandom().primaryKey(),
  code: text("code").notNull(),
  name: text("name").notNull(),
  client: text("client"),
  location: text("location"),
  description: text("description"),
  units: text("units").notNull().default("SI"),
  status: text("status").notNull().default("ACTIVO"),
  company: jsonb("company").$type<CompanyInfo>(),
  settings: jsonb("settings").$type<ProjectSettings>(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export type SourceKind = "IFC" | "EXCEL" | "MANUAL" | "TEMPLATE";

export const sources = pgTable(
  "bc_sources",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    projectId: uuid("project_id")
      .notNull()
      .references(() => projects.id, { onDelete: "cascade" }),
    kind: text("kind").notNull().$type<SourceKind>(),
    name: text("name").notNull(),
    discipline: text("discipline"),
    fileName: text("file_name"),
    fileSize: integer("file_size"),
    ifcSchema: text("ifc_schema"),
    contentHash: text("content_hash"),
    modelHash: text("model_hash"),
    status: text("status").notNull().default("ACTIVA"),
    stats: jsonb("stats").$type<Record<string, unknown>>(),
    meta: jsonb("meta").$type<Record<string, unknown>>(),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (t) => [index("sources_project_idx").on(t.projectId)]
);

export const elements = pgTable(
  "bc_elements",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    projectId: uuid("project_id")
      .notNull()
      .references(() => projects.id, { onDelete: "cascade" }),
    sourceId: uuid("source_id")
      .notNull()
      .references(() => sources.id, { onDelete: "cascade" }),
    globalId: text("global_id"),
    ifcClass: text("ifc_class").notNull(),
    name: text("name"),
    objectType: text("object_type"),
    description: text("description"),
    typeName: text("type_name"),
    semanticType: text("semantic_type"),
    material: text("material"),
    level: text("level"),
    layer: text("layer"),
    tag: text("tag"),
    properties: jsonb("properties").$type<
      Record<string, Record<string, string | number | boolean | null>>
    >(),
    quantities: jsonb("quantities").$type<Record<string, number>>(),
    dimensions: jsonb("dimensions").$type<ElementDimensions>(),
    dimensionSources: jsonb("dimension_sources").$type<Record<string, string>>(),
    geometry: jsonb("geometry").$type<ElementGeometry | null>(),
    excluded: boolean("excluded").notNull().default(false),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (t) => [
    index("elements_project_idx").on(t.projectId),
    index("elements_source_idx").on(t.sourceId),
    index("elements_global_idx").on(t.projectId, t.globalId),
  ]
);

export const groupingRuns = pgTable(
  "bc_grouping_runs",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    projectId: uuid("project_id")
      .notNull()
      .references(() => projects.id, { onDelete: "cascade" }),
    sourceIds: jsonb("source_ids").$type<string[]>().notNull(),
    criteria: jsonb("criteria").$type<string[]>().notNull(),
    excludedClasses: jsonb("excluded_classes").$type<string[]>().notNull().default([]),
    elementCount: integer("element_count").notNull().default(0),
    groupCount: integer("group_count").notNull().default(0),
    durationMs: integer("duration_ms").notNull().default(0),
    createdBy: text("created_by"),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (t) => [index("runs_project_idx").on(t.projectId)]
);

export const groups = pgTable(
  "bc_groups",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    runId: uuid("run_id")
      .notNull()
      .references(() => groupingRuns.id, { onDelete: "cascade" }),
    projectId: uuid("project_id")
      .notNull()
      .references(() => projects.id, { onDelete: "cascade" }),
    groupKey: text("group_key").notNull(),
    criteriaValues: jsonb("criteria_values").$type<Record<string, string>>().notNull(),
    elementIds: jsonb("element_ids").$type<string[]>().notNull(),
    elementCount: integer("element_count").notNull().default(0),
    ifcClasses: jsonb("ifc_classes").$type<string[]>().notNull(),
    semanticTypes: jsonb("semantic_types").$type<string[]>().notNull().default([]),
    sourceIds: jsonb("source_ids").$type<string[]>().notNull(),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (t) => [index("groups_run_idx").on(t.runId), index("groups_project_idx").on(t.projectId)]
);

export const catalogGroups = pgTable(
  "bc_catalog_groups",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    kind: text("kind").notNull().$type<"CAPITULO" | "SECCION">(),
    code: text("code").notNull(),
    name: text("name").notNull(),
    parentCode: text("parent_code"),
    active: boolean("active").notNull().default(true),
    sortOrder: integer("sort_order").notNull().default(0),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (t) => [index("catalog_groups_code_idx").on(t.kind, t.code)]
);

export const catalogActivities = pgTable("bc_catalog_activities", {
  id: uuid("id").defaultRandom().primaryKey(),
  code: text("code").notNull().unique(),
  chapterCode: text("chapter_code").notNull(),
  chapterName: text("chapter_name").notNull(),
  sectionCode: text("section_code").notNull(),
  sectionName: text("section_name").notNull(),
  name: text("name").notNull(),
  unit: text("unit").notNull(),
  method: text("method").notNull().$type<MeasurementMethod>(),
  measureConfig: jsonb("measure_config").$type<MeasureConfig>(),
  keywords: jsonb("keywords").$type<string[]>().notNull().default([]),
  ifcClasses: jsonb("ifc_classes").$type<string[]>().notNull().default([]),
  unitPrice: doublePrecision("unit_price").notNull().default(0),
  priceSource: text("price_source"),
  description: text("description"),
  origin: text("origin").notNull().default("SEED"),
  active: boolean("active").notNull().default(true),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export type MatchStatus = "PENDIENTE" | "PROPUESTA" | "VALIDADA" | "RECHAZADA";

export interface MatchCandidate {
  activityId: string;
  code: string;
  name: string;
  unit: string;
  method: string;
  score: number;
  matched: string[];
  classOk: boolean;
}

export const matches = pgTable(
  "bc_matches",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    projectId: uuid("project_id")
      .notNull()
      .references(() => projects.id, { onDelete: "cascade" }),
    runId: uuid("run_id")
      .notNull()
      .references(() => groupingRuns.id, { onDelete: "cascade" }),
    groupId: uuid("group_id")
      .notNull()
      .references(() => groups.id, { onDelete: "cascade" }),
    activityId: uuid("activity_id").references(() => catalogActivities.id),
    score: doublePrecision("score").notNull().default(0),
    status: text("status").notNull().$type<MatchStatus>().default("PENDIENTE"),
    candidates: jsonb("candidates").$type<MatchCandidate[]>().notNull().default([]),
    evidence: jsonb("evidence").$type<Record<string, unknown>>(),
    decidedBy: text("decided_by"),
    decidedAt: timestamp("decided_at"),
    decisionNote: text("decision_note"),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (t) => [index("matches_project_idx").on(t.projectId)]
);

export type QuantityStatus = "PENDIENTE" | "PROPUESTA" | "VALIDADA" | "RECHAZADA";

export const quantities = pgTable(
  "bc_quantities",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    projectId: uuid("project_id")
      .notNull()
      .references(() => projects.id, { onDelete: "cascade" }),
    matchId: uuid("match_id"),
    groupId: uuid("group_id"),
    activityId: uuid("activity_id").references(() => catalogActivities.id),
    sourceId: uuid("source_id").references(() => sources.id),
    sourceKind: text("source_kind").notNull().default("MANUAL"),
    derivedFromId: uuid("derived_from_id"),
    label: text("label"),
    value: doublePrecision("value"),
    unit: text("unit").notNull(),
    method: text("method").notNull(),
    measureConfig: jsonb("measure_config").$type<MeasureConfig>(),
    rule: text("rule"),
    evidence: jsonb("evidence").$type<Record<string, unknown>>(),
    elementIds: jsonb("element_ids").$type<string[]>().notNull().default([]),
    elementGlobalIds: jsonb("element_global_ids").$type<string[]>().notNull().default([]),
    elementCount: integer("element_count").notNull().default(0),
    status: text("status").notNull().$type<QuantityStatus>().default("PROPUESTA"),
    note: text("note"),
    validatedBy: text("validated_by"),
    validatedAt: timestamp("validated_at"),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (t) => [index("quantities_project_idx").on(t.projectId)]
);

export const structureNodes = pgTable(
  "bc_structure_nodes",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    projectId: uuid("project_id")
      .notNull()
      .references(() => projects.id, { onDelete: "cascade" }),
    parentId: uuid("parent_id"),
    kind: text("kind").notNull().$type<"CAPITULO" | "SECCION" | "ACTIVIDAD">(),
    code: text("code").notNull(),
    name: text("name").notNull(),
    activityId: uuid("activity_id"),
    sortOrder: integer("sort_order").notNull().default(0),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (t) => [index("structure_project_idx").on(t.projectId)]
);

export const decisions = pgTable(
  "bc_decisions",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    projectId: uuid("project_id")
      .notNull()
      .references(() => projects.id, { onDelete: "cascade" }),
    entityType: text("entity_type").notNull(),
    entityId: text("entity_id"),
    action: text("action").notNull(),
    detail: jsonb("detail").$type<Record<string, unknown>>(),
    actor: text("actor"),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (t) => [index("decisions_project_idx").on(t.projectId)]
);

/* ================================================================== */
/*  BIMCOST BUDGET — TABLAS (bb_*)                                     */
/* ================================================================== */

export interface SourceBcqMeta {
  packageId?: string;
  projectId?: string;
  projectCode?: string;
  projectName?: string;
  revision?: string;
  exportedAt?: string;
  producerVersion?: string;
  totalQuantities?: number;
  totalElements?: number;
  totalDecisions?: number;
}

export const budgetProjects = pgTable("bb_projects", {
  id: uuid("id").defaultRandom().primaryKey(),
  code: text("code").notNull(),
  name: text("name").notNull(),
  client: text("client"),
  location: text("location"),
  /** Zona de precios: ciudad, departamento o región de referencia. */
  region: text("region").notNull().default("COLOMBIA"),
  /** Fecha de corte de los precios del presupuesto. */
  priceDate: timestamp("price_date").notNull().defaultNow(),
  description: text("description"),
  currency: text("currency").notNull().default("COP"),
  status: text("status").notNull().default("ACTIVO"),
  sourceBcq: jsonb("source_bcq").$type<SourceBcqMeta>(),
  company: jsonb("company").$type<CompanyInfo>(),
  settings: jsonb("settings").$type<ProjectSettings>(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export interface RevisionSummary {
  packageId: string;
  revisionName: string;
  totalActivities: number;
  totalDirectCost: number;
  diffSummary?: {
    activitiesAdded: { code: string; name: string; unit: string; quantity: number }[];
    activitiesModified: { code: string; name: string; unit: string; oldQuantity: number; newQuantity: number; diff: number }[];
    activitiesRemoved: { code: string; name: string }[];
    costDifference: number;
  };
}

export const budgetRevisions = pgTable(
  "bb_revisions",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    projectId: uuid("project_id")
      .notNull()
      .references(() => budgetProjects.id, { onDelete: "cascade" }),
    revisionNumber: integer("revision_number").notNull().default(1),
    revisionName: text("revision_name").notNull(),
    packageId: text("package_id"),
    summary: jsonb("summary").$type<RevisionSummary>(),
    snapshotData: jsonb("snapshot_data").$type<Record<string, unknown>>(),
    importedBy: text("imported_by"),
    importedAt: timestamp("imported_at").notNull().defaultNow(),
  },
  (t) => [index("revisions_project_idx").on(t.projectId)]
);

export type InsumoCategory = "MATERIAL" | "MANO_DE_OBRA" | "EQUIPO" | "TRANSPORTE" | "SUBCONTRATO";

export const masterInsumos = pgTable("bb_insumos", {
  id: uuid("id").defaultRandom().primaryKey(),
  code: text("code").notNull().unique(),
  name: text("name").notNull(),
  unit: text("unit").notNull(),
  category: text("category").notNull().$type<InsumoCategory>(),
  unitPrice: doublePrecision("unit_price").notNull().default(0),
  currency: text("currency").notNull().default("COP"),
  /** Precio vigente preferido para esta zona. */
  region: text("region").notNull().default("COLOMBIA"),
  priceDate: timestamp("price_date").notNull().defaultNow(),
  supplier: text("supplier"),
  source: text("source"),
  validUntil: timestamp("valid_until"),
  notes: text("notes"),
  active: boolean("active").notNull().default(true),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const masterApus = pgTable(
  "bb_apus",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    /** Código único de la versión (p. ej. APU-04.01@ANT-2026-01). */
    code: text("code").notNull().unique(),
    /** Familia estable que agrupa versiones regionales del mismo APU. */
    familyCode: text("family_code").notNull().default("GENERAL"),
    /** Código de actividad técnica compatible de Quantity, si existe. */
    activityCode: text("activity_code"),
    name: text("name").notNull(),
    unit: text("unit").notNull(),
    category: text("category").notNull().default("GENERAL"),
    description: text("description"),
    unitCost: doublePrecision("unit_cost").notNull().default(0),
    rendimientoJornal: doublePrecision("rendimiento_jornal"),
    versionLabel: text("version_label").notNull().default("V1"),
    region: text("region").notNull().default("COLOMBIA"),
    currency: text("currency").notNull().default("COP"),
    effectiveDate: timestamp("effective_date").notNull().defaultNow(),
    validUntil: timestamp("valid_until"),
    source: text("source").notNull().default("BANCO_EMPRESA"),
    /** Banco inicial = plantilla por revisar; empresa = dato validado. */
    priceStatus: text("price_status").notNull().default("PENDIENTE_ACTUALIZAR"),
    isPreferred: boolean("is_preferred").notNull().default(false),
    active: boolean("active").notNull().default(true),
    createdAt: timestamp("created_at").notNull().defaultNow(),
    updatedAt: timestamp("updated_at").notNull().defaultNow(),
  },
  (t) => [
    index("apus_family_idx").on(t.familyCode),
    index("apus_activity_idx").on(t.activityCode),
    index("apus_region_idx").on(t.region),
  ]
);

export const apuItems = pgTable(
  "bb_apu_items",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    apuId: uuid("apu_id")
      .notNull()
      .references(() => masterApus.id, { onDelete: "cascade" }),
    insumoId: uuid("insumo_id").references(() => masterInsumos.id),
    category: text("category").notNull().$type<InsumoCategory>(),
    description: text("description").notNull(),
    unit: text("unit").notNull(),
    quantity: doublePrecision("quantity").notNull().default(1),
    wastePercentage: doublePrecision("waste_percentage").notNull().default(0),
    unitPrice: doublePrecision("unit_price").notNull().default(0),
    subtotal: doublePrecision("subtotal").notNull().default(0),
    sortOrder: integer("sort_order").notNull().default(0),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (t) => [index("apu_items_apu_idx").on(t.apuId)]
);

/* Historial regional y temporal de precios de insumos. */
export const insumoPrices = pgTable(
  "bb_insumo_prices",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    insumoId: uuid("insumo_id")
      .notNull()
      .references(() => masterInsumos.id, { onDelete: "cascade" }),
    projectId: uuid("project_id").references(() => budgetProjects.id, { onDelete: "set null" }),
    region: text("region").notNull().default("COLOMBIA"),
    currency: text("currency").notNull().default("COP"),
    price: doublePrecision("price").notNull(),
    supplier: text("supplier"),
    source: text("source"),
    effectiveDate: timestamp("effective_date").notNull().defaultNow(),
    validUntil: timestamp("valid_until"),
    createdBy: text("created_by"),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (t) => [index("insumo_prices_idx").on(t.insumoId, t.region, t.effectiveDate)]
);

/* Snapshot inmutable de cada actualización de un APU de la empresa. */
export const apuVersions = pgTable(
  "bb_apu_versions",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    apuId: uuid("apu_id")
      .notNull()
      .references(() => masterApus.id, { onDelete: "cascade" }),
    versionLabel: text("version_label").notNull(),
    region: text("region").notNull(),
    effectiveDate: timestamp("effective_date").notNull(),
    currency: text("currency").notNull().default("COP"),
    unitCost: doublePrecision("unit_cost").notNull(),
    source: text("source"),
    components: jsonb("components").$type<BudgetItemApuSnapshot["components"]>().notNull().default([]),
    notes: text("notes"),
    createdBy: text("created_by"),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (t) => [index("apu_versions_idx").on(t.apuId, t.region, t.effectiveDate)]
);

export const budgetNodes = pgTable(
  "bb_budget_nodes",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    projectId: uuid("project_id")
      .notNull()
      .references(() => budgetProjects.id, { onDelete: "cascade" }),
    parentId: uuid("parent_id"),
    kind: text("kind").notNull().$type<"CAPITULO" | "SECCION" | "ACTIVIDAD">(),
    code: text("code").notNull(),
    name: text("name").notNull(),
    activityId: text("activity_id"),
    unit: text("unit"),
    sortOrder: integer("sort_order").notNull().default(0),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (t) => [index("budget_nodes_project_idx").on(t.projectId)]
);

export type BudgetItemStatus =
  | "APU_ASIGNADO"
  | "SIN_APU"
  | "PRECIO_IMPORTADO"
  | "CANTIDAD_MODIFICADA"
  | "REVISION_PENDIENTE";

export interface BudgetItemApuSnapshot {
  apuId?: string;
  code: string;
  name: string;
  unit: string;
  unitCost: number;
  components: {
    category: InsumoCategory;
    description: string;
    unit: string;
    quantity: number;
    wastePercentage: number;
    unitPrice: number;
    subtotal: number;
  }[];
}

export interface QuantitySourceMeta {
  sources?: string[];
  elementCount?: number;
  elementGlobalIds?: string[];
  method?: string;
  rule?: string;
  validatedBy?: string;
  validatedAt?: string;
  derivedFrom?: {
    activityCode?: string;
    parentQuantity?: number;
    ruleApplied?: string;
  };
}

export const budgetItems = pgTable(
  "bb_budget_items",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    projectId: uuid("project_id")
      .notNull()
      .references(() => budgetProjects.id, { onDelete: "cascade" }),
    nodeId: uuid("node_id")
      .notNull()
      .references(() => budgetNodes.id, { onDelete: "cascade" }),
    activityCode: text("activity_code").notNull(),
    activityName: text("activity_name").notNull(),
    unit: text("unit").notNull(),
    quantityBcq: doublePrecision("quantity_bcq").notNull().default(0),
    quantityOverride: doublePrecision("quantity_override"),
    overrideReason: text("override_reason"),
    finalQuantity: doublePrecision("final_quantity").notNull().default(0),
    /** Precio unitario recibido de Quantity: referencia, no APU validado. */
    referenceUnitPrice: doublePrecision("reference_unit_price").notNull().default(0),
    referencePriceSource: text("reference_price_source"),
    /** Pendiente de convertir/validar como APU de la empresa. */
    priceReviewRequired: boolean("price_review_required").notNull().default(false),
    apuId: uuid("apu_id").references(() => masterApus.id),
    customApu: jsonb("custom_apu").$type<BudgetItemApuSnapshot>(),
    unitCost: doublePrecision("unit_cost").notNull().default(0),
    directCost: doublePrecision("direct_cost").notNull().default(0),
    sourceMeta: jsonb("source_meta").$type<QuantitySourceMeta>(),
    status: text("status").notNull().$type<BudgetItemStatus>().default("SIN_APU"),
    notes: text("notes"),
    createdAt: timestamp("created_at").notNull().defaultNow(),
    updatedAt: timestamp("updated_at").notNull().defaultNow(),
  },
  (t) => [index("budget_items_project_idx").on(t.projectId)]
);

export const budgetDecisions = pgTable(
  "bb_decisions",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    projectId: uuid("project_id")
      .notNull()
      .references(() => budgetProjects.id, { onDelete: "cascade" }),
    entityType: text("entity_type").notNull(),
    entityId: text("entity_id"),
    action: text("action").notNull(),
    detail: jsonb("detail").$type<Record<string, unknown>>(),
    actor: text("actor"),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (t) => [index("budget_decisions_project_idx").on(t.projectId)]
);
