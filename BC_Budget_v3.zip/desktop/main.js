/* ==================================================================
 *  BIMCost Budget Desktop — ventana nativa
 *  ------------------------------------------------------------------
 *  El backend y PostgreSQL viven en Docker (persistencia y robustez).
 *  Esta aplicación abre BIMCost en una ventana nativa de Electron,
 *  con mayor límite de memoria que una pestaña convencional.
 * ================================================================== */
"use strict";

const { app, BrowserWindow, dialog, ipcMain, shell, Menu } = require("electron");
const { spawn, spawnSync } = require("node:child_process");
const fs = require("node:fs");
const path = require("node:path");
const http = require("node:http");

const APP_URL = process.env.BIMCOST_URL || "http://127.0.0.1:3001";
let mainWindow = null;

function docker(args, opts = {}) {
  return spawnSync("docker", args, { encoding: "utf8", windowsHide: true, ...opts });
}

function ensureDockerBackend() {
  const version = docker(["version"]);
  if (version.status !== 0) {
    throw new Error(
      "Docker Desktop no está funcionando.\n\n" +
      "Abra Docker Desktop, espere ‘Engine running’ y vuelva a abrir BIMCost Budget."
    );
  }
  // Los contenedores ya fueron creados por INSTALAR.bat. Si están detenidos,
  // iniciarlos no requiere conocer la ubicación original del proyecto.
  docker(["start", "bimcost-budget-db", "bimcost-budget-app"]);
}

function waitForServer(timeoutMs = 120000) {
  const start = Date.now();
  return new Promise((resolve, reject) => {
    const tick = () => {
      const req = http.get(`${APP_URL}/api/health`, (res) => {
        let body = "";
        res.on("data", (d) => { body += d; });
        res.on("end", () => {
          if (res.statusCode && res.statusCode < 500) {
            try { return resolve(JSON.parse(body)); } catch { return resolve({ ok: true }); }
          }
          retry();
        });
      });
      req.on("error", retry);
      req.setTimeout(2500, () => { req.destroy(); retry(); });
    };
    const retry = () => {
      if (Date.now() - start > timeoutMs) {
        return reject(new Error("BIMCost no respondió. Ejecute INSTALAR.bat para actualizar el backend."));
      }
      setTimeout(tick, 800);
    };
    tick();
  });
}

function createWindow(health) {
  mainWindow = new BrowserWindow({
    width: 1640,
    height: 1000,
    minWidth: 1100,
    minHeight: 700,
    backgroundColor: "#0a0e15",
    show: false,
    title: `BIMCost Budget ${health?.version ? `v${health.version}` : ""}`,
    webPreferences: {
      preload: path.join(__dirname, "preload.js"),
      contextIsolation: true,
      nodeIntegration: false,
      spellcheck: false,
      // El renderer puede usar varios GB para el visor sin las restricciones
      // habituales de una pestaña compartida con otras páginas.
      v8CacheOptions: "bypassHeatCheck",
    },
  });

  mainWindow.once("ready-to-show", () => mainWindow.show());
  mainWindow.loadURL(APP_URL);

  mainWindow.webContents.setWindowOpenHandler(({ url }) => {
    if (!url.startsWith(APP_URL)) { shell.openExternal(url); return { action: "deny" }; }
    return { action: "allow" };
  });

  Menu.setApplicationMenu(Menu.buildFromTemplate([
    {
      label: "Archivo",
      submenu: [
        { label: "Abrir proyecto", accelerator: "CmdOrCtrl+O", click: () => mainWindow.loadURL(APP_URL) },
        { type: "separator" },
        { role: "quit", label: "Salir" },
      ],
    },
    {
      label: "Ver",
      submenu: [
        { role: "reload", label: "Recargar interfaz" },
        { role: "resetZoom", label: "Zoom normal" },
        { role: "zoomIn", label: "Acercar" },
        { role: "zoomOut", label: "Alejar" },
        { type: "separator" },
        { role: "togglefullscreen", label: "Pantalla completa" },
        { role: "toggleDevTools", label: "Herramientas de diagnóstico" },
      ],
    },
    {
      label: "Ecosistema BIMCost",
      submenu: [
        { label: `BC Quantity ${health?.version ? `v${health.version}` : ""}`, enabled: false },
        { label: "BC Budget — próximo módulo", enabled: false },
        { label: "BC Planning — futuro", enabled: false },
      ],
    },
  ]));
}

ipcMain.handle("bimcost:pick-ifc", async () => {
  const result = await dialog.showOpenDialog(mainWindow, {
    title: "Seleccionar modelos IFC",
    filters: [{ name: "Modelos IFC", extensions: ["ifc", "ifcxml", "step"] }],
    properties: ["openFile", "multiSelections"],
  });
  if (result.canceled) return [];
  return result.filePaths.map((p) => ({
    path: p,
    name: path.basename(p).replace(/\.(ifc|ifcxml|step)$/i, ""),
    sizeMB: Math.round((fs.statSync(p).size / 1048576) * 10) / 10,
  }));
});

ipcMain.handle("bimcost:pick-excel", async () => {
  const result = await dialog.showOpenDialog(mainWindow, {
    title: "Seleccionar Excel",
    filters: [{ name: "Hojas de cálculo", extensions: ["xlsx", "xls", "csv"] }],
    properties: ["openFile"],
  });
  if (result.canceled) return null;
  return { path: result.filePaths[0], name: path.basename(result.filePaths[0]) };
});

/**
 * Transmite un IFC desde el disco al backend por streaming multipart.
 * El renderer (la interfaz) nunca guarda el archivo completo en memoria.
 */
ipcMain.handle("bimcost:import-ifc", async (_event, args) => {
  const filePath = String(args?.path || "");
  const projectId = String(args?.projectId || "");
  if (!filePath || !projectId) throw new Error("Ruta y proyecto son obligatorios.");
  const stat = fs.statSync(filePath);
  const boundary = `----BIMCost${Date.now().toString(16)}`;
  const fields = {
    kind: "IFC",
    name: args.name || path.basename(filePath).replace(/\.(ifc|step)$/i, ""),
    discipline: args.discipline || "GENERAL",
    actor: args.actor || "",
    unitScale: args.unitScale || "auto",
  };
  const pieces = [];
  for (const [k, v] of Object.entries(fields)) {
    pieces.push(Buffer.from(`--${boundary}\r\nContent-Disposition: form-data; name="${k}"\r\n\r\n${v}\r\n`));
  }
  const fileHeader = Buffer.from(
    `--${boundary}\r\nContent-Disposition: form-data; name="file"; filename="${path.basename(filePath).replace(/"/g, "")}"\r\n` +
    `Content-Type: application/octet-stream\r\n\r\n`
  );
  const footer = Buffer.from(`\r\n--${boundary}--\r\n`);
  const contentLength = pieces.reduce((n, b) => n + b.length, 0) + fileHeader.length + stat.size + footer.length;

  return await new Promise((resolve, reject) => {
    const req = http.request(`${APP_URL}/api/projects/${projectId}/sources`, {
      method: "POST",
      headers: {
        "Content-Type": `multipart/form-data; boundary=${boundary}`,
        "Content-Length": String(contentLength),
      },
    }, (res) => {
      let body = "";
      res.on("data", (d) => { body += d; });
      res.on("end", () => {
        let parsed;
        try { parsed = JSON.parse(body); } catch { parsed = { error: body || `Error ${res.statusCode}` }; }
        if (res.statusCode && res.statusCode >= 200 && res.statusCode < 300) resolve(parsed);
        else reject(new Error(parsed.error || `Error ${res.statusCode}`));
      });
    });
    req.on("error", reject);
    for (const b of pieces) req.write(b);
    req.write(fileHeader);
    const stream = fs.createReadStream(filePath);
    stream.on("error", reject);
    stream.on("end", () => { req.write(footer); req.end(); });
    stream.pipe(req, { end: false });
  });
});

ipcMain.handle("bimcost:info", () => ({ version: app.getVersion(), desktop: true, platform: process.platform }));

app.commandLine.appendSwitch("js-flags", "--max-old-space-size=8192");
app.commandLine.appendSwitch("disable-renderer-backgrounding");

app.whenReady().then(async () => {
  try {
    ensureDockerBackend();
    const health = await waitForServer();
    createWindow(health);
  } catch (err) {
    dialog.showErrorBox("BIMCost Budget", String(err?.message || err));
    app.quit();
  }
});

app.on("window-all-closed", () => { if (process.platform !== "darwin") app.quit(); });
app.on("activate", () => { if (BrowserWindow.getAllWindows().length === 0) waitForServer().then(createWindow); });
