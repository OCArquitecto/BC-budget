/* ==================================================================
 *  Puente seguro entre la interfaz web y el escritorio.
 *  Expone únicamente lo necesario: selección de archivos por ruta
 *  (para no cargar modelos grandes en la memoria del navegador).
 * ================================================================== */
"use strict";

const { contextBridge, ipcRenderer } = require("electron");

contextBridge.exposeInMainWorld("bimcost", {
  isDesktop: true,
  /** Abre el diálogo nativo y devuelve las rutas de los IFC elegidos. */
  pickIfc: () => ipcRenderer.invoke("bimcost:pick-ifc"),
  /** Abre el diálogo nativo para elegir un Excel. */
  pickExcel: () => ipcRenderer.invoke("bimcost:pick-excel"),
  /** Importa un IFC por streaming, sin cargarlo en la memoria de la interfaz. */
  importIfc: (args) => ipcRenderer.invoke("bimcost:import-ifc", args),
  /** Información de la aplicación de escritorio. */
  info: () => ipcRenderer.invoke("bimcost:info"),
  /** Evento del menú Archivo → Abrir modelo IFC. */
  onOpenIfc: (cb) => {
    ipcRenderer.removeAllListeners("bimcost:open-ifc");
    ipcRenderer.on("bimcost:open-ifc", () => cb());
  },
});
