@echo off
chcp 65001 >nul
cd /d "%~dp0"
title BIMCost Budget - Abrir

set "APP_URL=http://localhost:3001"
set "APP_RUNNING="

where docker >nul 2>nul
if errorlevel 1 goto :notRunning

for /f "delims=" %%S in ('docker inspect -f "{{.State.Running}}" bimcost-budget-app 2^>nul') do set "APP_RUNNING=%%S"
if /i "%APP_RUNNING%"=="true" (
  start "" "%APP_URL%"
  exit /b 0
)

:notRunning
echo BIMCost Budget no esta encendido todavia.
echo Se abrira el asistente de inicio...
echo.
call "%~dp0INSTALAR.bat"
